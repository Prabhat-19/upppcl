import { Component, OnInit,HostListener } from '@angular/core';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import { AdminEditService } from '../admin-edit/admin-edit.service';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from "../../environments/environment";
import {NgxSpinnerService} from 'ngx-spinner';
import {GenerateTokenService} from '../generate-token/generate-token.service';

@Component({
  selector: 'app-admin-details-edit',
  templateUrl: './admin-details-edit.component.html',
  styleUrls: ['./admin-details-edit.component.scss']
})
export class AdminDetailsEditComponent implements OnInit {
  
  datas: any;
  editDetailsData: any;
  token:any
  constructor(private spinner:NgxSpinnerService,private generateTokenService:GenerateTokenService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private router: Router, private adminEdit: AdminEditService) { }

  ngOnInit() {
    this.checkUserTyper();
    this.agentAuth();
    var controls = $('.personalForm :input');
    controls.each(function (index, value) {
      $(this).prop('disabled', true);
      $('select').css('background-color', '#ebebe4')
    })
    this.edit();
    this.activeTab();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
  
  
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  edit() {
    this.spinner.show();
    let radiobtn;
    var id = localStorage.getItem("subAgentEditId");
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data=>{
      this.token=data;
    this.adminEdit.editDetails(id,this.token.access_token).then(data => {
      this.editDetailsData = data;
      if (this.editDetailsData.gstin != "" && this.editDetailsData.gstin != undefined) {
        $("#yesanswer").show();
        radiobtn = document.getElementById("yes");
        radiobtn.checked = true;
      }
      else {
        radiobtn = document.getElementById("no");
        radiobtn.checked = true;
        $("#yesanswer").hide();
      }
      this.editDetailsData.documents.forEach(element => {
        (<HTMLInputElement>document.getElementById(element.type)).innerHTML 
        = "<a href='" +element.location + "'>View Document</a>";
      });
    })
  })
  this.spinner.hide();
  }

  routingFunction(){
    if(this.editDetailsData.agentType == "AGENT")
      this.router.navigate(['/admin-analysis']);
      else
      this.router.navigate(['/admin-agency']);
  }

  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      $('#nav-about-tab').css('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      $('#nav-about-tab').css('background-color', '#6f8294');
    })
    $('#nav-about-tab').click(function () {
      $('#nav-about-tab').css('background-color', '#246aaf');
      $('#nav-profile-tab').css('background-color', '#6f8294');
      $('#nav-home-tab').css('background-color', '#6f8294');
    })
  }
}
