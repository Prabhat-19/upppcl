import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { constant } from 'src/environments/constant';

@Injectable({
  providedIn: 'root'
})
export class GenerateTokenService {
 
  constructor(private httpClient:HttpClient) { }
  getToken(consumerkey,consumerSecret) {
let token = btoa(consumerkey+':'+consumerSecret);
    
   
    let url = environment.ws02TokenAuthAPI+'&username='+constant.adminWSO2UserName+'&password='+constant.adminWSO2Password;
    
    let promise = new Promise((resolve, reject) => {
    this.httpClient.post(url, {},
      {
        headers: new HttpHeaders({
          'content-type':'application/x-www-form-urlencoded',
          'Authorization':'Basic ' + token
        })
      }).toPromise().then(data => {
        resolve(data);
      }),msg => {
      }
    })
    return promise;
  }
}
