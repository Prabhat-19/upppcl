import { Component, OnInit,HostListener } from '@angular/core';
import { AgentProfileService } from '../agent-profile/agent-profile.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import {environment} from '../../environments/environment';
import {TokenGenerateService} from '../token-generate.service';
import {GenerateTokenService} from '../generate-token/generate-token.service';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-agency-profile',
  templateUrl: './agency-profile.component.html',
  styleUrls: ['./agency-profile.component.scss']
})
export class AgencyProfileComponent implements OnInit {
  
  postalCode: string;
  city: string;
  state: string;
  agencyName: string;
  streetNumber: number;
  contactNumber: number;
  tanNumber: any;
  panNumber: string;
  address: string;
  emailAddress: string;
  lastName: string;
  firstName: string;
  registrationNumber: any;
  datas: any;
  userType: string;
  discom: string;
  division: string;
  image: any;
  radiobtn: any;
  gstin: string;
  token:any;
  agencyDetails:any;


  constructor(private spinner:NgxSpinnerService,private generateTokenService:GenerateTokenService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private agentDetail: AgentProfileService, private router: Router) { }

  ngOnInit() {
    this.activeTab();
    this.agentAuth();
    $('#selectUsertype').prop('disabled', true);
    $('#selectUsertype').css('background-color', '#ebebe4');
    $('#userName').prop('disabled', true);
    $('#userName').css('background-color', '#ebebe4');
    $('#emailId').prop('disabled', true);
    $('#emailId').css('background-color', '#ebebe4');
    this.Details();
    this.checkUserTyper();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /**
   * Agent details
   */
  Details() {
    this.spinner.show();
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data=>{
      this.token=data;
    this.agentDetail.getDetail(this.token.access_token).then(data => {
      this.agencyDetails = data;
      if (this.agencyDetails[0].gstin != undefined) {
        $("#yesanswer").show();
        this.radiobtn = document.getElementById("yes");
        this.radiobtn.checked = true;
        // this.gstinLabel = true;
      }
      else {
        this.radiobtn = document.getElementById("no");
        this.radiobtn.checked = true;
       // this.gstinLabel = false;
        $("#yesanswer").hide();
      }
      // this.registrationNumber = this.datas[0].registrationNumber;
      // this.firstName = this.datas[0].user.firstName;
      // this.lastName = this.datas[0].user.lastName;
      // this.agencyName = this.datas[0].agencyName
      // this.emailAddress = this.datas[0].user.email;
      // this.address = this.datas[0].user.address.state;
      // this.panNumber = this.datas[0].panNumber;
      // this.tanNumber = this.datas[0].tinNumber;
      // this.address = this.datas[0].user.residenceAddress.city;
      // this.contactNumber = this.datas[0].user.mobile;
      // this.streetNumber = this.datas[0].user.address.street;
      // this.state = this.datas[0].user.address.state;
      // this.city = this.datas[0].user.address.city;
      // this.postalCode = this.datas[0].user.address.postalCode;
      // this.userType = this.agencyDetails[0].user.role;
      // this.discom = this.datas[0].discomSubscription;
      // this.division = this.datas[0].division;
      // (<HTMLInputElement>document.getElementById("file1")).innerHTML = "<a href='" + this.agencyDetails[0].documents[0].location + "'>View Document</a>";
      // (<HTMLInputElement>document.getElementById("file2")).innerHTML = "<a href='" + this.agencyDetails[0].documents[1].location + "'>View Document</a>";
      // (<HTMLInputElement>document.getElementById("file3")).innerHTML = "<a href='" + this.agencyDetails[0].documents[2].location + "'>View Document</a>";
      // (<HTMLInputElement>document.getElementById("file4")).innerHTML = "<a href='" + this.agencyDetails[0].documents[3].location + "'>View Document</a>";
      // (<HTMLInputElement>document.getElementById("file5")).innerHTML = "<a href='" + this.agencyDetails[0].documents[4].location + "'>View Document</a>";
      console.log("<==>" +this.agencyDetails[0].documents);
      this.agencyDetails[0].documents.forEach(element => {
        (<HTMLInputElement>document.getElementById(element.type)).innerHTML 
        = "<a href='" +element.location + "'>View Document</a>";

      });
      
      // this.image = this.datas[0].documents[0].location;
    })

  })
  this.spinner.hide();
  }

  /**
   * check user type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agent")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * active tab code
   */
  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      $('#nav-about-tab').css('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      $('#nav-about-tab').css('background-color', '#6f8294');
    })
    $('#nav-about-tab').click(function () {
      $('#nav-about-tab').css('background-color', '#246aaf');
      $('#nav-profile-tab').css('background-color', '#6f8294');
      $('#nav-home-tab').css('background-color', '#6f8294');
    })
  }

  submitButton(profileForm: NgForm, profileBussinessForm:NgForm){
  this.tokenGenerate.getToken(environment.userToken).then(data => {
      this.token = data;
      this.agentDetail.putUpdate(this.token.access_token,profileForm.value,profileBussinessForm.value).then(data => {
        window.location.reload()
      });
    });
    }
}
