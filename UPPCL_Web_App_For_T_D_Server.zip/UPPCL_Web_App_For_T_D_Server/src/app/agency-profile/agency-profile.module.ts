import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { AgencyProfileRoutingModule } from './agency-profile-routing.module';
import {AgencyProfileComponent} from './agency-profile.component';
import { NgxSpinnerModule } from "ngx-spinner";


@NgModule({
  declarations: [AgencyProfileComponent],
  imports: [
    CommonModule,
    AgencyProfileRoutingModule,
    FormsModule,
    RouterModule,
    NgxSpinnerModule,
    SharedModule
  ]
})
export class AgencyProfileModule { }
