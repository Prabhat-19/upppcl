import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgentProfileService {
header:any;
address:any;
residenceAddress:any;
  constructor(private http: HttpClient) { }

  getDetail(token) {
    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
    return new Promise(resolve => {
      this.http.get(environment.manageSubAgentEdit + localStorage.getItem("userId"),this.header).subscribe(data => {
         resolve(data);
      });
    });
  }

  putUpdate(token,profileForm,profileBussinessForm) {
    this.address= {
      address : profileBussinessForm.address,
      city : profileBussinessForm.city,
      district : profileBussinessForm.district,
      state : profileBussinessForm.state,
      postalCode : profileBussinessForm.postalCode};
      this.residenceAddress ={
        address: profileForm.residenceAddress,
        city : profileForm.residencecity,
        district : profileForm.residencedistrict,
        state : profileForm.residencestate,
        postalCode : profileForm.residencepostalCode
      };
    var payload={
      // "agentType" : profileForm.registerAs,
      // "agencyName" : profileForm.agencyName,
      // "userName":profileForm.userName,
      // "discomSubscription":profileForm.discomSubscription,
      // "division" : "",
      "residenceAddress" : this.residenceAddress,
      "address" : this.address,
      // "documents" :this.document,
      // "email" : profileForm.EmailId,
      "firstName" : profileForm.firstName,
      // "gstin" : profileBussinessForm.gstinNumber,
      "lastName" : profileForm.lastName,
      // "panNumber" : profileBussinessForm.panNumber,
      "mobile" : profileBussinessForm.mobile,
      // "tinNumber" : profileBussinessForm.tanNumber,
    };
    this.header = {
      headers: new HttpHeaders({
        // 'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
    return new Promise(resolve => {
      this.http.put(environment.updateUserDetails + localStorage.getItem("userId"),payload,this.header).subscribe(data => {
         resolve(data);
      });
    });
  }
}
