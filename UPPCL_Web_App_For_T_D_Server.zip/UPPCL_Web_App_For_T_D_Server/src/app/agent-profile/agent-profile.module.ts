import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { HeaderComponent  } from '../header/header.component';
// import { FooterComponent  } from '../footer/footer.component';
import { AgentProfileComponent } from './agent-profile.component';
import { AgentProfileRoutingModule } from './agent-profile-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [AgentProfileComponent],
  imports: [
    CommonModule,
    AgentProfileRoutingModule,
    FormsModule,
    RouterModule,
    NgxSpinnerModule,
    SharedModule
  ]
})
export class AgentProfileModule { }
