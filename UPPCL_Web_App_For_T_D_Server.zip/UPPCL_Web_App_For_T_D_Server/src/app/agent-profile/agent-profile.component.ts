import { Component, OnInit,HostListener } from '@angular/core';
import { AgentProfileService } from './agent-profile.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';
import {environment} from '../../environments/environment';
import {GenerateTokenService} from '../generate-token/generate-token.service';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-agent-profile',
  templateUrl: './agent-profile.component.html',
  styleUrls: ['./agent-profile.component.scss']
})
export class AgentProfileComponent implements OnInit {
  // @HostListener('document:mousemove', ['$event']) 
  // onMouseMove(e) {
  //   this.agentAuth();
  // }
  agentDetailsData: any;
  image: any;
  radiobtn: any;
  gstinDocumentLabel:boolean = true;
  datas:any;
  token:any;
  constructor(private spinner:NgxSpinnerService,private generateTokenService:GenerateTokenService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private agentDetail: AgentProfileService, private router: Router) { }
  ngOnInit() {
    this.agentAuth();
    this.activeTab();
    $('#selectUsertype').prop('disabled', true);
    $('#selectUsertype').css('background-color', '#ebebe4');
    $('#userName').prop('disabled', true);
    $('#userName').css('background-color', '#ebebe4');
    $('#EmailId').prop('disabled', true);
    $('#EmailId').css('background-color', '#ebebe4');
    this.Details();
    this.checkUserTyper();
  }
  agentAuth() {
    
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;
      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
  Details() {
    this.spinner.show();
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data=>{
      this.token=data;
    this.agentDetail.getDetail(this.token.access_token).then(data => {

      this.agentDetailsData = data;

      var agencyis=this.agentDetailsData[0].agencyId;
if(agencyis!=undefined)
{
  $(":input" ).each(function(){
    $(this).attr('disabled','disabled');

  })
  $('#mySelect2').css('background-color', '#ebebe4');
 
}

      $("#city").val(this.agentDetailsData[0].user.address.city);
      $("#address").val(this.agentDetailsData[0].user.address.address);
      $("#state").val(this.agentDetailsData[0].user.address.state);
      $("#district").val(this.agentDetailsData[0].user.address.district);
      $("#postalCode").val(this.agentDetailsData[0].user.address.postalCode);

      $("#panNumber").val(this.agentDetailsData[0].panNumber);
      $("#tinNumber").val(this.agentDetailsData[0].tinNumber);
      $("#mobile").val(this.agentDetailsData[0].user.mobile);
      $("#yesanswer").val(this.agentDetailsData[0].gstin);


      $("#firstName").val(this.agentDetailsData[0].user.firstName);
      $("#lastName").val(this.agentDetailsData[0].user.lastName);
      $("#EmailId").val(this.agentDetailsData[0].user.email);
      $("#userName").val(this.agentDetailsData[0].user.userName);
      $("#mySelect2").val(this.agentDetailsData[0].discoms).change();;
     
    
      $("#residenceAddress").val(this.agentDetailsData[0].user.residenceAddress.address);
      $("#residencecity").val(this.agentDetailsData[0].user.residenceAddress.city);
      $("#residencestate").val(this.agentDetailsData[0].user.residenceAddress.state);
      $("#residencedistrict").val(this.agentDetailsData[0].user.residenceAddress.district);
      $("#residencepostalCode").val(this.agentDetailsData[0].user.residenceAddress.postalCode);

      // $("#myFilea").val(this.agentDetailsData[0].documents[0].location);
      // $("#RESIDENCE_ID").val(this.agentDetailsData[0].documents[1].location);
      // $("#myFiler").val(this.agentDetailsData[0].user.residenceAddress.postalCode);
      // $("#myFilep").val(this.agentDetailsData[0].user.residenceAddress.postalCode);
      // $("#myFileg").val(this.agentDetailsData[0].user.residenceAddress.postalCode);
      // $("#myFilei").val(this.agentDetailsData[0].user.residenceAddress.postalCode);
     

      if (this.agentDetailsData[0].gstin != undefined) {
        $("#yesanswer").show();
        var radiobtn = document.getElementById("yes") as HTMLInputElement;
        radiobtn.checked = true;
        this.gstinDocumentLabel = true;
      }
      else {
        radiobtn = document.getElementById("no") as HTMLInputElement;
        radiobtn.checked = true;
        this.gstinDocumentLabel = false;
        $("#yesanswer").hide();
      }
      this.agentDetailsData[0].documents.forEach(element => {
        (<HTMLInputElement>document.getElementById(element.type)).innerHTML 
        = "<a href='" +element.location + "'>View Document</a>";
      });
    })
  })
  this.spinner.hide();
  }
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      $('#nav-about-tab').css('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      $('#nav-about-tab').css('background-color', '#6f8294');
    })
    $('#nav-about-tab').click(function () {
      $('#nav-about-tab').css('background-color', '#246aaf');
      $('#nav-profile-tab').css('background-color', '#6f8294');
      $('#nav-home-tab').css('background-color', '#6f8294');
    })
  }
  submitButton(profileForm: NgForm, profileBussinessForm:NgForm){
  this.tokenGenerate.getToken(environment.userToken).then(data => {
    this.token = data;
    this.agentDetail.putUpdate(this.token.access_token,profileForm.value,profileBussinessForm.value)
    .then(data => {
      window.location.reload()
    });
  });
  }
  
}
