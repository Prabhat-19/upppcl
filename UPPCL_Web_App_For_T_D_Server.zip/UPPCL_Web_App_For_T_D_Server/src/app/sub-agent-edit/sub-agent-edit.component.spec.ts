import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubAgentEditComponent } from './sub-agent-edit.component';

describe('SubAgentEditComponent', () => {
  let component: SubAgentEditComponent;
  let fixture: ComponentFixture<SubAgentEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubAgentEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubAgentEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
