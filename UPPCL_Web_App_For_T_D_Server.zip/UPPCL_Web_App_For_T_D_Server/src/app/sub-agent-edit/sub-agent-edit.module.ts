import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubAgentEditRoutingModule } from './sub-agent-edit-routing.module';
import { SubAgentEditComponent } from './sub-agent-edit.component';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import {NgxPaginationModule} from 'ngx-pagination'; 
import {NgxSpinnerModule} from 'ngx-spinner';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [SubAgentEditComponent],
  imports: [
    CommonModule,
    SubAgentEditRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxPaginationModule,
    NgxSpinnerModule,
    ScrollingModule,
    OrderModule,
  ],
  providers: [DatePipe]
})
export class SubAgentEditModule { }
