import { Component, OnInit, HostListener } from '@angular/core';
import { AdminEditService } from '../admin-edit/admin-edit.service';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import {NgxSpinnerService} from 'ngx-spinner';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';
declare var $: any

@Component({
  selector: 'app-sub-agent-edit',
  templateUrl: './sub-agent-edit.component.html',
  styleUrls: ['./sub-agent-edit.component.scss']
})
export class SubAgentEditComponent implements OnInit {

  datas: any;
  editDetailsData: any;
  token:any
  constructor(private spinner:NgxSpinnerService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private router: Router, private adminEdit: AdminEditService) { }

  ngOnInit() {
    $('#adminAgencyHeader').css('color', 'white');
    this.checkUserTyper();
    this.agentAuth();
    this.activeTab();
    var controls = $('.personalForm :input');
    controls.each(function (index, value) {
      $(this).prop('disabled', true);
      $('select').css('background-color', '#ebebe4')
    })
    this.edit();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /**
   * Method to check user Type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * Edit
   */
  edit() {
    this.spinner.show();
    let radiobtn;
    var id = localStorage.getItem("subAgentId");
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data=>{
      this.token=data;
    this.adminEdit.editDetails(id,this.token.access_token).then(data => {
      this.editDetailsData = data;
      if (this.editDetailsData.gstin != "" && this.editDetailsData.gstin != undefined) {
        $("#yesanswer").show();
        radiobtn = document.getElementById("yes");
        radiobtn.checked = true;
      }
      else {
        radiobtn = document.getElementById("no");
        radiobtn.checked = true;
        $("#yesanswer").hide();
      }
    
      this.editDetailsData.documents.forEach(element => {
        (<HTMLInputElement>document.getElementById(element.type)).innerHTML 
        = "<a href='" +element.location + "'>View Document</a>";
      });
    })
  })
  this.spinner.hide();
  }
  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      // $('#nav-about-tab').csss('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      // $('#nav-about-tab').css('background-color', '#6f8294');
    })
    // $('#nav-about-tab').click(function () {
    //   $('#nav-about-tab').css('background-color', '#246aaf');
    //   $('#nav-profile-tab').css('background-color', '#6f8294');
    //   $('#nav-home-tab').css('background-color', '#6f8294');
    // })
  }
}
