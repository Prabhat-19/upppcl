import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminTransactionComponent } from './admin-transaction.component';
import {Routes,Router,RouterModule  } from '@angular/router';

const route:Routes=[
  {path:'admin-transaction',component:AdminTransactionComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
    ]
})
export class AdminTransactionRoutingModule { }
