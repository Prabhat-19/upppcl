import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { AdminDashboardService } from '../admin-dashboard/admin-dashboard.service';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-admin-transaction',
  templateUrl: './admin-transaction.component.html',
  styleUrls: ['./admin-transaction.component.scss']
})

export class AdminTransactionComponent implements OnInit {
  
  a: any;
  uppclLedgerData = [];
  result: any;
  activities: any;
  firstArray = [];
  secondArray = [];
  dataResult: any;
  van: any;
  filterData = [];
  ledgerHistory: boolean = false;
  row: any;
  startDate: any;
  endDate: any;
  allData: any;
  filterSource: any;
  datas: any;
  searchBarValue: any;
  source: string;
  usersData: any;
  firstName: string;
  lastName: string;
  agentType: string;
  agencyName: string;
  loop: any;
  config: any;
  creditAmount: number;
  debitAmount: number;
  ledgerAdminData: any;
  addData = [];
  userDetails: any;
  vanUserDetails: any;
  rowData: any;
  filterTransactionId: any;
  filterAgentId = 'User Type';
  filterType: any;
  filterConsumerId: any;
  filterBillNumber = 'Source';
  filterAmount: any;
  filterFromDate: any;
  filterToDate: any;
  // nextPageToken: "";
  constructor(private spinner: NgxSpinnerService, public datepipe: DatePipe, private tokenGenerate: TokenGenerateService, private AdminDashboard: AdminDashboardService, private agentDashboardService: AgentDashboardService, private router: Router, private excelService: ExcelServiceService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
    };
  }

  ngOnInit() {
    this.checkUserTyper();
    this.agentAuth();
    this.ledgerData("");
   
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }


  /**
   * To check agent Type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * For ledger data
   */
  ledgerData(nextPageToken) {
    this.spinner.show();
    this.creditAmount = 0;
    this.tokenGenerate.getToken(environment.uppclTransactionToken).then(data => {
      this.datas = data;
      this.AdminDashboard.uppclTransactionData(this.datas.access_token,nextPageToken).then(data => {
        this.ledgerAdminData = data;
        var self = this;
        for (var a = 0; a < self.ledgerAdminData.result.length; a++) {
          (function (j) {
            self.userDetailsTransaction(self.ledgerAdminData.result[j].entityId).then(data => {
              self.vanUserDetails = data;
              if (self.vanUserDetails.agentType == "AGENCY") {
                self.ledgerAdminData.result[j]['agencyName'] = self.vanUserDetails.agencyName;
              }
              else {
                self.ledgerAdminData.result[j]['agencyName'] = self.vanUserDetails.user.firstName + " " + self.vanUserDetails.user.lastName;
              }
              self.ledgerAdminData.result[j]['van'] = self.vanUserDetails.van
            });
          })(a);
          self.addData.push(self.ledgerAdminData.result[a]);
          console.log(self.addData);
          if (this.addData[a].discom == undefined || this.addData[a].discom == "") { this.addData[a].discom = "-"; }
          if (this.addData[a].division == undefined || this.addData[a].division == "") { this.addData[a].division = "-"; }
          if (this.addData[a].transactionType == "NON_RAPDRP") { this.addData[a].transactionType = "NON-RAPDRP (RURAL)"; }
          if (this.addData[a].transactionType == "RAPDRP") { this.addData[a].transactionType = "RAPDRP (URBAN)"; }
          this.creditAmount += this.ledgerAdminData.result[a].amount;
        }
      });
    });
    this.spinner.hide();
  }
  userDetailsTransaction(entityId) {
    return new Promise(resolve => {
      this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
        this.datas = data;
        this.AdminDashboard.userData(entityId, this.datas.access_token).then(data => {
          resolve(data);
        });
      });
    });
  }
  pageChanged(event) {
    this.config.currentPage = event;
    if(this.ledgerAdminData.recordCount == 20){
      this.ledgerData(this.ledgerAdminData.nextPageToken);
    }
  }
  /**
   * method for filter search bar
   * @param event 
   */
  onSubmit() {
    this.filterData = [];

    for (var agentTranscationLoop = 0; agentTranscationLoop < this.ledgerAdminData.result.length; agentTranscationLoop++) {

      if (this.filterTransactionId == null) {
        this.filterTransactionId = "";
      }
      if ((this.filterFromDate > this.filterToDate)) {
        this.callModal("Invalid Date Range.");
        this.filterFromDate = "";
        this.filterToDate = "";
      }
      if (this.filterTransactionId == null || (this.filterTransactionId != null && this.ledgerAdminData.result[agentTranscationLoop].externalTransactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
        && (this.filterAgentId == 'User Type' || (this.filterAgentId != 'User Type' && this.ledgerAdminData.result[agentTranscationLoop].entityType == (this.filterAgentId)))
        && (this.filterType == null || (this.filterType != null && this.ledgerAdminData.result[agentTranscationLoop].activity.toUpperCase().includes(this.filterType.toUpperCase())))
        && (this.filterConsumerId == null || (this.filterConsumerId != null && this.ledgerAdminData.result[agentTranscationLoop].amount == (Number(this.filterConsumerId))))
        && (this.filterBillNumber == 'Source' || (this.filterBillNumber != 'Source' && this.ledgerAdminData.result[agentTranscationLoop].transactionType == (this.filterBillNumber)))
        && (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.datepipe.transform(this.ledgerAdminData.result[agentTranscationLoop].transactionTime, 'dd-MM-yyyy') >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy'))))
        && (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy') != null && this.datepipe.transform(this.ledgerAdminData.result[agentTranscationLoop].transactionTime, 'dd-MM-yyyy') <= (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy'))))
      ) {
        this.filterData.push(this.ledgerAdminData.result[agentTranscationLoop])
      }
    }
    this.addData = this.filterData;
  }

  clear() {
    this.filterData = [];
    this.filterTransactionId = null;
    this.filterAgentId = 'User Type';
    this.filterType = null;
    this.filterConsumerId = null;
    this.filterBillNumber = 'Source';
    this.filterAmount = null;
    this.filterToDate = null;
    this.filterFromDate = null;
    this.addData = this.ledgerAdminData.result;
  }
  /**
   * Method to call Modal
   * @param message 
   */
  callModal(message: string) {
    $(document).ready(function () {
      $("#modalText").text(message);
      $('#btnhide').click();
    })
  }

  /**
   * Method to export as Excel File
   */
  exportAsXLSX(): void {
    for (var i = 0; i < this.addData.length; i++) {
      this.firstArray.push({
        TransactionId: this.addData[i].externalTransactionId,
        UserType: this.addData[i].entityType,
        Name: this.addData[i].agencyName.toUpperCase(),
        VAN: this.addData[i].van,
        Type: this.addData[i].activity,
        Discom: this.addData[i].discom,
        Division: this.addData[i].division,
        Amount: this.addData[i].amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
        Source: this.addData[i].transactionType,
        TransactionStatus: "Successful",
        Date: this.datepipe.transform(this.addData[i].transactionTime, 'dd-MM-yyyy')
      });
    }
    this.excelService.exportAsExcelFile(this.firstArray, 'UPPCL-transcation');
  }
}
