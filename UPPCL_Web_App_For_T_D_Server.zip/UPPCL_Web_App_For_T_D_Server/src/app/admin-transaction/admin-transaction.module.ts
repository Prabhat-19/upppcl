import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
// import {AdminHeaderComponent} from '../admin-header/admin-header.component'
import { AdminTransactionComponent } from './admin-transaction.component';
import { AdminTransactionRoutingModule } from './admin-transaction-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import {NgxPaginationModule} from 'ngx-pagination'; 
import {NgxSpinnerModule} from 'ngx-spinner'
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [AdminTransactionComponent],
  imports: [
    CommonModule,
    AdminTransactionRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxSpinnerModule,
    OrderModule,
    NgxPaginationModule
  ],
  providers: [DatePipe]

})
export class AdminTransactionModule { }
