import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { AdminAnalysisService } from '../admin-analysis/admin-analysis.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
import { OrderPipe } from 'ngx-order-pipe';
import { validation } from 'src/environments/validationsMessage';

@Component({
  selector: 'app-admin-agency-listing',
  templateUrl: './admin-agency-listing.component.html',
  styleUrls: ['./admin-agency-listing.component.scss']
})
export class AdminAgencyListingComponent implements OnInit {
  
  dataLngth: any = [];
  result: any[];
  datas: any;
  walletBalance: any;
  wallet: any;
  finalResult: any;
  config: any;
  token: any
  getData: any;
  getAllUserData = [];
  addData1: any;
  filterVirtualAccount: any;
  filterAgencyName: any;
  filterFirstName: any;
  filterLastName: any;
  filterMobileNumber: any;
  filterDistrict: any;
  filterWalletBalance: any;
  filterFromDate: any;
  filterToDate: any;
  filterData = [];
  adminData: any;
  filterAgencyName1: any;
  constructor(private orderPipe: OrderPipe, private spinnerService: NgxSpinnerService, public datepipe: DatePipe, private tokenGenerate: TokenGenerateService, private generateTokenService: GenerateTokenService, private agentDashboardService: AgentDashboardService, private router: Router, private AdminAnalysis: AdminAnalysisService) {
    this.config = {
      itemsPerPage: 15,
      currentPage: 1,
    };
  }

  ngOnInit() {
    this.agentAuth();
    // $('#adminDashboard').css('color', 'white');
    this.getAllRegisteredAgentsData();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  pageChanged(event) {
    this.config.currentPage = event;
  }

  // method to get all registered agent data
  getAllRegisteredAgentsData() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.AdminAnalysis.getId(this.token.access_token).then(data => {
        this.dataLngth = data;
        this.getallData();
      })
    })
  }

  getallData() {
    var self = this;
    for (var i = 0; i < self.dataLngth.length; i++) {
      // self.spinnerService.show();
      if (self.dataLngth[i].agentType == validation.upplcRoles.agency.toUpperCase()) {
      (function (j) {
            self.tokenGenerate.getToken(environment.tokenForBalanceUsingVan).then(data => {
            self.AdminAnalysis.getAllData(self.dataLngth[j].van, data).then(data => {
              self.addData1 = data;
              self.dataLngth[j]['wallet'] = self.addData1.balance;
              self.getAllUserData.push(self.dataLngth[j]);
              self.getAllUserData.sort((a,b) => a.user.createdAt.localeCompare(b.user.createdAt));
              self.adminData = self.dataLngth[j];
         });
          });
      })(i);
    }
  }
    // this.spinnerService.hide();
  }


  onSubmit() {
    this.filterData = [];
    for (var agentTranscationLoop = 0; agentTranscationLoop < this.adminData.length; agentTranscationLoop++) {

      if (this.filterVirtualAccount == null) {
        this.filterVirtualAccount = "";
      }
      if ((this.filterFromDate > this.filterToDate)) {
        this.callModal("Invalid Date Range.");
        this.filterFromDate = "";
        this.filterToDate = "";
      }
      if (this.filterToDate != null) {
        let newDate = new Date(this.filterToDate);
        var nextDate = new Date(newDate.getTime() + 1000 * 60 * 60 * 24);
      }
      if (this.filterVirtualAccount == null || (this.filterVirtualAccount != null && this.adminData[agentTranscationLoop].van.toUpperCase().includes(this.filterVirtualAccount.toUpperCase()))
        && (this.filterAgencyName1 == null || (this.filterAgencyName1 != null && this.adminData[agentTranscationLoop].agenciesName.toUpperCase().includes(this.filterAgencyName1.toUpperCase())))
        && (this.filterAgencyName == null || (this.filterAgencyName != null && this.adminData[agentTranscationLoop].agencyName.toUpperCase().includes(this.filterAgencyName.toUpperCase())))
        && (this.filterFirstName == null || (this.filterFirstName != null && this.adminData[agentTranscationLoop].user.firstName.toUpperCase().includes(this.filterFirstName.toUpperCase())))
        && (this.filterLastName == null || (this.filterLastName != null && this.adminData[agentTranscationLoop].user.lastName.toUpperCase().includes(this.filterLastName.toUpperCase())))
        && (this.filterMobileNumber == null || (this.filterMobileNumber != null && this.adminData[agentTranscationLoop].user.mobile.includes(this.filterMobileNumber)))
        && (this.filterDistrict == null || (this.filterDistrict != null && this.adminData[agentTranscationLoop].user.address.district.toUpperCase().includes(this.filterDistrict.toUpperCase())))
        && (this.filterWalletBalance == null || (this.filterWalletBalance != null && this.adminData[agentTranscationLoop].wallet.toString() == (this.filterWalletBalance)))
        && (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') != null && this.adminData[agentTranscationLoop].user.createdAt >= (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd'))))
        && (this.datepipe.transform(nextDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(nextDate, 'yyyy-MM-dd') != null && this.adminData[agentTranscationLoop].user.createdAt <= (this.datepipe.transform(nextDate, 'yyyy-MM-dd'))))
      ) {
        this.filterData.push(this.adminData[agentTranscationLoop])
      }
    }

    this.getAllUserData = this.filterData;
  }

  subAgentDetails(AgencyID, agencyName) {
    localStorage.setItem('AgencyID', AgencyID);
    localStorage.setItem('agencyName', agencyName);
    this.router.navigate(['sub-agent']);
  }

  clear() {
    this.filterData = [];
    this.filterVirtualAccount = null;
    this.filterAgencyName = null;
    this.filterFirstName = null;
    this.filterLastName = null;
    this.filterMobileNumber = null;
    this.filterDistrict = null;
    this.filterWalletBalance = null;
    this.filterToDate = null;
    this.filterFromDate = null;
    this.getAllUserData = this.adminData;
  }

  /** method to get all registered agent 
   *  Store agentId , Van and Agency Name in local Storage
   *  */
  allRegistereduser(subAgentId, subAgentVan, AgencyName) {
    this.router.navigate(['all-subagentdetails']);
    localStorage.setItem("subAgentId", subAgentId);
    localStorage.setItem("subAgentVan", subAgentVan);
    localStorage.setItem("AgencyName", AgencyName);
  }

  /** method to navigate to adminDetails-edit page 
   * Store Sub Agent ID
   * */
  allEditDetails(subAgentEditId) {
    localStorage.setItem("subAgentEditId", subAgentEditId);
    this.router.navigate(['/adminDetails-edit']);
  }

  // method for modal
  callModal(message: string) {
    $(document).ready(function () {
      $("#modalText").text(message);
      $('#btnhide').click();
    })
  }

}

