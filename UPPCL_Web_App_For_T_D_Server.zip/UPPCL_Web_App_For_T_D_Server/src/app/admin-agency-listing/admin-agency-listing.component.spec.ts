import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAgencyListingComponent } from './admin-agency-listing.component';

describe('AdminAgencyListingComponent', () => {
  let component: AdminAgencyListingComponent;
  let fixture: ComponentFixture<AdminAgencyListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminAgencyListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAgencyListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
