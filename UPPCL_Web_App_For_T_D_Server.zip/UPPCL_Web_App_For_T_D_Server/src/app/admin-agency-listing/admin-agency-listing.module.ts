import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminAgencyListingComponent } from './admin-agency-listing.component';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { AdminAgencyListingRoutingModule } from './admin-agency-listing-routing.module';
import {NgxPaginationModule} from 'ngx-pagination'; 
import {NgxSpinnerModule} from 'ngx-spinner';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [AdminAgencyListingComponent],
  imports: [
    CommonModule,
    AdminAgencyListingRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxPaginationModule,
    NgxSpinnerModule,
    ScrollingModule,
    OrderModule
  ],
  providers: [DatePipe]

})
export class AdminAgencyListingModule { }
