import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAgencyListingComponent } from './admin-agency-listing.component';

const routes: Routes = [
  {path:'admin-agency',component:AdminAgencyListingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminAgencyListingRoutingModule { }
