import { TestBed } from '@angular/core/testing';

import { RechargeSuccessService } from './recharge-success.service';

describe('RechargeSuccessService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RechargeSuccessService = TestBed.get(RechargeSuccessService);
    expect(service).toBeTruthy();
  });
});
