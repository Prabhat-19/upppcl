import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RechargeSuccessService {

  constructor(private http: HttpClient) { }
  
  getBalance() {
    return new Promise(resolve => {
      const url = 'http://49.50.81.110:9999/api/wallet/agent/' + localStorage.getItem('agentId');
      this.http.get(url).subscribe((data: any) => {
        resolve(data);
      });
    });
  }
}
