import { Component, OnInit,HostListener } from '@angular/core';
import { RechargeSuccessService } from '../recharge-success/recharge-success.service';
import * as $ from 'jquery';
import { delay } from 'q';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';

@Component({
  selector: 'app-recharge-success',
  templateUrl: './recharge-success.component.html',
  styleUrls: ['./recharge-success.component.scss']
})
export class RechargeSuccessComponent implements OnInit {
  
  wallet: any;
  datas: any;

  constructor(private agentDashboardService: AgentDashboardService, private walletRecharge: RechargeSuccessService, private router: Router) { }

  ngOnInit() {
    this.walletBalance();
    this.checkUserTyper();
  }

  /**
   * To get wallet balance
   */
  walletBalance() {
    this.walletRecharge.getBalance().then((data: any) => {
      this.wallet = data.wallet.balance;
    });
  }

  /**
   * To check agent type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
}

