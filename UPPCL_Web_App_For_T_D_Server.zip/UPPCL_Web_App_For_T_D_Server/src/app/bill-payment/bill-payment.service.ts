import { Injectable, ComponentFactoryResolver } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class BillPaymentService {

    consumerNo: any;
    header:any;
    constructor(private http: HttpClient,private spinner:NgxSpinnerService) { }
    
    validateAccountForPaymentmPower(billId,todayDate,consumerNumber,token) 
    {
      this.header = {
        headers: new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Bearer ' + token
        })
      }

       var url =environment.validateAccountForPaymentApiFormPower+ billId +"/date/"+ todayDate + "/accountNumber/" +consumerNumber;;
      return new Promise(resolve => {
        this.http.get(url,this.header).subscribe(data => {
          resolve(data);
        });
      });
    }

    validateAccountForPaymentCcb(billId,todayDate,consumerNumber,token) 
    {
      this.header = {
        headers: new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Bearer ' + token
        })
      }

       var url =environment.validateAccountForPaymentApiForCcb+ billId +"/date/"+ todayDate + "/accountNumber/" +consumerNumber;
      console.log(url)
       return new Promise(resolve => {
        this.http.get(url,this.header).subscribe(data => {
          resolve(data);
        });
      });
    }

    getAgencyName(token) 
    {
      this.header = {
        headers: new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Bearer ' + token
        })
      }
  
      return new Promise(resolve => {
        this.http.get(environment.editAgentDetail+localStorage.getItem("agencyIdForagencyName"),this.header).subscribe(data => {
          resolve(data);
        });
      });
    }

    asyncCallOnit(token) {

        this.header = {
            headers: new HttpHeaders({
              'Content-Type': 'application/x-www-form-urlencoded',
              'Authorization': 'Bearer ' + token
            })
          }
          const URl = environment.editAgentDetail+localStorage.getItem('agentId');

        return new Promise(resolve => {
            this.http.get(URl,this.header).subscribe(datas => {
                resolve(datas);
            });
        });
    }

    sendMessage(agentFirstName,wallet,mobileNumber,token)
    {
        var payload = {
            "templateId": "LOW_BALANCE",
            "fields": [
            {
            "key": "firstName",
            "value": agentFirstName
            },
            {
            "key": "balance",
            "value": wallet
            },
            {
            "key": "phoneNo",
            "value": "9711787773"
            }
            ]
            };
            
           
        let promise = new Promise((resolve, reject) => {
            this.http.post(environment.sendPassword, payload,
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })                     
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        reject(msg);
                    })
        })
        return promise;
    }

    verifyOtp(OtpId,otp,token) {
        var payload = {
            "otpId":OtpId,
            "otp":otp
        };
        let promise = new Promise((resolve, reject) => {
            this.http.put(environment.verifyOtp, payload,
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })                     
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        reject(msg);
                    })
        })
        return promise;
    }



    ccbPostBill(name, billId,token,number,discom,division,payAmount) {

        var payloadData = {  
            "agentId":localStorage.getItem("agentId"),
            "amount":payAmount,
            "billId":billId,
            "consumerAccountId":this.consumerNo,
            "consumerName":name,
            "sourceType": "RAPDRP",
            "type":"RAPDRP",
            "vanNo":localStorage.getItem("van"),
            "walletId":"",
            "discom": discom,
            "division": division,
            "mobile": number
        };


        let promise = new Promise((resolve, reject) => {
            this.http.post(environment.billPost, payloadData,
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })                     
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        reject(msg);
                    })
        })
        return promise;
    }


    sendOtp(number:string,token) {
        var payload = {
            "phoneNo":number.trim()
        };
        let promise = new Promise((resolve,reject) => {
            this.http.post(environment.addOtp, payload,
                         {
                         headers: new HttpHeaders ({
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + token
                           })
                         }).toPromise().then((data : any)=>{
                              resolve(data);
                         },
                         msg => {
                             reject(msg);
                           }
                    )
          })
         return promise;
    }


    mPowerPostBill(amount, billId,name,token,number,discom,division) {

        var payload = {  
            "agentId":localStorage.getItem("agentId"),
            "amount":amount,
            "billId":billId,
            "consumerAccountId":this.consumerNo,
            "consumerName":name,
            "type":"NON_RAPDRP",
            "vanNo":localStorage.getItem("van"),
            "walletId":"",
            "discom": discom.split("-")[0],
            "division": division,
            "mobile": number,
         };

         console.log("mPower Payload" +JSON.stringify(payload));

        let promise = new Promise((resolve, reject) => {
            this.http.post(environment.billPost, payload,
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        reject(msg);
                    }
                )
            });
        return promise;
    }


    getDetails(Url,token) {
        this.header = {
            headers: new HttpHeaders({
              'Content-Type': 'application/x-www-form-urlencoded',
              'Authorization': 'Bearer ' + token
            })
          }


        return new Promise(resolve => {
            var url = Url;
            this.http.get(url,this.header).subscribe(datas => {
                resolve(datas);
            });
        });
    }

    fetchMpowerApi(consumerno,token) {
        this.consumerNo = consumerno;
         let promise = new Promise((resolve, reject) => {
            this.http.post(environment.billFetchApiFromMPower, {
                "accountNo": consumerno
            },
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        this.spinner.hide();
                        reject(msg);
                    }
                )
        });
            return promise;
    }

    callModal(message: string, title: string) {
        $(document).ready(function () {
          $("#h4").text(title);
          $("#modelText").text(message);
          $('#btnhide').click();
        })
      } 

    fetchCcbApi(consumerno,token) {

        this.consumerNo = consumerno;
        let promise = new Promise((resolve, reject) => {
            this.http.post(environment.billFetchApiFromCcb, {
                "accountNo": consumerno
            },
                {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })
                }).toPromise().then((data: any) => {
                    resolve(data);
                },
                    msg => {
                        if(msg.error.status == 500)
                        {
                            this.spinner.hide();
                            this.callModal("Technical issue. Please try again later","Alert")
                        }
                        reject(msg);
                    }
                )
        })
        return promise;
    }
}
