import { Component, OnInit, HostListener } from '@angular/core';
import { Form, FormGroup, FormsModule } from '@angular/forms';
import { BillPaymentService } from './bill-payment.service';
import { delay } from 'rxjs/operators';
// import * as $ from 'jquery';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DeviceDetectorService } from 'ngx-device-detector';
import { constant } from 'src/environments/constant';
declare var $: any;

@Component({
  selector: 'app-bill-payment',
  templateUrl: './bill-payment.component.html',
  styleUrls: ['./bill-payment.component.scss']
})

@Pipe({
  name: 'numberToWords'
})
export class BillPaymentComponent implements OnInit, PipeTransform {

  selectedValue: string = 'Select one';
  selectedDiscom: string = '';
  datas: any;
  token: any;
  wallet: any;
  data: any;
  consumerNames: any;
  billDate: any;
  outstandingBill: any;
  dueDate: any;
  payAmount: any;
  transStatus: string;
  transcationtime: any;
  consumernos: any;
  status: string;
  discom: string;
  division: string;
  consumerAccountId: any;
  year: string;
  billID: any;
  dates: string;
  mobileNumber: number;
  numberMobile: string;
  logo: string;
  otpSendMobileNumber: string;
  key: any; // need to be discussed with amit sir
  value: any; // need to be discussed with amit sir
  txId: string;
  van: string;
  otpId: any;
  message: boolean = false;
  recieptNo: any;
  transactionDate: string;
  area: string;
  printBy: any;
  Url: string;
  dateTimes: any;
  addressCity: string;
  addressState: string;
  mobileNo: any;
  helps: any; //not required in place of this we can use datas
  pending: boolean = false;
  success: boolean = false;
  mobile: boolean = false;
  payAmountInWords: string;
  totalDurationTime: number = 0;
  count: number = 0;
  subDivision: any;
  agentFirstName: any;

  agencyNameLabel: boolean = false;
  agencyName: any;
  amountPaid: any;
  consumerId: any;
  nameOfConsumer: any;
  numberOfPayer: any;

  rebateLabel:boolean= false;
  rebateAmount:any;

  a = [
    '',
    'one ',
    'two ',
    'three ',
    'four ',
    'five ',
    'six ',
    'seven ',
    'eight ',
    'nine ',
    'ten ',
    'eleven ',
    'twelve ',
    'thirteen ',
    'fourteen ',
    'fifteen ',
    'sixteen ',
    'seventeen ',
    'eighteen ',
    'nineteen '];

  b = [
    '',
    '',
    'twenty',
    'thirty',
    'forty',
    'fifty',
    'sixty',
    'seventy',
    'eighty',
    'ninety'];
  deviceInfo: any;
  isMobile: any;
  isDesktopDevice: any;
  config: any;
  isTablet;
  mobPrintBtn: boolean = false;
  webPrintBtn: boolean = false;

  constructor(private datePipe: DatePipe, private deviceService: DeviceDetectorService, private tokenGenerate: TokenGenerateService, private router: Router, private agentDashboardService: AgentDashboardService, private spinner: NgxSpinnerService, private http: HttpClient, private billService: BillPaymentService) { }


  checkUserTyper() {

    if (localStorage.getItem("isSubAgent") == "Yes") {
      this.agencyNameLabel = true;
      this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
        this.token = data;
        this.billService.getAgencyName(this.token.access_token).then((data: any) => {
          this.agencyName = data.agencyName;
        })
      })
      return;
    }
    else {
      this.agencyNameLabel = false;
    }
  }


  /**
   * 
   */
  showHide() {
    $(document).ready(function () {
      var form = <HTMLElement>(document.getElementById("showbill"));
      if (form.style.display == "block") {
        form.style.display = "none";
      }
      else {
        form.style.display = "block";
      }
    })
  }

  epicFunction() {
    // console.log('hello `Home` component');
    this.deviceInfo = this.deviceService.getDeviceInfo();
    this.isMobile = this.deviceService.isMobile();
    this.isTablet = this.deviceService.isTablet();
    this.isDesktopDevice = this.deviceService.isDesktop();
    console.log(this.deviceInfo);
    // console.log("mobile"+this.isMobile);  // returns if the device is a mobile device (android / iPhone / windows-phone etc)
    // console.log("istablet"+this.isTablet);  // returns if the device us a tablet (iPad etc)
    // console.log("desktop"+this.isDesktopDevice); // returns if the app is running on a Desktop browser.
    this.config = {
      itemsPerPage: 15,
      currentPage: 1,
    };
  }

  transform(value: any, args?: any): any {
    if (value) {
      let num: any = Number(value);
      if (num) {
        if ((num = num.toString()).length > 9) { return 'We are not the Iron Bank, you can lower down the stakes :)'; }
        const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) { return ''; }
        let str = '';
        str += (Number(n[1]) !== 0) ? (this.a[Number(n[1])] || this.b[n[1][0]] + ' ' + this.a[n[1][1]]) + 'crore ' : '';
        str += (Number(n[2]) !== 0) ? (this.a[Number(n[2])] || this.b[n[2][0]] + ' ' + this.a[n[2][1]]) + 'lakh ' : '';
        str += (Number(n[3]) !== 0) ? (this.a[Number(n[3])] || this.b[n[3][0]] + ' ' + this.a[n[3][1]]) + 'thousand ' : '';
        str += (Number(n[4]) !== 0) ? (this.a[Number(n[4])] || this.b[n[4][0]] + ' ' + this.a[n[4][1]]) + 'hundred ' : '';
        str += (Number(n[5]) !== 0) ? ((str !== '') ? 'and ' : '') +
          (this.a[Number(n[5])] || this.b[n[5][0]] + ' ' +
            this.a[n[5][1]]) + 'rupees only' : '';
        this.titleCase(str);
      } else {
        return '';
      }
    } else {
      return '';
    }
  }

  titleCase(str) {
    var splitStr = str.toLowerCase().split(' ');
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    this.payAmountInWords = splitStr.join(' ');
  }

  ngOnInit() {
    this.epicFunction();
    this.agentAuth();
    this.checkUserTyper();
    this.van = localStorage.getItem("van");
    $('#consumerno').focus(function () {
      $('div.showbill').hide();
    })
    $("select").change(function () {
      $('div.showbill').hide();
    })

    // show & hide bill
    $(document).ready(function () {
      var navListItems = $('div.setup-panel div a');
      var allWells = $('.setup-content');
      var allNextBtn = $('.nextBtn');
      allWells.hide();

      navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
          $item = $(this);
        if (!$item.hasClass('btn-circle')) {
          $item.addClass('btn-circle').removeClass('btn-default');
          allWells.hide();
          $target.show();
          $target.find('input:eq(0)').focus();
        }
        else {
          allWells.hide();
          $target.show();
          $target.find('input:eq(0)').focus();
        }
      });

      allNextBtn.click(function () {
        var curStep = $(this).closest(".setup-content"),
          curStepBtn = curStep.attr("id"),
          nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
          curInputs = curStep.find("input[type='text'],input[type='url']"),
          isValid = true;

        $(".form-group").removeClass("has-error");
        for (var i = 0; i < curInputs.length; i++) {
          if (!((curInputs[i] as HTMLInputElement).validity.valid)) {
            isValid = false;
          }
          $(curInputs[i]).closest(".form-group").addClass("has-error");
        }
        if (isValid) {
          nextStepWizard.removeAttr('disabled').trigger('click');
          if (curStepBtn == 'exampleModalCenter') {
            nextStepWizard = $('div.setup-panel div a[href="#' + "step-2" + '"]').parent().children("a");
            nextStepWizard.removeAttr('disabled').trigger('click');
            $('#showbill').hide();
          }
        }
      });
      $('div.setup-panel div a.btn-circle').trigger('click');
    });

  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /**
   * Continue button clicked.
   */
  btnContinue() {
    this.selectedValue = "Select one";
    (document.getElementById("consumerno") as HTMLInputElement).value = "";
    $('#step-1').show();
    $('#step-2').hide();
    $('#step-3').hide();
    $('div.setup-panel div a[href="#' + "step-3" + '"]').removeClass("btn-circle");
    $('div.setup-panel div a[href="#' + "step-2" + '"]').removeClass("btn-circle");
    var nextStepWizard = $('div.setup-panel div a[href="#' + "step-1" + '"]').parent().children("a");
    nextStepWizard.removeAttr('disabled').trigger('click');
    $('#showbill').hide();
  }

  /**
   * Method is used to fetch the data from mPower as well as CCB api
   * @param consumerno number
   */
  callService(consumerno) {
    this.spinner.show();
    if (this.selectedValue == "" || this.selectedValue == "Select one") {
      this.spinner.hide();
      this.callModal("Please enter all required field(s).", "Alert");
    }
    else {
      if (this.selectedValue == "RAPDRP") {
        if (consumerno.length != 10) {
          this.spinner.hide();
          this.callModal("Please enter correct account number.", "Alert");
        }
        else {
          this.rebateLabel = false;
          this.tokenGenerate.getToken(environment.ccbFetchToken).then(data => {
            this.data = data;
            this.billService.fetchCcbApi(consumerno, this.data.access_token).then(data => {
              this.datas = data;
              this.spinner.hide();
              if (JSON.stringify(this.datas).includes('Required Field Account Id is Invalid in Request')) {
                this.spinner.hide();
                this.callModal("Please enter correct account number.", "Alert");
              }
              else if (JSON.stringify(this.datas).includes('Service Error')) {
                this.spinner.hide();
                this.callModal("Please enter correct account number.", "Alert");
              }
              else if (this.datas.Body.PaymentDetailsResponse.AccountInfo <= 0) {
                this.callModal("No Bill Due.", "Alert");
              }
              else {
                if (JSON.stringify(this.datas).includes("Division")) {
                  this.spinner.hide();
                  this.showHide();
                  this.consumerNames = this.datas.Body.PaymentDetailsResponse.ConsumerName;
                  this.division = this.datas.Body.PaymentDetailsResponse.Division;
                  this.discom = this.datas.Body.PaymentDetailsResponse.Discom.split("-")[0];
                  this.year = this.datas.Body.PaymentDetailsResponse.BillDueDate.split("-")[2];
                  this.outstandingBill = this.datas.Body.PaymentDetailsResponse.AccountInfo;
                  this.subDivision = this.datas.Body.PaymentDetailsResponse.SubDivision;
                  this.dueDate = this.datas.Body.PaymentDetailsResponse.BillDueDate;
                  this.payAmount = this.datas.Body.PaymentDetailsResponse.AccountInfo;
                  this.billDate = this.datas.Body.PaymentDetailsResponse.BillDate;
                  this.payAmount = Math.round(this.payAmount);
                  this.setAddress();
                  this.status = "PENDING";
                  this.consumernos = consumerno;
                  var today = new Date();
                  this.mobileNumber = this.datas.Body.PaymentDetailsResponse.MobileNumber;

                  this.dateTime();
                  this.billID = this.datas.Body.PaymentDetailsResponse.BillID;
                }
                else {
                  this.spinner.hide();
                  this.callModal("Due to some problem server is not responding.", "Alert");
                }
              }
            });
          })
        }
      }
      else {
        if ((consumerno.length != 12)) {
          this.spinner.hide();
          this.callModal("Please enter correct consumer number.", "Alert");
        }
        else {
          this.tokenGenerate.getToken(environment.mPowerFetchToken).then(data => {
            this.data = data;
            this.billService.fetchMpowerApi(consumerno, this.data.access_token).then(data => {
              this.datas = data;
              for (var key in this.datas) {
                this.datas[key] = this.datas[key].toString().trim()
                this.key = key;
                this.value = this.datas[key];
              }
              if (this.datas[key] == 201) {
                this.spinner.hide();
                this.callModal("No Bill Due.", "Alert");
              }
              else if (this.datas[key] == 202) {
                this.spinner.hide();
                this.callModal("Please enter correct account number.", "Alert");
              }
              else {
                if (JSON.stringify(this.datas).includes("DIVISION_NAME")) {
                  this.rebateLabel = true;
                  this.spinner.hide();
                  this.showHide();
                  this.datas = data;
                  this.consumerNames = this.datas.NAME;
                  this.division = this.datas.DIVISION_NAME;
                  this.discom = this.datas.DISCOMENAME;
                  this.year = this.datas.BILLMONTH.split("/")[1];
                  this.billDate = this.datas.BILLMONTH.split("/")[0];
                  this.billDate = parseInt(this.billDate);
                  this.rebateAmount = this.datas.REBATE;
                  this.billMonth(this.billDate);
                  this.setAddress();
                  this.mobileNumber = null;
                  this.outstandingBill = this.datas.OUTSTANDING_AMT;
                  this.dueDate = this.datas.BILLDUEDATE.split(" ")[0];
                  this.payAmount = this.datas.AMOUNT;
                  this.payAmount = Math.round(this.payAmount);
                  this.billID = this.datas.BILLNUMBER;
                  let status = this.datas.PAYSTATUS;
                  this.dateTime();
                  if (status == 'N') {
                    this.status = "PENDING";
                  }
                  else {
                    this.status = status;
                  }
                  this.consumernos = consumerno;
                }
                else {
                  this.spinner.hide();
                  this.callModal("Due to some problem server is not responding.", "Alert");
                }
              }
            });
          })

        }
      }
    }
  }


  setAddress() {
    var discomName = this.discom;
    switch (discomName) {
      case ('MVVNL'):
        {
          this.addressCity = '4A, Gokhale Marg';
          this.addressState = 'Lucknow, Uttar Pradesh';
          this.logo = "../assets/image/mvvnl.jpeg"
          break;
        }
      case ('PVVNL'):
        {
          this.addressCity = 'Urja Bhawan, Victoria Park';
          this.addressState = 'Meerut, Uttar Pradesh';
          this.logo = "../assets/image/pvvnl.jpg"
          break;
        }
      case ('DVVNL'):
        {
          this.addressCity = 'Urja Bhavan, Sikandra';
          this.addressState = 'Agra, Uttar Pradesh';
          this.logo = "../assets/image/dvvnl.jpg"
          break;
        }
      default:
        {
          this.addressCity = 'DLW Bhikharipur';
          this.addressState = 'Varanasi, Uttar Pradesh';
          this.logo = "../assets/image/puvnnl.jpeg"
          break;
        }
    }

  }

  //bill receipt for web & device
  billprintfunction() {
    if (this.isDesktopDevice) {
      $('#step-3').trigger('click');
    }
    else
    //is mobile
    {
      $('#printshow').trigger('click');

    }
  }




  /**
   * Method is used to verify otp
   */
  onNext() {
    var otp = (<HTMLInputElement>document.getElementById("otp")).value;
    var val = (<HTMLInputElement>document.getElementById("btnnnnn")).value;
    this.tokenGenerate.getToken(environment.updateOtpStatusToken).then(data => {
      this.data = data;
      this.billService.verifyOtp(this.otpId, otp, this.data.access_token).then(data => {
        $("#otp").val("");
        if (data) {
          this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
            this.data = data;
            this.billService.asyncCallOnit(this.data.access_token).then((data: any) => {
              this.wallet = data.balanceAmount;
              this.wallet = this.wallet.toFixed(2);
              this.agentFirstName = localStorage.getItem("firstName") + " " + localStorage.getItem("lastName") + " " + "(" + localStorage.getItem("van") + ")";
              $('#btncenterhidee').trigger('click');
            });
          })
        }
        else {
          $('#step-2').hide();
          $('#step-3').hide();
          $('#step-1').show();
          $('div.showbill').show();
          $('#exampleModalCenter').show();
          this.message = true;
        }
      })
    })
  }

  sendOtpBtn() {

    this.numberMobile = (<HTMLInputElement>document.getElementById("txtMobileNumber")).value.trim();
    if (this.numberMobile.length == 10) {
      var startMobile = ((parseInt(this.numberMobile) / 100000000).toString()).split(".")[0];
      var endMobile = parseInt(this.numberMobile) % 100;
      this.otpSendMobileNumber = startMobile + 'XXXXXX' + endMobile;
      $(document).ready(function () {
        $('#btnMobileNumber').click();
      });
      this.mobile = false;
      this.message = false;
      this.centerOtpModal();
      this.getOtp();
    }
    else {
      this.mobile = true;
    }
  }

  onReturn() {
    (document.getElementById("txtMobileNumber") as HTMLInputElement).value = " ";
  }


  /**
   * delay is used to delay any method for specific time.
   * @param ms in mili seconds
   */
  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => { });
  }

  /*
  @author manoj 
  This method is used to open the pop up menu 
  @param
  message 
  */
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  /**
   * To check if agent is having mobile number in data or not
   */
  // verifyOtp() {
  //   if (parseInt(this.outstandingBill) > 0) {
  //     (document.getElementById("txtMobileNumber") as HTMLInputElement).value = " ";
  //     $(document).ready(function () {
  //       $('#btnMobileNumber').click();
  //     })
  //   }
  //   else {
  //     this.callModal("No Bill Due.", "Alert");
  //   }
  // }

  verifyOtp() {
    if (parseInt(this.outstandingBill) > 0) {
      var todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd', 'es-ES');
      if(this.consumernos.length == 12) {
      this.tokenGenerate.getToken(environment.validateAccountForPaymentFormPowerApiToken).then(data => {
      this.data = data;
        this.billService.validateAccountForPaymentmPower(this.billID,todayDate,this.consumernos,this.data.access_token).then((data: any) => {
          if (data.length > 0 && (data[0].status.toUpperCase() == 'S' || data[0].status.toUpperCase() == 'P')) {
            this.callModal(constant.billAlreadyPaid,constant.alertError);
            return;
          }
          else {
            (document.getElementById("txtMobileNumber") as HTMLInputElement).value = " ";
            $(document).ready(function () {
              $('#btnMobileNumber').click();
            })
          }
        })
      })
      return;
    }
    else {
      this.tokenGenerate.getToken(environment.validateAccountForPaymentForCcbApiToken).then(data => {
        this.data = data;
          this.billService.validateAccountForPaymentCcb(this.billID,todayDate,this.consumernos,this.data.access_token).then((data: any) => {
            if (data.length > 0 && (data[0].UpdateStatus.toUpperCase() == 'SUCCESS' || data[0].UpdateStatus.toUpperCase() == 'PENDING')) {
              this.callModal(constant.billAlreadyPaid,constant.alertError);
              return;
            }
            else {
              (document.getElementById("txtMobileNumber") as HTMLInputElement).value = " ";
              $(document).ready(function () {
                $('#btnMobileNumber').click();
              })
            }
          })
        })
        return;
    }
  }
    else {
      this.callModal("No Bill Due.", "Alert");
      return;
    }
  
  }

  /**
   * if agent is not having registered mobile number then this method is called.
   */
  navigate() {
    $('#step-1').hide();
    $('#showbill').hide();
    $('#step-2').show();

    var nextStepWizard = $('div.setup-panel div a[href="#' + "step-2" + '"]').parent().children("a");
    nextStepWizard.removeAttr('disabled').trigger('click');

    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.data = data;
      this.billService.asyncCallOnit(this.data.access_token).then((data: any) => {
        this.wallet = data.balanceAmount;
        this.wallet = this.wallet.toFixed(2);
        this.transform(this.payAmount);
        this.agentFirstName = localStorage.getItem("firstName");
        // $('#btncenterhidee').trigger('click');
      });
    })
    // this.tokenGenerate.getToken(environment.apiWalletAgentToken).then(data => {
    //   this.data = data;
    //   this.billService.asyncCallOnit(this.data.access_token).then((data: any) => {
    //     this.wallet = data.wallet.balance;
    //     this.wallet = this.wallet.toFixed(2);
    //     localStorage.setItem("walletid", data.wallet.walletId);
    //   });
    // })
  }

  /**
   * Method to get Otp Id
   */
  getOtp() {
    this.tokenGenerate.getToken(environment.addotpToken).then(data => {
      this.token = data;
      this.billService.sendOtp(this.numberMobile, this.token.access_token).then(data => {
        this.otpId = JSON.stringify(data);
      });
    })
  }

  /**
   * Method to show Otp Modal
   */
  centerOtpModal() {
    $(document).ready(function () {
      $('#btncenterhide').click();
    })
  }

  /**
   * Method to convert data in dd-mm-yyyy 
   * Convert time in hh:mm:ss
   */
  dateTime() {
    var today = new Date();
    var mm = "" + (today.getMonth() + 1);
    var dd = "" + today.getDate();
    if (parseInt(mm) < 10) {
      mm = "0" + mm;
    }
    if (parseInt(dd) < 10) {
      dd = "0" + dd;
    }
    var date = today.getFullYear() + '-' + mm + '-' + dd;
    this.dates = dd + '-' + mm + '-' + today.getFullYear();

    var hours = "" + today.getHours();
    if (parseInt(hours) < 10) {
      hours = "0" + hours;
    }
    var minutes = "" + today.getMinutes();
    if (parseInt(minutes) < 10) {
      minutes = "0" + minutes;
    }
    var seconds = "" + today.getSeconds();
    if (parseInt(seconds) < 10) {
      seconds = "0" + seconds;
    }
    var time = hours + ":" + minutes + ":" + seconds;
    var dateTime = this.dates + ' ' + time;
    this.transcationtime = dateTime;
  }


  /**
   * Method is called when agent is paying.
   */
  onDebit() {
    //for device mini slip
    if (this.isDesktopDevice) {
      this.webPrintBtn = true;
    }
    else
    //is mobile
    {
      this.mobPrintBtn = true;
    }

    if (parseInt(this.payAmount) > parseInt(this.wallet)) {
      $('#step-1').hide();
      $('#showbill').hide();
      $('#step-2').show();
      var nextStepWizard = $('div.setup-panel div a[href="#' + "step-2" + '"]').parent().children("a");
      nextStepWizard.removeAttr('disabled').trigger('click');
      this.callModal("Your wallet balance is low. Please Recharge your wallet !", "Unsuccessful");
      this.tokenGenerate.getToken(environment.notifyUserToken).then(data => {
        this.data = data;
        this.billService.sendMessage(this.agentFirstName, this.wallet, this.numberMobile, this.data.access_token).then(data => {
          JSON.stringify(data);
        })
      })
      return false;
    }
    else {


      if (this.consumernos.length == 12) {

        $('#step-1').hide();
        $('#showbill').hide();
        $('#step-2').hide();
        $('#step-3').show();
        var nextStepWizard = $('div.setup-panel div a[href="#' + "step-3" + '"]').parent().children("a");
        nextStepWizard.removeAttr('disabled').trigger('click');
        this.tokenGenerate.getToken(environment.billPostToken).then(data => {
          this.data = data;
          console.log(data);
          this.billService.mPowerPostBill(this.payAmount, this.billID, this.consumerNames, this.data.access_token, this.numberMobile, this.discom, this.division).then(data => {
            this.datas = data;
            if (JSON.stringify(this.datas).includes('/v1/event')) {
              this.Url = this.datas.location;
              this.toCheckResponseOfmPower(this.Url);
            }
            else {
              this.callModal("There is some problem in server.Please try later.", "Alert");
              this.transStatus = 'Failed';
            }
          })
        })
      }
      else {
        $('#step-1').hide();
        $('#showbill').hide();
        $('#step-2').hide();
        $('#step-3').show();
        var nextStepWizard = $('div.setup-panel div a[href="#' + "step-3" + '"]').parent().children("a");
        nextStepWizard.removeAttr('disabled').trigger('click');

        this.tokenGenerate.getToken(environment.billPostToken).then(data => {
          this.data = data;
          this.billService.ccbPostBill(this.consumerNames, this.billID, this.data.access_token, this.numberMobile, this.discom, this.division, this.payAmount).then(data => {
            this.datas = data;
            if (JSON.stringify(this.datas).includes('/v1/event')) {
              this.Url = this.datas.location;
              this.toCheckResponse(this.Url);
            }
            else {
              this.callModal("There is some problem in server.Please try later.", "Alert");
              this.transStatus = 'Failed';
            }
          })
        })
      }





    }
  }

  /**
   * To get response of transaction
   * @param url string
   */
  toCheckResponseOfmPower(url) {
    this.count = 0;
    this.delay(1000).then(any => {
      this.tokenGenerate.getToken(environment.eventToken).then(data => {
        this.data = data;
        this.billService.getDetails(environment.event + url, this.data.access_token).then(data => {
          this.datas = data;
          if (JSON.stringify(this.datas).includes("response")) {
            this.totalDurationTime = 0;
            this.pending = false;
            this.success = true;
            if (this.datas.status != "FAILED") {
              this.txId = this.datas.response[0].transactionId;
              this.recieptNo = this.datas.response[0].receiptNo;
            }
            this.mobileNo = this.datas.payload.mobile;
            this.transStatus = this.datas.status;
            this.transactionDate = this.datas.date;
            this.amountPaid = this.datas.payload.amount;
            this.consumerId = this.datas.payload.consumerAccountId;
            this.nameOfConsumer = this.datas.payload.consumerName;
            this.numberOfPayer = this.datas.payload.mobile;

            this.area = this.datas.payload.sourceType;
            if(this.area == "RAPDRP") {
              this.area = this.area + " " + "(URBAN)";
            }
            else
            {
              this.area = this.area + " " + "(RURAL)";
            }

            this.transform(this.amountPaid);
            this.printBy = localStorage.getItem("firstName") + " " + localStorage.getItem("lastName") + " (" + localStorage.getItem("van") + ")";
            this.consumerAccountId = this.datas.payload.consumerAccountId;
            $("#transactionStatus").text(this.transStatus).css("color", "green");
            this.showStatusPayment();
          }
          else {
            if (this.totalDurationTime < 30) {
              this.pending = true;
              this.success = false;
              this.transactionDate = this.datas.date;
              this.transStatus = "Transaction is in progress";

              $('.blink').fadeOut(500);
              $('.blink').fadeIn(500);
              this.delay(2000).then(any => {
                $('.blink').fadeOut(500);
                $('.blink').fadeIn(500);
                $('.blink').fadeOut(500);
                $('.blink').fadeIn(500);
                this.totalDurationTime = this.totalDurationTime + 3;
                this.toCheckResponseOfmPower(url);
              })
            }
            else {
              this.pending = true;
              this.success = false;
              this.transactionDate = this.datas.date;
              this.transStatus = "Transaction is in progress";
              this.callModal("Transaction is taking more time. Please check status after some time in Ledger.", "Alert");
            }
          }
        })
      })
    })
  }

  /**
   * Recursively call of this Method for 30 second.
   * With blinking transaction status
   * @param url string
   */
  toCheckResponse(url) {
    this.count = 0;
    this.delay(1000).then(any => {
      this.tokenGenerate.getToken(environment.eventToken).then(data => {
        this.data = data;
        this.billService.getDetails(environment.event + url, this.data.access_token).then((help: any) => {
          this.helps = help;
          if (JSON.stringify(this.helps).includes("response")) {
            this.totalDurationTime = 0;
            this.responseForCcb();
          }
          else {
            this.pending = true;
            this.success = false;
            this.transStatus = "Transaction is in progress";
            if (this.totalDurationTime < 30) {
              $('.blink').fadeOut(500);
              $('.blink').fadeIn(500);
              this.delay(2000).then(any => {
                $('.blink').fadeOut(500);
                $('.blink').fadeIn(500);
                $('.blink').fadeOut(500);
                $('.blink').fadeIn(500);
                this.totalDurationTime = this.totalDurationTime + 3;
                this.toCheckResponse(url);
              })
            }
            else {
              this.pending = true;
              this.success = false;
              this.transactionDate = this.helps.date;
              this.transStatus = "Transaction is in progress";
              this.callModal("Transaction is taking more time. Please check status after some time in Ledger.", "Alert");
            }
          }
        })
      })
    })
  }


  /**
   * Response from CCB 
   */
  responseForCcb() {
    this.success = true;
    this.pending = false;
    this.mobileNo = this.helps.payload.mobile;
    if (this.helps.status != "FAILED") {
      this.txId = this.helps.response[0].transactionId;
      this.recieptNo = this.helps.response[0].receiptNo;
    }
    this.transStatus = this.helps.status;
    this.amountPaid = this.helps.payload.amount;
    this.transform(this.amountPaid);
    this.transactionDate = this.helps.date;
    this.area = this.helps.payload.sourceType;
    if(this.area == "RAPDRP") {
      this.area = this.area + " " + "(URBAN)";
    }
    else
    {
      this.area = this.area + " " + "(RURAL)";
    }
    this.consumerId = this.helps.payload.consumerAccountId;
    this.nameOfConsumer = this.helps.payload.consumerName;
    this.numberOfPayer = this.helps.payload.mobile;

    $("#transactionStatus").text(this.transStatus);
    this.showStatusPayment();
    // this.txId = this.helps.response.transactionId;
    // this.mobileNo = this.helps.payload.mobile;
    // this.txId = this.helps.response[0].transactionId;
    // this.recieptNo = this.helps.response[0].receiptNo;
    // this.transStatus = this.helps.status;
    // this.transactionDate = this.helps.date;
    // $("#transactionStatus").text(this.transStatus);
    // this.showStatusPayment();

  }

  /**
   * Method will called from mPower && Ccb service
   */
  showStatusPayment() {
    switch (this.transStatus.toUpperCase()) {
      case "FAILED":
        this.callModal("Due to some problem. Bill Payment Unsuccessful.", "Failed");
        break;
      case "TRANSACTION IS IN PROGRESS":
        this.callModal("Transaction is in progress. Please check after sometime in ledger.", "Alert");
        break;
      case "SUCCESS":
        this.callModal("Bill Payment Successful !", "Successful");
        break;
      default:
        this.callModal("There is problem in server. Please try after sometime.", "Alert");
        break;
    }
  }

  /**
   * Method to convert month from number to string.
   * @param month 
   */
  billMonth(month) {

    switch (month) {
      case 1:
        this.billDate = "January" + " " + this.year;
        break;
      case 2:
        this.billDate = "Febuary" + " " + this.year;
        break;
      case 3:
        this.billDate = "March" + " " + this.year;
        break;
      case 4:
        this.billDate = "April" + " " + this.year;
        break;
      case 5:
        this.billDate = "May" + " " + this.year;
        break;
      case 6:
        this.billDate = "June" + " " + this.year;
        break;
      case 7:
        this.billDate = "July" + " " + this.year;
        break;
      case 8:
        this.billDate = "August" + " " + this.year;
        break;
      case 9:
        this.billDate = "September" + " " + this.year;
        break;
      case 10:
        this.billDate = "Octuber" + " " + this.year;
        break;
      case 11:
        this.billDate = "November" + " " + this.year;
        break;
      case 12:
        this.billDate = "December" + " " + this.year;
        break;
    }
  }

}

