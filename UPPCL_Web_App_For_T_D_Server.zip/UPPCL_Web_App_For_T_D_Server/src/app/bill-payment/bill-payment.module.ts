import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { HeaderComponent  } from '../header/header.component';
// import { FooterComponent  } from '../footer/footer.component';
import { BillPaymentComponent } from './bill-payment.component';
import { BillPaymentRoutingModule } from './bill-payment-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import {NgxPrintModule} from 'ngx-print';
import { NgxSpinnerModule } from "ngx-spinner";
import { DatePipe } from '@angular/common';
import { DeviceDetectorModule } from 'ngx-device-detector';

@NgModule({
  declarations: [BillPaymentComponent],
  imports: [
    NgxPrintModule,
    CommonModule,
    BillPaymentRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxSpinnerModule,
    DeviceDetectorModule.forRoot()
  ],
  providers: [DatePipe]
})
export class BillPaymentModule { }
