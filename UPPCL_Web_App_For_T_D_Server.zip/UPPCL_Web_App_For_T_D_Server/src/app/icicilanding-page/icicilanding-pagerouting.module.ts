import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IcicilandingPageComponent } from './icicilanding-page.component';
import { Routes,RouterModule} from '@angular/router';
import { RechargeWalletComponent } from '../recharge-wallet/recharge-wallet.component';


const route:Routes=[

  { path:'pgResponse/:status/:txnref/:amt/:paymode/:txntime',component:IcicilandingPageComponent }
  //  { path:'recharge-wallet',component:RechargeWalletComponent }
]


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)  
  ]

})
export class IcicilandingPageroutingModule { }
