import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxSpinnerModule } from "ngx-spinner";
import { IcicilandingPageComponent } from './icicilanding-page.component';
import { IcicilandingPageroutingModule } from './icicilanding-pagerouting.module';
import { NgForm, FormsModule, Form } from '@angular/forms';

@NgModule({
  declarations: [IcicilandingPageComponent],
  imports: [
    IcicilandingPageroutingModule,
    CommonModule,
    FormsModule,
    NgxSpinnerModule
  ]
})
export class IcicilandingPageModule { }
