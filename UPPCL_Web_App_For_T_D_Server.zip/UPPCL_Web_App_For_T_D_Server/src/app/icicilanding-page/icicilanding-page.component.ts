import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { RechargeWalletService } from '../recharge-wallet/recharge-wallet.service';
import { ActivatedRoute, Router } from '@angular/router';
import { validation } from '../../environments/validationsMessage';
import {environment} from '../../environments/environment';
import {TokenGenerateService} from '../token-generate.service';

@Component({
  selector: 'app-icicilanding-page',
  templateUrl: './icicilanding-page.component.html',
  styleUrls: ['./icicilanding-page.component.scss']
})
export class IcicilandingPageComponent implements OnInit {
  wallet: any;
  success: any = false;
  fail: any = false;
  rechargeAmount: any;
  status: any;
  txnRef: any;
  payMode: any;
  txnTime: any;
  amount: any;
  role: any;
  challan: any = false;
  datas:any;
vanNumber:any;
  constructor(private tokenGenerate:TokenGenerateService,private walletRecharge: RechargeWalletService, private router: Router, private _route: ActivatedRoute, private spinner: NgxSpinnerService, private agentDashboardService: AgentDashboardService) { }
  ngOnInit() {
    this.agentAuth();
    if (this.role != "AGENT" || this.role != "AGENCY") {

      // alert('something went wrong');

      //this.callModal('something went wrong');
      //window.location.href = '/login';

    }

    /*
      This method is used to restrict to referesh page
      */
    if (performance.navigation.type == 1) {

      // event.preventDefault();
      //return false;
      //this.callModal('You refreshed the page. Please re-login.');
      alert('You refreshed the page. Please retry.');

      if (this.role == "AGENT") {
        this.router.navigate(['/agent-dashboard']);
        // window.location.href = '/agent-dashboard';
      }
      else {
        this.router.navigate(['/agency-dashboard']);
        //window.location.href = '/agency-dashboard';
      }
    }

    /*
    This method is used to navigate to restrict the user to press any key
    */
    function preventBack() {
      window.history.forward();
    }
    setTimeout("preventBack()", 0);
    window.onunload = function () { null };

    $(document).ready(function () {
      $(function () {
        $(this).bind("contextmenu", function (e) {
          e.preventDefault();
        });
      });

      history.pushState(null, document.title, location.href);
      preventBack();
      $(window).keydown(function (event) {
        if (event.keyCode == 116 || event.altKey || event.ctrlKey || event.shiftKey) {
          event.preventDefault();
          return false;
        }
      });
    });
    /*
    This set of lines ae reading url value
    */
    this.role = localStorage.getItem('role');
    this.status = this._route.snapshot.paramMap.get('status');
    this.txnRef = this._route.snapshot.paramMap.get('txnref');
    this.amount = this._route.snapshot.paramMap.get('amt');
    this.payMode = this._route.snapshot.paramMap.get('paymode').replace('_', " ").replace('_', " ");
    this.txnTime = this._route.snapshot.paramMap.get('txntime').replace('+', ' ');
    this.vanNumber = localStorage.getItem("van");
    if (this.status == "Success") {
      this.success = true;
      const agentID = localStorage.getItem("van");
      this.spinner.show()
      setTimeout(() => {
          this.tokenGenerate.getToken(environment.transactionCreditToken).then(token => {
            this.datas = token;
          this.walletRecharge.rechargeWalletFromIciciLanding(this.amount,this.datas.access_token,this.txnRef).then(data => {
          })
        })
        /** spinner ends after 5 seconds */
        this.spinner.hide();
      }, 1000);
    }
    else if (this.status == "Fail") {
      this.fail = true;
      this.spinner.show()
      setTimeout(() => {
        this.spinner.hide();
        //this.router.navigate(['/paymentgateway-landingpage']);
        /** spinner ends after 5 seconds */
      }, 1000);
    }

    else if (this.status == "Generated") {
      this.success = false;
      this.fail = false;
      this.challan = true;
    }

    else {
      this.challan = false;
      this.success = false;
      this.fail = false;
      this.router.navigate(['/login']);
    }
  }

  /*
  This method is used to authenticate the user
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data: any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /*
  This method is used to navigate to user according to roles
  */
  routeToRechargeWallet() {
    if (this.role == "AGENT") {
      this.router.navigate(['/recharge-wallet']);
    }
    else if (this.role == "AGENCY")
      this.router.navigate(['/agency-wallet']);

    else {
      this.callModal(validation.somethingWentWrongMessage);
      this.router.navigate(['/login']);

    }
  }
  /*
    This method is used to navigate to user according to roles after challan
    */
  routeToDashboardAfterChallan() {
    if (this.role == "AGENT") {
      this.router.navigate(['/agent-dashboard']);
    }
    else if (this.role == "AGENCY")
      this.router.navigate(['/agency-dashboard']);
    else {
      this.callModal(validation.somethingWentWrongMessage);
      this.router.navigate(['/login']);
    }

  }
  /*
  This method is used to navigate to user according to roles after challan
  */
  routeToRechargeWalletAfterChallan() {
    if (this.role === "AGENT") {
      this.router.navigate(['/recharge-wallet']);
    }
    else if (this.role === "AGENCY")
      this.router.navigate(['/agency-wallet']);
    else {
      this.callModal(validation.somethingWentWrongMessage);
      this.router.navigate(['/login']);
    }
  }

  /*
    This method is used to navigate to user according to roles after failure
    */
  routeToRechargeWalletAfterFailure() {

    if (this.role == "AGENT") {
      this.router.navigate(['/recharge-wallet']);
    }
    else if (this.role == "AGENCY")
      this.router.navigate(['/agency-wallet']);

    else {
      this.callModal(validation.somethingWentWrongMessage);
      this.router.navigate(['/login']);
    }

  }
  /*
    This method is used to navigate to user according to roles
    */
  routeToDashboard() {

    if (this.role == "AGENT") {
      this.router.navigate(['/agent-dashboard']);
    }
    else if (this.role == "AGENCY")
      this.router.navigate(['/agency-dashboard']);

    else {
      this.callModal("Something went wrong.");
      this.router.navigate(['/login']);
    }
  }
  /*
  This method is used to navigate to user according to roles after failure
  */

  routeToDashboardAfterFailure() {
    if (this.role == "AGENT") {
      this.router.navigate(['/agent-dashboard']);
    }
    else if (this.role == "AGENCY")
      this.router.navigate(['/agency-dashboard']);

    else {
      this.callModal("Something went wrong.");
      this.router.navigate(['/login']);

    }
  }

  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }


  /*
  This method is used to recharge wallet
  */
  rechargeWallet() {

    this.rechargeAmount = localStorage.getItem("rechargeAmount");

    if (this.rechargeAmount == "") {
      //this.callModal('something went wrong');
    }
    else {
      this.walletRecharge.recharge("1").then(data => {
        if (data == null) {
          //this.callModal("Somthing went wrong.If money is deducted,it will be credited to your account within 48 hours.");
          //  this.router.navigate(['/recharge-success']);
        }
        else {

          //this.callModal('Recharge successful');

        }
      })
    }
  }
}