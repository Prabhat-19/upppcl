import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcicilandingPageComponent } from './icicilanding-page.component';

describe('IcicilandingPageComponent', () => {
  let component: IcicilandingPageComponent;
  let fixture: ComponentFixture<IcicilandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcicilandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcicilandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
