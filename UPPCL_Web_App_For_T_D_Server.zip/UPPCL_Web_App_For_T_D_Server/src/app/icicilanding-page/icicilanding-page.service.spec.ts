import { TestBed } from '@angular/core/testing';

import { IcicilandingPageService } from './icicilanding-page.service';

describe('IcicilandingPageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IcicilandingPageService = TestBed.get(IcicilandingPageService);
    expect(service).toBeTruthy();
  });
});
