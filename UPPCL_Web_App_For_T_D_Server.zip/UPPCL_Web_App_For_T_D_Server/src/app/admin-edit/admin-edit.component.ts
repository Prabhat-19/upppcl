import { Component, OnInit,HostListener } from '@angular/core';
import { AdminEditService } from '../admin-edit/admin-edit.service';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import {NgxSpinnerService} from 'ngx-spinner';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';

declare var $: any

@Component({
  selector: 'app-admin-edit',
  templateUrl: './admin-edit.component.html',
  styleUrls: ['./admin-edit.component.scss']
})
export class AdminEditComponent implements OnInit {

  Results: any;
  Agent_ID: any;
  radiobtn: any;
  datas: any;

  constructor(private spinner:NgxSpinnerService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private router: Router, private adminEdit: AdminEditService) { }

  ngOnInit() {
    $('#ApprovalRequest').css('color', 'white');
    this.checkUserTyper();
    this.agentAuth();
    this.activeTab();
    var controls = $('.personalForm :input');
    controls.each(function (index, value) {
      $(this).prop('disabled', true);
      $('select').css('background-color', '#ebebe4')
    })
    this.edit();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /**
   * Method to check user Type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * Edit
   */
  edit() {
    this.spinner.show();
    var id = localStorage.getItem("adminId");
    this.tokenGenerate.getToken(environment.agentRequestToken).then(data => {
      this.datas = data;
    this.adminEdit.edit(id,this.datas.access_token).then(data => {
      this.Results = data;
      this.disableButton();
      if (this.Results.gstin != "" && this.Results.gstin != undefined ) {
        $("#yesanswer").show();
        this.radiobtn = document.getElementById("yes");
        this.radiobtn.checked = true;
      }
      else {
        this.radiobtn = document.getElementById("no");
        this.radiobtn.checked = true;
        $("#yesanswer").hide();
      }
     
      this.Results.documents.forEach(element => {
        (<HTMLInputElement>document.getElementById(element.type)).innerHTML 
        = "<a href='" +element.location + "'>View Document</a>";
      });
    })
  })
  this.spinner.hide();
  }

  /**
   * Method for Approval process.
   * NAvigate to admin-approval.
   */
  onApprove() {
      this.tokenGenerate.getToken(environment.getRejectToken).then(data => {
        this.datas = data;
      this.adminEdit.getApproval(this.Agent_ID,this.datas.access_token).then(data => {
        this.router.navigate(['/admin-approval']);
      });
    })
  }

  /**
   * Method for rejecting agent
   * Modal will appear for confirmation
   */
  onReject() {
    var remarkValue = (<HTMLInputElement>document.getElementById("remark")).value;
    if (remarkValue == "") {
      this.callModal("Please enter remark before rejection.", "Alert");
    }
    else {
      $('#btnExampleModalCenter1').trigger('click');
    }
  }

  /**
   * when clicked on yes button in modal
   * api will be called to send message to agent with proper rejection reason
   * @param userName 
   * @param mobile 
   */
  btnRejectYes(userName, mobile) {
    var remarkValue = (<HTMLInputElement>document.getElementById("remark")).value;
    this.tokenGenerate.getToken(environment.getRejectToken).then(data => {
      this.datas = data;
    this.adminEdit.getReject(this.Agent_ID,this.datas.access_token).then(data => {
      
      this.tokenGenerate.getToken(environment.notifyUserToken).then(data => {
        this.datas = data;
      this.adminEdit.sendRejectionMessage(userName, mobile, remarkValue,this.datas.access_token).then(data => {
      })
    })
  })
      this.router.navigate(['/admin-approval']);
    });
  }

  /*
@author manoj 
This method is used to open the pop up menu 
@param
message 
*/
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  /**
   * Method to disable the submit button after first approval 
   */
  disableButton() {
    if (localStorage.getItem('userName') == environment.lokeshEmail) {
      if (this.Results.status == "PENDING_LEVEL_2_APPROVAL" || this.Results.status == "PENDING_MAIL_VERIFICATION") {
        $('#button1').prop('disabled', true).css('background-color', '#ccc');
        $('#button2').prop('disabled', true).css('background-color', '#ccc');
      }
    }
    else {
      if (this.Results.status == "PENDING_LEVEL_1_APPROVAL" || this.Results.status == "PENDING_MAIL_VERIFICATION") {
        $('#button1').prop('disabled', true).css('background-color', '#ccc');
        $('#button2').prop('disabled', true).css('background-color', '#ccc');
      }
    }


    if (this.Results.status == "FULFILLED" || this.Results.status == "REJECTED") {
      $('#button1').prop('disabled', true).css('background-color', '#ccc' );
      $('#button2').prop('disabled', true).css('background-color', '#ccc');
    }

    // changing status
    if (this.Results.status == "PENDING_MAIL_VERIFICATION") { this.Results.status = "PENDING" }
    else if (this.Results.status == "FULFILLED") {
      this.Results.status = "FULFILLED"
    }
    else if (this.Results.status == "PENDING_LEVEL_1_APPROVAL") { this.Results.status = "PENDING" }
    else if (this.Results.status == "PENDING_LEVEL_2_APPROVAL") { this.Results.status = "PENDING FOR APPROVAL II" }

  }

  /**
   * Method to show active tabs.
   */
  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      $('#nav-about-tab').css('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      $('#nav-about-tab').css('background-color', '#6f8294');
    })
    $('#nav-about-tab').click(function () {
      $('#nav-about-tab').css('background-color', '#246aaf');
      $('#nav-profile-tab').css('background-color', '#6f8294');
      $('#nav-home-tab').css('background-color', '#6f8294');
    })
  }
}

