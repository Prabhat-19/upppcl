import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminEditComponent } from './admin-edit.component';
import {Routes,Router,RouterModule  } from '@angular/router';

const route:Routes=[
  {path:'admin-edit',component:AdminEditComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AdminEditRoutingModule { }
