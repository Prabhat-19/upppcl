import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
// import {AdminHeaderComponent} from '../admin-header/admin-header.component'
import { AdminEditComponent } from './admin-edit.component';
import { AdminEditRoutingModule } from './admin-edit-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {NgxSpinnerModule} from 'ngx-spinner';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [AdminEditComponent],
  imports: [
    CommonModule,
    AdminEditRoutingModule,
    FormsModule,
    NgxSpinnerModule,
    RouterModule,
    SharedModule
  ]
})
export class AdminEditModule { }
