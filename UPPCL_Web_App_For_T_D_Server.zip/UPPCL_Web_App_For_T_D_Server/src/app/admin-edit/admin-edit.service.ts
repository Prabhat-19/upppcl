import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { resolve } from 'q';

@Injectable({
  providedIn: 'root'
})
export class AdminEditService {
  
  event: string;
  Agent_ID: string;
  data: any;
  header:any;

  constructor(private http: HttpClient) { }

  edit(id: any,token) {

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }


    return new Promise(resolve => {
     // this.http.get
      this.http.get(environment.editAgentDetails + id,this.header).subscribe((responseData:any) => {
        this.data = responseData;
        resolve(responseData);
      })
    })
  }

  // ID is different in both the cases.
  editDetails(id: any,token) {

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }


    return new Promise(resolve => {
      this.http.get(environment.editAgentDetail + id,this.header).subscribe((responseData: any) => {
        this.data = responseData;
        resolve(responseData);
      })
    })
  }

  // To send approval message to agent
  getApproval(payload: any,token) {
    var payload2 = {
      event: "APPROVED",
    }
    return new Promise(resolve => {
      this.http.post(environment.agentApproval + this.data.id, payload2,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          })
        }
      ).subscribe(data => {
        resolve(data);
      });
    });

  }

  // To send reject message to agent
  sendRejectionMessage(firstName, phoneNo, msg, token) {
    var payload = {
      "templateId": "AGENT_REJECT",
      "fields": [
        {
          "key": "firstName",
          "value": firstName
        },
        {
          "key": "phoneNo",
          "value": phoneNo
        },
        {
          "key": "msg",
          "value": msg
        }
      ]
    };
    return new Promise(resolve => {
      this.http.post(environment.sendPassword, payload,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          })
        }).subscribe(data => {
          resolve(data);
        });
    });
  }


  getReject(payload: any,token) {
    var payload2 = {
      event: "REJECTED",
    }
    return new Promise(resolve => {
      this.http.post(environment.agentReject + this.data.id, payload2,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          })

        }
      ).subscribe(data => {
        resolve(data);
      });
    });

  }
}

