import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentgatewayLandingpageComponent } from './paymentgateway-landingpage.component';

describe('PaymentgatewayLandingpageComponent', () => {
  let component: PaymentgatewayLandingpageComponent;
  let fixture: ComponentFixture<PaymentgatewayLandingpageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentgatewayLandingpageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentgatewayLandingpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
