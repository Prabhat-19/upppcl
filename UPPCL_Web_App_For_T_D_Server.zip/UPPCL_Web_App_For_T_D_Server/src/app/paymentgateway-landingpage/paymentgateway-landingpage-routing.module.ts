import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentgatewayLandingpageComponent } from './paymentgateway-landingpage.component';
import { Routes,RouterModule} from '@angular/router';

const route:Routes=[
{
  path:'paymentgateway-landingpage', component:PaymentgatewayLandingpageComponent
 
}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
  // exports: [PaymentgatewayLandingpageComponent],
  
})
export class PaymentgatewayLandingpageRoutingModule { }
