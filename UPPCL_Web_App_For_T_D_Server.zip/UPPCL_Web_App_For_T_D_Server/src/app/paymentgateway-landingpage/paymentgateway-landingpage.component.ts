import { Component, OnInit,HostListener } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BillPaymentService } from '../bill-payment/bill-payment.service';
import { NgxSpinnerService } from "ngx-spinner";
import { AgentDashboardService } from "../agent-dashboard/agent-dashboard.service"
import { Router } from '@angular/router';


@Component({
  selector: 'app-paymentgateway-landingpage',
  templateUrl: './paymentgateway-landingpage.component.html',
  styleUrls: ['./paymentgateway-landingpage.component.scss']
})
export class PaymentgatewayLandingpageComponent implements OnInit {
  

  constructor(private router:Router,private agentDashboardService:AgentDashboardService, private http: HttpClient, public billSerivce:BillPaymentService ,private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.agentAuth();

    /*
  This method is used to show spinner for 1 sec
  */
    this.spinner.show();
    setTimeout(() => {
      window.location.href=localStorage.getItem("encryptedUrl");
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

}

/*
  This method is used to authenticate user 
  */

agentAuth() {
  this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
  if(!data.valid)
    {
      this.router.navigate(["/login"]);
    }
  });
}
}
