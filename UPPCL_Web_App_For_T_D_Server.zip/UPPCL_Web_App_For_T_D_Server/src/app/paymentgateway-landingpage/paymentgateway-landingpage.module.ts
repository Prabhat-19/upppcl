import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentgatewayLandingpageComponent } from './paymentgateway-landingpage.component';
import { PaymentgatewayLandingpageRoutingModule } from './paymentgateway-landingpage-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [PaymentgatewayLandingpageComponent],
  imports: [
    PaymentgatewayLandingpageRoutingModule,
    CommonModule,
    NgxSpinnerModule,
    FormsModule,
    SharedModule,
    RouterModule
  ],
  // exports: [PaymentgatewayLandingpageComponent],
})
export class PaymentgatewayLandingpageModule { }
