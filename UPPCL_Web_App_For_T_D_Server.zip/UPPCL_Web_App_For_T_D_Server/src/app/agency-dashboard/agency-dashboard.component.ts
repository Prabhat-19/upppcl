import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { NgxSpinnerService } from "ngx-spinner";
declare var $: any
import { RegistrationService } from '../registration/registration.service';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { environment } from '../../environments/environment';
import { TokenGenerateService } from '../token-generate.service';
import { AgentTransactionService } from '../agent-transaction/agent-transaction.service';
import { AgencyDashboardService } from './agency-dashboard.service';
import { HeaderService } from '../header/header.service';

@Component({
  selector: 'app-agency-dashboard',
  templateUrl: './agency-dashboard.component.html',
  styleUrls: ['./agency-dashboard.component.scss']
})
export class AgencyDashboardComponent implements OnInit {
  
  @ViewChild('imageInput', { static: false }) imageInput: ElementRef;
  firstName: string;
  lastName: string;
  walletBalance: any;
  van: string;
  image: string;
  agencyName: string;
  datas: any;
  element: any;
  token: any
  agentId: string;
  agencyDashboardData: any;
  walletActivites = [];
  uploadProfilePicUrl: any;
  profilePicUrl: string;
  activityArray:any;
  constructor(private headerService: HeaderService,private agencyDashboardService: AgencyDashboardService, private agentTransactionService: AgentTransactionService, private tokenGenerate: TokenGenerateService, private generateTokenService: GenerateTokenService, private registrationService: RegistrationService, private agentDashboardService: AgentDashboardService, private spinner: NgxSpinnerService, private router: Router) { }

  ngOnInit() {
    this.checkUserTyper();
    this.tokenGenerate.afterLogin();
    this.spinner.hide();
    this.getAgencyId();
  }
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == null)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  onupload(event: any) {
    event.preventDefault();
    this.element = this.imageInput.nativeElement;
    this.element.click();
  }

  onChange() {
    if (this.element.files && this.element.files[0]) {
      var reader = new FileReader();
      reader.addEventListener('load', (event: any) => {
        $('.profile-pic').attr('src', event.target.result);
      })
      reader.readAsDataURL(this.element.files[0]);
    }
    this.spinner.show();
    this.uploadPhoto();
  }
  uploadPhoto() {
    return new Promise(resolve => {
      let formData = new FormData();
      formData.append('file', this.element.files[0]);
      formData.append('extraField', "uploadPhoto");
      // this.registrationService.uploadDocumentsService(formData, this.token).then(data => {
      //   resolve(data);
      // });
      // this.tokenGenerate.getToken(environment.fileUploadToken).then(data => {
      //   this.token = data;
        this.registrationService.uploadDocumentsService(formData).then(data => {
          this.uploadProfilePicUrl = data;
          this.uploadProfilePicUrl = this.uploadProfilePicUrl.fileDownloadUri;
          this.tokenGenerate.getToken(environment.userToken).then(data => {
            this.token = data;
            this.agencyDashboardService.fileUpdate(this.token.access_token, this.uploadProfilePicUrl).then(data => {
              this.spinner.hide();
            })
          })
        // });
      })
    });
  }

  modaldash() {

    $('#btncenterhide').click();
  
  };

  
  getAgencyId() {
    let userId = localStorage.getItem("userId");
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.agentDashboardService.getAgentId(userId, this.token).then((data: any) => {
        if(data.length == 0){   
          this.modaldash();
      }
        this.agentId = data[0].id;
        this.agentLogin();
        localStorage.setItem("agentId", this.agentId);
      });
    });
  }
  agentLogin() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.agentDashboardService.getUserDetail(this.agentId, this.token).then((data: any) => {
        if (data.user.imageUrl == "" || data.user.imageUrl == undefined) {
          this.profilePicUrl = "../../assets/image/Dummy_Image.png";
        }
        else {
          this.profilePicUrl = data.user.imageUrl;
        }
        this.walletBalance = data.balanceAmount;
        this.walletBalance = this.walletBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        this.firstName = data.user.firstName;
        this.lastName = data.user.lastName;
        this.van = data.van;
        this.agencyName = data.agencyName
        localStorage.setItem("van", this.van);
        localStorage.setItem("firstName", this.firstName);
        localStorage.setItem("lastName", this.lastName);
        localStorage.setItem("AgencyName", this.agencyName);
        this.walletTransactionActivites();
      });
    });
  }

  walletTransactionActivites() {
    this.spinner.show();
    this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data => {
      this.datas = data;
      this.agentTransactionService.getWalletDetailByAgentIds(this.datas.access_token).then((data: any) => {
        for (var i = 0; i < data.content.length; i++) {
          if (data.content[i].status == "SUCCESS") {
            if(data.content[i].type == "WalletTransaction"){
              this.activityArray = "DEBIT";
            }else{
            for(var activityData =0; activityData < data.content[i].response.length;activityData++){
              if(data.content[i].response[activityData].vanId != 'UPPCL'){
              this.activityArray = data.content[i].response[activityData].activity;
            }
            }
          }
            data.content[i]['sourceActivity'] = this.activityArray;
            this.walletActivites.push(data.content[i]);
            this.agencyDashboardData = this.walletActivites;
          }
        }
        // if (this.agencyDashboardData == "" || this.agencyDashboardData == undefined || this.agencyDashboardData == null) {
        //   document.getElementById("ledgerHistory").style.display = "";
        // }
      });
    });
    this.spinner.hide();
  }
  /**
   * logout method.
   * Navigate to login page.
   */
  logout() {
    this.headerService.deleteToken().then(data => {
      localStorage.clear();
      this.router.navigate(['/login']);
    });
  }
}
