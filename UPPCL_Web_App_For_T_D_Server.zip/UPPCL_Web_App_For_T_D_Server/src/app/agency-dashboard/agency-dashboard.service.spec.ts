import { TestBed } from '@angular/core/testing';

import { AgencyDashboardService } from './agency-dashboard.service';

describe('AgencyDashboardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgencyDashboardService = TestBed.get(AgencyDashboardService);
    expect(service).toBeTruthy();
  });
});
