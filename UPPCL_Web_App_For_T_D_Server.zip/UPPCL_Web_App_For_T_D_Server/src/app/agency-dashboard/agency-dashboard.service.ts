import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'; 
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgencyDashboardService {
  header : any;	
  constructor(private httpClient: HttpClient) { }
  
  fileUpdate(token,urlPath) {	
    var payload={	
      // "residenceAddress" : this.residenceAddress,	
      // "address" : this.address,	
      "firstName" : localStorage.getItem("firstName"),	
      "lastName" : localStorage.getItem("lastName"),	
      "imageUrl" : urlPath	
    };	
    this.header = {	
      headers: new HttpHeaders({	
        'Authorization': 'Bearer ' + token	
      })	
    }	
    return new Promise(resolve => {	
      this.httpClient.put(environment.updateUserDetails + localStorage.getItem("userId"),payload,this.header).subscribe(data => {	
         resolve(data);	
      });	
    });	
  	
  }	

}
