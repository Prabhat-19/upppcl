import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgencyDashboardComponent } from './agency-dashboard.component';

const route:Routes=[
  {path:'agency-dashboard',component:AgencyDashboardComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AgencyDashboardRoutingModule { }
