import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgencyDashboardComponent } from './agency-dashboard.component';
import { AgencyDashboardRoutingModule } from './agency-dashboard-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { NgxSpinnerModule } from "ngx-spinner";
import { OrderModule } from 'ngx-order-pipe';

@NgModule({
  declarations: [AgencyDashboardComponent],
  imports: [
    CommonModule,
    AgencyDashboardRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxSpinnerModule,
    OrderModule
  ]
})
export class AgencyDashboardModule { }
