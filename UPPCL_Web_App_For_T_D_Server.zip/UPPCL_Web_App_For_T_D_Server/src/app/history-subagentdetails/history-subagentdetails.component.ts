import { Component, OnInit,HostListener } from '@angular/core';
import { HistorySubagentService } from '../history-subagentdetails/history-subagent.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { validation } from '../../environments/validationsMessage';
import { NgxSpinnerService } from "ngx-spinner";
import {GenerateTokenService} from '../generate-token/generate-token.service';
import {TokenGenerateService} from '../token-generate.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-history-subagentdetails',
  templateUrl: './history-subagentdetails.component.html',
  styleUrls: ['./history-subagentdetails.component.scss']
})
export class HistorySubagentdetailsComponent implements OnInit {

  wallet: any;
  agentId: any;
  filterData: any;
  firstName: any;
  filterTransactionId: any;
  agentTransactionData: any;
  transactionRecord: boolean = false;
  lastName: any;
  arr = [];
  arr1 = []
  results: any;
  filterToDate: any;
  token:any;
  filterFromDate: any;
  subAgentToken:any;

  filterConsumerId: any;
  filterAgentId:any;
  typeSelectedValue = "Type";
  filterBillNumber:any;
  filterAmount:any;
  filterSource = "Source";
  config:any;

  statusSelectedValue = "Status";  

  constructor(public datepipe:DatePipe,private spinner:NgxSpinnerService,private tokenGenerate : TokenGenerateService, private generateTokenService:GenerateTokenService,private historySubagent: HistorySubagentService, private agentDashboardService: AgentDashboardService, private router: Router, private excelService: ExcelServiceService) { 
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
    };
  }

  ngOnInit() {
    this.agentAuth();
    $('#manage-agent').css('color', 'white');
    this.spinner.show();
    this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data=>{
      this.token=data;
      this.onTransaction();
    });
    // this.onTransaction();
    this.onDetails();
    // this.checkUserTyper();
  }
  /*
  This Method is used the check agent authentication 
  */
  agentAuth():void  {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
  
  pageChanged(event) {
    this.agentAuth();
    this.config.currentPage = event;
  }
  /*
  This method is used to open the pop up menu 
  */
  onTransaction(): void {
    this.historySubagent.manageSubAgent(this.token).then((data: any) => {
      if (data.empty == true) {
        (document.getElementById('ledgerHistory') as HTMLInputElement).style.display = "";
      }
      else {
        for (var i = 0; i < data.content.length; i++) {
          if (data.content[i].payload.billId == undefined) {
            data.content[i].payload.billId = "-";
            data.content[i].payload.consumerAccountId = "-";
          }
          if(data.content[i].status != "FAILED")
          {
          this.arr1.push(data.content[i]);
          this.results = this.arr1;
          }
        }
      }
    });
    this.spinner.hide();
  }


  onSubmit() {
    this.results = this.arr1;
    var self = this;
    this.filterData = [];
    
// if(this.filterFromDate >= this.filterToDate && this.filterToDate <= this.filterFromDate){
//   console.log("inside if date");
//     this.callModal("Please enter valid date range");
// }
// else{
    for (var agentTranscationLoop = 0; agentTranscationLoop < self.results.length; agentTranscationLoop++) {
        if (this.filterTransactionId == null) {
          this.filterTransactionId = "";
        }
        if(this.filterToDate != null){
        let newDate = new Date(this.filterToDate);  
        var nextDate = new Date(newDate.getTime()+1000*60*60*24);
        // if(this.filterFromDate >= this.filterToDate && this.filterToDate <= this.filterFromDate){
        //   console.log("inside if date");
        //   this.callModal("Please enter valid date range");
        // }
        }
        if( (this.filterFromDate > this.filterToDate)){
          this.callModal("Invalid Date Range.");
          this.filterFromDate = "";
          this.filterToDate = "";
        }
        if (this.results[agentTranscationLoop].status == "SUCCESS") { 
        if (this.filterTransactionId == null || (this.filterTransactionId != null && self.results[agentTranscationLoop].response[0].transactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
          && (this.filterConsumerId == null || (this.filterConsumerId != null && self.results[agentTranscationLoop].payload.consumerAccountId.includes(this.filterConsumerId)))
          && (this.filterAgentId == null || (this.filterAgentId != null && self.results[agentTranscationLoop].payload.vanNo.toUpperCase().includes(this.filterAgentId.toUpperCase())))
          && (this.typeSelectedValue == 'Type' || (this.typeSelectedValue != 'Type' && self.results[agentTranscationLoop].response[0].activity.includes(this.typeSelectedValue.toUpperCase())))
          && (this.filterBillNumber == null || (this.filterBillNumber != null && self.results[agentTranscationLoop].payload.billId.includes(this.filterBillNumber)))
          && (this.filterAmount == null || (this.filterAmount != null && self.results[agentTranscationLoop].payload.amount == (Number(this.filterAmount))))
          && (this.filterSource == 'Source' || (this.filterSource != 'Source' && self.results[agentTranscationLoop].payload.sourceType == (this.filterSource.toUpperCase())))
          && (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.results[agentTranscationLoop].date >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy'))))
          && (this.datepipe.transform(nextDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(nextDate, 'dd-MM-yyyy') != null && this.results[agentTranscationLoop].date <= (this.datepipe.transform(nextDate, 'dd-MM-yyyy'))))
        ) {
          this.filterData.push(this.results[agentTranscationLoop])
        }
       }
    }
  // }
    this.results = this.filterData;
  }

  callModal(message: string) {
    this.agentAuth();
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }


  clear() {
    this.agentAuth();
    this.filterData = [];
    this.filterTransactionId = null;
    this.filterConsumerId = null;
    this.filterAgentId = null;
    this.typeSelectedValue = 'Type';
    this.filterBillNumber = null;
    this.filterAmount = null;
    this.filterSource = "Source";
    this.statusSelectedValue = 'Status';
    this.filterToDate = null;
    this.filterFromDate = null;
    this.results = this.arr1;
  }

  /*
  This method is used to open the pop up menu 
  */
  onDetails(): void {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data =>{
      this.subAgentToken = data;
      this.historySubagent.getWalletDetailByAgentId(this.subAgentToken.access_token).then((data: any) => {
        this.firstName = data.user.firstName;
        this.lastName = data.user.lastName;
        this.wallet = data.balanceAmount;
      });
    })
  }

  /*
  This method is used to export the excel file  
  */
  exportAsXLSX(): void {
    for (var i = 0; i < this.results.length; i++) {
      this.arr.push({
        TransactionId: this.results[i].response[0].transactionId,
        Van: this.results[i].payload.vanNo,
        Type: this.results[i].payload.sourceType,
        CustomerId: this.results[i].payload.consumerAccountId,
        BillId: this.results[i].payload.billId,
        Amount: this.results[i].response.amount,
        SourceType: this.results[i].payload.sourceType,
        Status: this.results[i].status,
        Date: this.results[i].date,
      });
    }
    this.excelService.exportAsExcelFile(this.arr, 'Ledger');
  }
}