import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';
import { validation } from '../../environments/validationsMessage';

@Injectable({
  providedIn: 'root'
})
export class HistorySubagentService  {

  constructor(private http: HttpClient) { }
 
  manageSubAgent(token:any){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization':'Bearer '+ token.access_token
      })};
    return new Promise(resolve => {
      this.http.get(environment.agencyForTransactionAgentIdBasis+localStorage.getItem('subAgentVan'),httpOptions).subscribe((data: any) => {
        resolve(data);
       });
   });
  }
 
  getWalletDetailByAgentId(token:any){
    return new Promise(resolve => {
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization':'Bearer '+ token
        })};
      this.http.get(environment.editAgentDetail+localStorage.getItem('subAgentId'),httpOptions).subscribe(data => {
        resolve(data);
      });
    });
  }
}
