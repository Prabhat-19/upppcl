import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, Router,RouterModule } from '@angular/router';
import { HistorySubagentdetailsComponent } from '../history-subagentdetails/history-subagentdetails.component';
import { SharedModule } from '../shared/shared.module';

const routes: Routes = [
  { path:'history-subagentdetails', component: HistorySubagentdetailsComponent}
];

@NgModule({
  declarations: [],
  imports: [
    SharedModule,
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class HistorySubagentdetailsRoutingModule { }
