import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistorySubagentdetailsComponent } from './history-subagentdetails.component';

describe('HistorySubagentdetailsComponent', () => {
  let component: HistorySubagentdetailsComponent;
  let fixture: ComponentFixture<HistorySubagentdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistorySubagentdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistorySubagentdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
