import { TestBed } from '@angular/core/testing';

import { HistorySubagentService } from './history-subagent.service';

describe('HistorySubagentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HistorySubagentService = TestBed.get(HistorySubagentService);
    expect(service).toBeTruthy();
  });
});
