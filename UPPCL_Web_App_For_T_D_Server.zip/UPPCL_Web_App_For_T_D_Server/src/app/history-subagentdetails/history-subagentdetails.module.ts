import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { HistorySubagentdetailsRoutingModule } from '../history-subagentdetails/history-subagentdetails-routing.module';
import { HistorySubagentdetailsComponent} from '../history-subagentdetails/history-subagentdetails.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerModule } from "ngx-spinner";
import {NgxPaginationModule} from 'ngx-pagination'; 

@NgModule({
  declarations: [HistorySubagentdetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    FormsModule,
    ScrollingModule,
    NgxSpinnerModule,
    HistorySubagentdetailsRoutingModule,
    NgxPaginationModule
  ],
  providers: [ExcelServiceService,DatePipe]
})
export class HistorySubagentdetailsModule { }
