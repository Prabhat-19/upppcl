import { Component, OnInit } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event } from '@angular/router';
import { LoginService } from './login.service';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { validation } from '../../environments/validationsMessage';
import { HttpClient } from '@angular/common/http';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { TokenGenerateService } from '../token-generate.service';
import { constant } from '../../environments/constant';
declare var $: any

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  dropDownComponent = constant.dropDownValue;
  captcha: any;
  code: any;
  res: any;
  userName: any;
  userPassword: any;
  openAMToken: any;
  token: any;
  securityCode: any;
  adminData: any;
  constructor(private tokenGenerate: TokenGenerateService, private httpClient: HttpClient, private router: Router, private generateTokenService: GenerateTokenService, private service: LoginService, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.createCaptcha();
    this.router.events.subscribe((routerEvent: Event) => {
      if (routerEvent instanceof NavigationStart) {
        this.spinner.show()
      }
      if (routerEvent instanceof NavigationEnd) {
        this.spinner.hide()
      }
    })
  }

  createCaptcha(): void {
    var charsArray = validation.CAPTCHA_STRING;
    var lengthOtp = 6;
    var captcha = [];
    for (var i = 0; i < lengthOtp; i++) {
      var index = Math.floor(Math.random() * charsArray.length + 1);
      if (captcha.indexOf(charsArray[index]) == -1)
        captcha.push(charsArray[index]);
      else i--;
    }
    var canv = document.createElement("canvas");
    canv.id = "captcha";
    canv.width = 100;
    canv.height = 50;
    var ctx = canv.getContext("2d");
    ctx.font = "30px Georgia";
    ctx.strokeText(captcha.join(""), 0, 30);
    this.code = captcha.join("");
    var arg = document.getElementById("captcha").appendChild(canv);
    (<HTMLInputElement>document.getElementById('captcha')).value = this.code;
  }

  validateCaptcha(): boolean {
    var captchaCode = (<HTMLInputElement>document.getElementById("cpatchaTextBox")).value;
    if (this.code.replace(/ /g, "") == captchaCode) {
      return true;
    }
    else {
      return false;
    }
  }

  checkFilled(usernamelogin: String, userPassword: String, securityCode: String, dropDown: String): boolean {
    if (usernamelogin == "" || userPassword == "" || usernamelogin == undefined || userPassword == undefined || securityCode == "" || securityCode == undefined || dropDown == constant.dropDownValue)
      return false;
    else
      return true;}

  callModal(message: string): void {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  loginValidate(event): void {
    if (this.checkFilled(this.userName, this.userPassword, this.securityCode, event)) {
      if (this.validateCaptcha()) {
        this.service.agentValidateIDAM(this.userName, this.userPassword).then(data => {
          this.openAMToken = data;
          this.openAMToken = this.openAMToken.tokenId;
          localStorage.setItem("authToken", this.openAMToken);
          this.tokenGenerate.getToken(environment.userToken).then(data => {
            this.token = data;
            this.service.agentValidate(this.userName, this.token).then(data => {
              this.setUserTypeInSession();
              localStorage.setItem('role', data[0].role);
              if (data[0].role.includes(this.dropDownComponent.toUpperCase())) {
                if (data[0].role == validation.upplcRoles.Agent.toUpperCase()) {
                  localStorage.setItem("userId", data[0].id);
                  this.router.navigate(['/agent-dashboard']);
                }
                else if (data[0].role == validation.upplcRoles.agency.toUpperCase()) {
                  localStorage.setItem("userId", data[0].id);
                  this.router.navigate(['/agency-dashboard']);
                }
                else {
                  this.adminData = data;
                  localStorage.setItem('userName', this.adminData[0].userName);
                  localStorage.setItem("userId", data[0].id);
                  this.router.navigate(['/admin-dashboard']);
                }
              }
              else {
                this.callModal(validation.ENTER_VALID_USER_TYPE);
              }
            });
          });
        });
      }
      else {
        this.callModal(validation.ENTER_VALID_SECURITY_CODE);
      }
    }
    else {
      this.callModal(validation.ENTER_REQURIED_FIELD)
    }
    this.createCaptcha();
  }

  checkObjectEmpty(obj): boolean {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  setUserTypeInSession(): void {
    localStorage.setItem("userType", (this.dropDownComponent.toString()));
  }

  confirmationModal(event): void {
    $(document).ready(function () {
      event.preventDefault();
      jQuery.noConflict();
      $("#emailVerificationModal").modal();
    });
  }

  clear(): void {
    $('input').not('#captcha').not('#btnlogin').not('#btncancel').val('');
    $('select').val('Select one')
  }
}

