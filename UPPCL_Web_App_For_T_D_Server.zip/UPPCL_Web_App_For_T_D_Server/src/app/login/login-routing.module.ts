import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { LoginComponent } from './login.component';
const route:Routes=[
  { path: '', component: LoginComponent },
  {path:'login',component:LoginComponent}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class LoginRoutingModule { }
