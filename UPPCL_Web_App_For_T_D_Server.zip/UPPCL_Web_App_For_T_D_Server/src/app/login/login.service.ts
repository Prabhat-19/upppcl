import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { validation } from '../../environments/validationsMessage';
import { error } from 'util';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpClient: HttpClient, private spinner: NgxSpinnerService) { }

  agentValidate(userName: any,token:any) {
      const httpOptions = {
      headers: new HttpHeaders({
        'Authorization':'Bearer '+ token.access_token
      })};
    let promise = new Promise((resolve, reject) => {
      this.httpClient.get(environment.agentValidate + userName,httpOptions).toPromise().then((data: any) => {
        // if (JSON.stringify(data) == "[]") {
        //   $("#modelText").text("Username is incorrect");
        //   $('#btnhide').click();
        // }
        // else {
          resolve(data);
        // }
      },
        msg => {
          console.log(msg);
          if(msg.status == 401){
            this.callModal(validation.ENTER_VALID_DETAIL);
          }
          // $("#modelText").text("Username is incorrect");
          // $('#btnhide').click();
          reject(msg);
        })
    })
    return promise;
  }

  agentValidateIDAM(userName: any, password: any) {
    let promise = new Promise((resolve, reject) => {
      this.httpClient.post(environment.validateAgentWithIDAM, {},
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'X-OpenAM-Username': userName,
            'X-OpenAM-Password': password,
            'Accept-API-Version': 'resource=2.0, protocol=1.0'
          })
        }
        ).toPromise().then((data: any) => {
          resolve(data);
          this.spinner.hide();
        },
          msg => {
            this.spinner.hide();
            if(msg.status == 401){
              this.callModal(validation.ENTER_VALID_DETAIL);
            }
            reject(msg);
          })
    })
    return promise;
  }

  callModal(message: string): void {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
}

