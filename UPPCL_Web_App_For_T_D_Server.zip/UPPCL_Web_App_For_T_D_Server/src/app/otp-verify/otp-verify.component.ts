import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OtpVerifyService } from './otp-verify.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { NgxSpinnerService } from 'ngx-spinner';
import {TokenGenerateService} from '../token-generate.service';
import {environment} from '../../environments/environment';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-otp-verify',
  templateUrl: './otp-verify.component.html',
  styleUrls: ['./otp-verify.component.scss']
})
export class OtpVerifyComponent implements OnInit {

  datas: any;
  otpId: any;
  otp: any;
  token:any;

  constructor(private spinnerService: NgxSpinnerService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService,  private router: Router, private otpService: OtpVerifyService) { }

  ngOnInit() {
    this.checkUserTyper();
    this.spinnerService.hide();
    this.sendRequestForOtp();
  }

  /**
   * delay some particular Method.
   * @param ms in mili seconds
   */
  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => {});
  }

  /*
 @author manoj 
 This method is used to open the pop up menu 
 @param
   message 
 */
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  /**
   * To verify otp 
   */
  verify() {
    this.otp = (<HTMLInputElement>document.getElementById("otpCode")).value;
                                            
    this.tokenGenerate.getToken(environment.updateOtpStatusToken).then(data => {
      this.token = data;
    this.otpService.verifiedOtp(this.otpId, this.otp,this.token.access_token).then(data => {
      this.delay(2000).then(any => {
        this.datas = data;
        if (this.datas) {
          this.registrationUser();
          this.router.navigate(['/registration-success']);
        }
        else {
          this.callModal("Please enter correct OTP.", "Alert");
        }
      });
    })
  })
  }

  /**
   * Method for resend otp
   */
  resendOtp() {
    
    this.tokenGenerate.getToken(environment.addotpToken).then(data => {
      this.datas = data;
      this.otpService.sendRequestForOtp(this.datas.access_token).then(data => {
      this.datas = JSON.stringify(data);
      this.datas = data;
      this.callModal("OTP has been resend.", "Alert");
      this.otpId = this.datas;
      })
    })
    // this.otpService.sendRequestForOtp().then(data => {
    //   this.datas = JSON.stringify(data);
    //   this.datas = data;
    //   this.callModal("OTP has been resend", "Alert");
    //   this.otpId = this.datas;
    // })
  }

  /**
   * Method to checkuser type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * Method for Register agent
   */
  registrationUser() {
    this.tokenGenerate.getToken(environment.agentRegisterToken).then(data => {
      this.token = data;
    this.otpService.registerUser(this.token.access_token).then(data => {
      this.datas = data;
    })
  })
  }

  /**
   * send request for otp
   */
  sendRequestForOtp() {
    this.tokenGenerate.getToken(environment.addotpToken).then(data => {
      this.datas = data;
      this.otpService.sendRequestForOtp(this.datas.access_token).then(data => {
      this.datas = data;
      this.otpId = this.datas;
      })
    })
  }
}
