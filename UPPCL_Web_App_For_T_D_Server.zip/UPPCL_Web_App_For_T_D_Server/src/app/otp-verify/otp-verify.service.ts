import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class OtpVerifyService {



  constructor(private router: Router, private http: HttpClient) { }

  verifiedOtp(optId, otp,token) {
    var payload = {
      "otpId": optId,
      "otp": otp
    };
    let promise = new Promise((resolve, reject) => {
      this.http.put(environment.verifyOtp, payload,
        {
          headers: new HttpHeaders({
            // 'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Bearer ' + token
          })
        }).toPromise().then((data: any) => {

          resolve(data);
        },
          msg => {
            reject(msg);
          }
        )
    })
    return promise;
  }

  registerUser(token) {
    let promise = new Promise((resolve, reject) => {
      this.http.post(environment.agentRegister, localStorage.getItem("registerationUserData"),
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token 
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
            reject(msg);
          }
        )
    })
    return promise;
  }

  sendRequestForOtp(token) {
    if (localStorage.getItem("mobileNumber") == null) {
      this.router.navigate(['/login']);
    }
    else {
      var payload = {
        "phoneNo": localStorage.getItem("mobileNumber")
      };

      let promise = new Promise((resolve, reject) => {
        this.http.post(environment.addOtp, payload,
          {
            headers: new HttpHeaders({
              // 'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + token 
            })
          }).toPromise().then((data: any) => {
            resolve(data);
          },
            msg => {
              reject(msg);
            }
          )
      })
      return promise;
    }
  }
}
