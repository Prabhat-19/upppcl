import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { OtpVerifyComponent } from './otp-verify.component';

const route:Routes=[
  {path:'otp-verify',component:OtpVerifyComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class OtpVerifyRoutingModule { }
