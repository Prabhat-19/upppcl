import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
import { OtpVerifyComponent } from './otp-verify.component';
import { OtpVerifyRoutingModule } from './otp-verify-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { NgxSpinnerModule } from "ngx-spinner";
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

@NgModule({
  declarations: [OtpVerifyComponent],
  imports: [
    CommonModule,
    OtpVerifyRoutingModule,
    RouterModule,
    FormsModule,
    SharedModule,
    NgxSpinnerModule,
    Ng4LoadingSpinnerModule
  ]
})
export class OtpVerifyModule { }
