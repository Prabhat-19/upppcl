import { Component, OnInit, ɵConsole } from '@angular/core';
import { AgentTransactionService } from './agent-transaction.service';
import { Router } from '@angular/router'
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { DatePipe } from '@angular/common';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
import { Pipe, PipeTransform, HostListener } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { NgxSpinnerService } from "ngx-spinner";
import { DeviceDetectorService } from 'ngx-device-detector';
declare var $: any;

@Component({
  selector: 'app-agent-transaction',
  templateUrl: './agent-transaction.component.html',
  styleUrls: ['./agent-transaction.component.scss']
})

@Pipe({
  name: 'numberToWords'
})
export class AgentTransactionComponent implements OnInit, PipeTransform {
  
  typeSelectedValue = "Type";
  statusSelectedValue = "Status";
  agentData: string;
  agentTransactionData: any;
  area: any;
  agentId: any;
  txId: string;
  billId: string;
  filterData = [];
  startDate: any;
  endDate: any;
  datas: any;
  transactionDate: Date;
  transcationtime: Date;
  billID: string;
  payAmount: number;
  transStatus: string;
  consumerNames: string;
  token: any;
  payAmountInWords: string;
  consumerAccountId: string;
  config: any;
  creditAmount: number;
  debitAmount: number;
  agentTransactionServiceData: any;
  printBy: any;
  filterTextfeild: any;
  eventValue: any;
  addressCity: any;
  addressState: any;
  mobileNumber: any;
  recieptNo: any;
  dates: any;
  nowDateTime: any;
  discom: any;
  division: any;
  logo: any;
  a = [
    '',
    'one ',
    'two ',
    'three ',
    'four ',
    'five ',
    'six ',
    'seven ',
    'eight ',
    'nine ',
    'ten ',
    'eleven ',
    'twelve ',
    'thirteen ',
    'fourteen ',
    'fifteen ',
    'sixteen ',
    'seventeen ',
    'eighteen ',
    'nineteen '];

  agencyNameLabel: boolean = false;
  agencyName: any;

  b = [
    '',
    '',
    'twenty',
    'thirty',
    'forty',
    'fifty',
    'sixty',
    'seventy',
    'eighty',
    'ninety'];
  filterTransactionId: any;
  filterAgentId: any;
  filterConsumerId: any;
  filterType: any;
  filterBillNumber: any;
  filterAmount: any;
  filterSource = 'Source';
  filterStatus: any;
  filterFromDate: any;
  filterToDate: any;
  activity = [];
  activityArray: any;
  activity1: any;
  deviceInfo: any;
  isMobile: any;
  isDesktopDevice: any;
  isTablet
  totalElements:any;
  constructor(

    private spinner: NgxSpinnerService, private _decimalPipe: DecimalPipe, private tokenGenerate: TokenGenerateService, private agentDashboardService: AgentDashboardService, public datepipe: DatePipe, private agentTransactionService: AgentTransactionService, private router: Router, private excelService: ExcelServiceService
    , private deviceService: DeviceDetectorService) {

  }

  epicFunction() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    this.isMobile = this.deviceService.isMobile();
    this.isTablet = this.deviceService.isTablet();
    this.isDesktopDevice = this.deviceService.isDesktop();
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
    };
  }

  ngOnInit() {
    this.agentAuth();
    this.epicFunction();
    this.onTransaction(this.totalElements);
    this.checkUserTyper();
  }
  //  Page load API calls 
  onTransaction(totalElements) {
    this.spinner.show();
    this.creditAmount = 0;
    this.debitAmount = 0;
    let agentTransactionDataArray = [];
    this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data => {
      this.token = data;
      this.agentTransactionService.getWalletDetailByAgentId(this.token.access_token,totalElements).then((data: any) => {
        this.agentTransactionServiceData = data;
        for (var i = 0; i < data.content.length; i++) {
          if (data.content[i].payload.sourceType == "BANK") {
            data.content[i].payload.sourceType = "NET BANKING";
            data.content[i].payload.consumerAccountId = "-";
          }
          if (data.content[i].payload.sourceType == "NON_RAPDRP") { data.content[i].payload.sourceType = "NON-RAPDRP (RURAL)"; }
          if (data.content[i].payload.sourceType == "RAPDRP") { data.content[i].payload.sourceType = "RAPDRP (URBAN)"; }
          if (data.content[i].payload.billId == undefined) { data.content[i].payload.billId = "-"; }
          if (data.content[i].payload.consumerAccountId == undefined) { data.content[i].payload.consumerAccountId = "-"; }
          if (data.content[i].response.type == undefined) { data.content[i].response.type = "-"; }
          if (data.content[i].payload.discom == undefined) { data.content[i].payload.discom = "-"; }
          if (data.content[i].payload.division == undefined) { data.content[i].payload.division = "-"; }
          if (data.content[i].status == "SUCCESS") {
            if (data.content[i].type == "WalletTransaction") {
              this.activityArray = "CREDIT";
            } else {
              for (var activityData = 0; activityData < data.content[i].response.length; activityData++) {
                if (data.content[i].response[activityData].vanId != 'UPPCL') {
                  this.activityArray = data.content[i].response[activityData].activity;
                }
              }
            }
            data.content[i]['sourceActivity'] = this.activityArray;
            if (data.content[i].sourceActivity == "CREDIT") {
              this.creditAmount += data.content[i].payload.amount;
            }
            else if (data.content[i].sourceActivity == "DEBIT") {
              this.debitAmount += data.content[i].payload.amount;
            }
            agentTransactionDataArray.push(data.content[i]);
            this.agentTransactionData = agentTransactionDataArray;
            this.agentData = this.agentTransactionData;
          }
        }
       // if (this.agentTransactionData == "" || this.agentTransactionData == undefined) {
        //   document.getElementById("ledgerHistory").style.display = "";
        // }
      });
    })
    this.spinner.hide();
  }
  pageChanged(event) {
    this.agentAuth();
    this.config.currentPage = event;
    this.onTransaction(this.agentTransactionServiceData.totalElements);
  }
  onSubmit() {
    this.agentAuth();
    this.filterData = [];
    for (var agentTranscationLoop = 0; agentTranscationLoop < this.agentTransactionServiceData.content.length; agentTranscationLoop++) {
      if (this.agentTransactionServiceData.content[agentTranscationLoop].status == "SUCCESS") {
        if (this.filterTransactionId == null) {
          this.filterTransactionId = "";
        }
        if (this.filterToDate != null) {
          let newDate = new Date(this.filterToDate);
          var nextDate = new Date(newDate.getTime() + 1000 * 60 * 60 * 24);
        }
        if ((this.filterFromDate > this.filterToDate)) {
          this.callModal("Invalid Date Range.");
          this.filterFromDate = "";
          this.filterToDate = "";
        }
        if (this.filterTransactionId == null || (this.filterTransactionId != null && this.agentTransactionServiceData.content[agentTranscationLoop].response[0].transactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
          && (this.filterConsumerId == null || (this.filterConsumerId != null && this.agentTransactionServiceData.content[agentTranscationLoop].payload.consumerAccountId.includes(this.filterConsumerId)))
          && (this.filterAgentId == null || (this.filterAgentId != null && this.agentTransactionServiceData.content[agentTranscationLoop].payload.agentId.toUpperCase().includes(this.filterAgentId.toUpperCase())))
          && (this.typeSelectedValue == "Type" || (this.typeSelectedValue != "Type" && this.agentTransactionServiceData.content[agentTranscationLoop].sourceActivity.toUpperCase().includes(this.typeSelectedValue.toUpperCase())))
          && (this.filterBillNumber == null || (this.filterBillNumber != null && this.agentTransactionServiceData.content[agentTranscationLoop].payload.billId.includes(this.filterBillNumber)))
          && (this.filterAmount == null || (this.filterAmount != null && this.agentTransactionServiceData.content[agentTranscationLoop].payload.amount == (Number(this.filterAmount))))
          && (this.filterSource == 'Source' || (this.filterSource != 'Source' && this.agentTransactionServiceData.content[agentTranscationLoop].payload.sourceType == (this.filterSource.toUpperCase())))
          // && (this.filterSource == null || (this.filterSource != null && this.agentTransactionServiceData.content[agentTranscationLoop].payload.sourceType.toUpperCase().includes(this.filterSource.toUpperCase())))
          //&& (this.statusSelectedValue == "Status" || (this.statusSelectedValue != "Status" && this.agentTransactionServiceData.content[agentTranscationLoop].status.toUpperCase().includes(this.statusSelectedValue.toUpperCase())))
          && (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.agentTransactionServiceData.content[agentTranscationLoop].date >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy'))))
          && (this.datepipe.transform(nextDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(nextDate, 'dd-MM-yyyy') != null && this.agentTransactionServiceData.content[agentTranscationLoop].date <= (this.datepipe.transform(nextDate, 'dd-MM-yyyy'))))
          // (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy') != null && this.agentTransactionServiceData.content[agentTranscationLoop].date <= (this.datepipe.transform(this.filterToDate, 'dd-MM-yyyy'))))
        ) {
          this.filterData.push(this.agentTransactionServiceData.content[agentTranscationLoop])
        }
      }
    }
    this.agentTransactionData = this.filterData;
  }
  clear() {
    this.agentAuth();
    this.filterData = [];
    this.filterTransactionId = null;
    this.filterConsumerId = null;
    this.filterAgentId = null;
    this.typeSelectedValue = "Type";
    this.filterBillNumber = null;
    this.filterAmount = null;
    this.filterSource = "Source";
    this.statusSelectedValue = "Status";
    this.filterToDate = null;
    this.filterFromDate = null;
    this.agentTransactionData = this.agentData;
  }

  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
    if (localStorage.getItem("isSubAgent") == "Yes") {
      this.agencyNameLabel = true;
      this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
        this.token = data;
        this.agentTransactionService.getAgencyName(this.token.access_token).then((data: any) => {
          this.agencyName = data.agencyName;
        })
      })
      return;
    }
    else {
      this.agencyNameLabel = false;
    }
  }

  transform(value: any, args?: any): any {
    this.agentAuth();
    if (value) {
      let num: any = Number(value);
      if (num) {
        if ((num = num.toString()).length > 9) { return 'We are not the Iron Bank, you can lower down the stakes :)'; }
        const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) { return ''; }
        let str = '';
        str += (Number(n[1]) !== 0) ? (this.a[Number(n[1])] || this.b[n[1][0]] + ' ' + this.a[n[1][1]]) + 'crore ' : '';
        str += (Number(n[2]) !== 0) ? (this.a[Number(n[2])] || this.b[n[2][0]] + ' ' + this.a[n[2][1]]) + 'lakh ' : '';
        str += (Number(n[3]) !== 0) ? (this.a[Number(n[3])] || this.b[n[3][0]] + ' ' + this.a[n[3][1]]) + 'thousand ' : '';
        str += (Number(n[4]) !== 0) ? (this.a[Number(n[4])] || this.b[n[4][0]] + ' ' + this.a[n[4][1]]) + 'hundred ' : '';
        str += (Number(n[5]) !== 0) ? ((str !== '') ? 'and ' : '') +
          (this.a[Number(n[5])] || this.b[n[5][0]] + ' ' +
            this.a[n[5][1]]) + ' rupees only' : '';
        this.titleCase(str);

      } else {
        return '';
      }
    } else {
      return '';
    }
  }

  titleCase(str) {
    //  this.agentAuth();
    var splitStr = str.toLowerCase().split(' ');
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    this.payAmountInWords = splitStr.join(' ');
  }

  /**
    * Method to convert data in dd-mm-yyyy 
    * Convert time in hh:mm:ss
    */
  setDateTime() {
    this.agentAuth();
    var today = new Date();
    var mm = "" + (today.getMonth() + 1);
    var dd = "" + today.getDate();
    if (parseInt(mm) < 10) {
      mm = "0" + mm;
    }
    if (parseInt(dd) < 10) {
      dd = "0" + dd;
    }
    var date = today.getFullYear() + '-' + mm + '-' + dd;
    this.dates = dd + '-' + mm + '-' + today.getFullYear();

    var hours = "" + today.getHours();
    if (parseInt(hours) < 10) {
      hours = "0" + hours;
    }
    var minutes = "" + today.getMinutes();
    if (parseInt(minutes) < 10) {
      minutes = "0" + minutes;
    }
    var seconds = "" + today.getSeconds();
    if (parseInt(seconds) < 10) {
      seconds = "0" + seconds;
    }
    var time = hours + ":" + minutes + ":" + seconds;
    var dateTime = date + ' ' + time;
    this.nowDateTime = dateTime;
  }


  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }


  clicked(area, agentId, billId, status, date, transactionId, amount, names, consumerAccountId, type, discom, division, number, recieptNo,billNo) {


    this.agentAuth();
    document.getElementById('printshow1').style.display = "block";
    
    this.setDateTime();
    this.txId = transactionId;

    this.transactionDate = date.split(" ")[0];
    this.transcationtime = date.split(" ")[1];
    this.consumerAccountId = consumerAccountId;
    this.consumerNames = names;
    this.billID = billId;
    this.payAmount = amount;
    this.transform(this.payAmount);
    this.transStatus = status;
    this.discom = discom;
    this.division = division;
    this.setAddress(this.discom);
    this.area = area;
    this.recieptNo = recieptNo;
    this.printBy = localStorage.getItem('firstName') + " " + localStorage.getItem("lastName") + " " + "(" + localStorage.getItem("van") + ")";
    this.mobileNumber = number;
    if (this.isDesktopDevice) {
      $('#btncenterhidee').trigger('click');
    }
    else
    //is mobile
    {

      $('#hidemob').trigger('click');

    }
  }
  centerOtpModal() {
    this.agentAuth();
    $(document).ready(function () {
      $('#btncenterhide').click();
    })
  }

  setAddress(discomName) {
    this.agentAuth();
    var discomName = this.discom;
    switch (discomName) {
      case ('MVVNL'):
        {
          this.addressCity = '4A, Gokhale Marg';
          this.addressState = 'Lucknow, Uttar Pradesh';
          this.logo = "../assets/image/mvvnl.jpeg"
          break;
        }
      case ('PVVNL'):
        {
          this.addressCity = 'Urja Bhawan, Victoria Park';
          this.addressState = 'Meerut, Uttar Pradesh';
          this.logo = "../assets/image/pvvnl.jpg"
          break;
        }
      case ('DVVNL'):
        {
          this.addressCity = 'Urja Bhavan, Sikandra';
          this.addressState = 'Agra, Uttar Pradesh';
          this.logo = "../assets/image/dvvnl.jpg"
          break;
        }
      default:
        {
          this.addressCity = 'DLW Bhikharipur';
          this.addressState = 'Varanasi, Uttar Pradesh';
          this.logo = "../assets/image/puvnnl.jpeg"
          break;
        }
    }
  }

  onCancel() {

    document.getElementById('printshow1').style.display = "none";
    $('.modal-backdrop').remove();

  }

  callModal(message: string) {
    this.agentAuth();
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }


  exportAsXLSX(): void {
    let arr = [];
    for (let i = 0; i < this.agentTransactionData.length; i++) {
      arr.push({
        TransactionId: this.agentTransactionData[i].response[0].transactionId,
        Van: localStorage.getItem("van"),
        Name: localStorage.getItem("firstName") + " " + localStorage.getItem("lastName"),
        Type: this.agentTransactionData[i].sourceActivity,
        ConsumerId: this.agentTransactionData[i].payload.consumerAccountId,
        ConsumerName: this.agentTransactionData[i].payload.consumerName,
        billNumber: this.agentTransactionData[i].payload.billId,
        Amount: this.agentTransactionData[i].payload.amount,
        Source: this.agentTransactionData[i].payload.sourceType,
        Discom: this.agentTransactionData[i].payload.discom,
        Division: this.agentTransactionData[i].payload.division,
        Status: this.agentTransactionData[i].status,
        Date: this.agentTransactionData[i].date,
      });
    }
    this.excelService.exportAsExcelFile(arr, 'Ledger');
  }
}
