import { TestBed } from '@angular/core/testing';

import { AgentTransactionService } from './agent-transaction.service';

describe('AgentTransactionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentTransactionService = TestBed.get(AgentTransactionService);
    expect(service).toBeTruthy();
  });
});
