import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http'; 
import { environment  } from '../../environments/environment';
import { TokenGenerateService } from '../token-generate.service';

@Injectable({
  providedIn: 'root'
})
export class AgentTransactionService {

  header:any;
  URL:any
  constructor(private http:HttpClient) { }

  getAgencyName(token) 
  {
    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }

    return new Promise(resolve => {
      this.http.get(environment.editAgentDetail+localStorage.getItem("agencyIdForagencyName"),this.header).subscribe(data => {
        resolve(data);
      });
    });
  }

  getWalletDetailByAgentIds(token) {

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }

    return new Promise(resolve => {
      this.http.get(environment.agencyForTransactionAgentIdBasis+localStorage.getItem("van"),this.header).subscribe(data => {
        resolve(data);
      });
    });

  }

  getWalletDetailByAgentId(token,totalPages) {

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
    
    if(totalPages == ""){
      this.URL = environment.agentTransactionAgentIdBasis+'&sort=date%2Cdesc&status=SUCCESS&van=';}
      else{
        this.URL = environment.agentTransactionAgentIdBasis+'size='+ totalPages +'&sort=date%2Cdesc&status=SUCCESS&van=';}
    
    return new Promise(resolve => {
      this.http.get(this.URL+localStorage.getItem("van"),this.header).subscribe(data => {
        resolve(data);
      });
    });

  }
}
