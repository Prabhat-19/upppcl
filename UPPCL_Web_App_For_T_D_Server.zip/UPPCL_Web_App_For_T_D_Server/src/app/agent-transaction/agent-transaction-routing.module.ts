import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgentTransactionComponent } from './agent-transaction.component';

const route:Routes=[
  {path:'agent-transaction',component:AgentTransactionComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AgentTransactionRoutingModule { }
