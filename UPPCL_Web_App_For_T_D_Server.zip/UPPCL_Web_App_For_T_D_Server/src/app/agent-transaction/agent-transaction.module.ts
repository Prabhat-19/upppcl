import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgentTransactionComponent } from './agent-transaction.component';
import { AgentTransactionRoutingModule } from './agent-transaction-routing.module';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module'
// import { ScrollingModule } from '@angular/cdk/scrolling';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxPrintModule } from 'ngx-print';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { OrderModule } from 'ngx-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';   
import { DecimalPipe } from '@angular/common';
import { DeviceDetectorModule } from 'ngx-device-detector';

@NgModule({
  declarations: [AgentTransactionComponent],
  imports: [
    CommonModule,
    AgentTransactionRoutingModule,
    NgxPrintModule,
    FormsModule,
    RouterModule,
    SharedModule,
    // ScrollingModule,
    NgxSpinnerModule,
    NgxPaginationModule,
    OrderModule,
    Ng2SearchPipeModule,
    DeviceDetectorModule.forRoot()
  ],
  providers: [ExcelServiceService, DatePipe, DecimalPipe]
})
export class AgentTransactionModule { }

