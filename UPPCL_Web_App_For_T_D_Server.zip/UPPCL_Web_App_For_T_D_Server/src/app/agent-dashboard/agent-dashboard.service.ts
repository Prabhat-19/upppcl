import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'; 
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgentDashboardService {

  header:any;

constructor(private httpClient: HttpClient) { }
  
/*
@author Manoj
This method is used to get the user detail by id 
@parameter
  userId 
return 
  this method retunr full user detail Except the wallet detail 
*/
getAgentId(userId,token){
  this.header = {
    headers: new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Bearer ' + token.access_token
    })
  }
  return new Promise(resolve => {
   this.httpClient.get(environment.manageSubAgentEdit+userId,this.header).subscribe(data => {
      resolve(data);
    });
  });
}
fileUpdate(token,urlPath) {	
  var payload={	
    // "residenceAddress" : this.residenceAddress,	
    // "address" : this.address,	
    "firstName" : localStorage.getItem("firstName"),	
    "lastName" : localStorage.getItem("lastName"),	
    "imageUrl" : urlPath	
  };	
  this.header = {	
    headers: new HttpHeaders({	
      'Authorization': 'Bearer ' + token	
    })	
  }	
  return new Promise(resolve => {	
    this.httpClient.put(environment.updateUserDetails + localStorage.getItem("userId"),payload,this.header).subscribe(data => {	
       resolve(data);	
    });	
  });	
}
getUserDetail(agentId,token){
  this.header = {
    headers: new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Bearer ' + token.access_token
    })
  }
 
  return new Promise(resolve => {
   this.httpClient.get(environment.editAgentDetail+agentId,this.header).subscribe(data => {
      resolve(data);
    });
  });
}
/*
@author Manoj
This method is used to get the user detail by AgentId
@parameter
  agentId
return 
  this method retunr full user detail Except the wallet detail 
*/
getWalletDetailByAgentId(van,token){

  this.header = {
    headers: new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Bearer ' + token
    })
  }


  return new Promise(resolve => {
    this.httpClient.get(environment.walletDetailsVanBasis+van,this.header).subscribe(data => {
      resolve(data);
    });
  });
}

agentTokenValidateIDAM(){
  return new Promise(resolve => {
   
    this.httpClient.post(environment.openAMValidateAPI+localStorage.getItem("authToken")+'?_action=validate',{},
    {
    headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept-API-Version':'resource=1.0, protocol=1.0' 
    })
    }).subscribe(data => {
    resolve(data);
    });
    });
  }
}

