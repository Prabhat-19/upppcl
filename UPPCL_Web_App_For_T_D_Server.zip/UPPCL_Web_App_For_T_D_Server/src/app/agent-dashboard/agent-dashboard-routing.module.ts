import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgentDashboardComponent } from './agent-dashboard.component';

const route:Routes=[
  {path:'agent-dashboard',component:AgentDashboardComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
 ]
})
export class AgentDashboardRoutingModule { }
