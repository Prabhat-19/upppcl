import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgentDashboardComponent } from './agent-dashboard.component';
import { AgentDashboardRoutingModule } from './agent-dashboard-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule} from '../shared/shared.module';
import { NgxSpinnerModule } from "ngx-spinner";
import { OrderModule } from 'ngx-order-pipe';

@NgModule({
  declarations: [AgentDashboardComponent],
  imports: [
    CommonModule,
    AgentDashboardRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxSpinnerModule,
    OrderModule
  ]
})
export class AgentDashboardModule { }
