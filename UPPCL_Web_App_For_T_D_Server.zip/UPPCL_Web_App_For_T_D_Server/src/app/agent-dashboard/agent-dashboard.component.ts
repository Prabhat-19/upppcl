import { Component, OnInit, ViewChild, ElementRef,HostListener } from '@angular/core';
import { AgentDashboardService } from './agent-dashboard.service';
import { Router } from '@angular/router';
import { Pipe, PipeTransform } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { RegistrationService } from '../registration/registration.service';
import { environment } from '../../environments/environment';
import { TokenGenerateService} from '../token-generate.service'
import { AgentTransactionService } from '../agent-transaction/agent-transaction.service';
import { ignoreElements } from 'rxjs/operators';
import { HeaderService } from '../header/header.service';


@Pipe({
  name: "sort"
})

@Component({
  selector: 'app-agent-dashboard',
  templateUrl: './agent-dashboard.component.html',
  styleUrls: ['./agent-dashboard.component.scss']
})
export class AgentDashboardComponent implements OnInit {
  
  @ViewChild('imageInput',{static: false}) imageInput: ElementRef;	
  wallet: any;
  walletActivites=[];
  firstName: string;
  lastName: string
  element:any;	
  uploadProfilePicUrl:any;	
  profilePicUrl: string;
  agentDashboardData: any;
  van: string;
  datas:any;
  token: any;
  mobile:any;
  agentDashboardTransactionData:any;
  agentId:string;
  userName:any;
  activityArray:any;
  constructor(private headerService: HeaderService,private agentTransaction : AgentTransactionService,private tokenGenerate:TokenGenerateService,private registrationService: RegistrationService, private agentDashboardService: AgentDashboardService, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.checkUserTyper();
    this.tokenGenerate.afterLogin();
    this.spinner.hide();
    this.getAgentId();
    // document.getElementById('ledgerHistory').style.display = "";
    }

  getAgentId(){
    let userId = localStorage.getItem("userId");
     this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
    this.token = data;
    this.agentDashboardService.getAgentId(userId,this.token).then((data: any) => {
      if(data.length == 0){   
        this.modaldash();
      }
      this.agentId = data[0].id;
      this.agentLogin();
      localStorage.setItem("agentId", this.agentId);
    });
  });
  }
  modaldash() {
  $('#btncenterhide').click();
  };
  onupload(event:any){	
    event.preventDefault();	
    this.element =  this.imageInput.nativeElement;	
    this.element.click();	
  }	
  onChange(){	
    if (this.element.files && this.element.files[0]) {	
      var reader = new FileReader();	
      reader.addEventListener('load', (event: any) => {	
      $('.profile-pic').attr('src', event.target.result);	
      })	
      reader.readAsDataURL(this.element.files[0]);	
       }	
       this.spinner.show();	
       this.uploadPhoto();	
  }	
  uploadPhoto(){	
    return new Promise(resolve => {	
    let formData = new FormData();	
    formData.append('file', this.element.files[0]);	
    formData.append('extraField', "uploadPhoto");	
    // this.tokenGenerate.getToken(environment.fileUploadToken).then(data => {	
    //   this.token = data;	
    this.registrationService.uploadDocumentsService(formData).then(data => {	
      this.uploadProfilePicUrl = data;	
      this.uploadProfilePicUrl = this.uploadProfilePicUrl.fileDownloadUri;	
      this.tokenGenerate.getToken(environment.userToken).then(data => {	
        this.token = data;	
        this.agentDashboardService.fileUpdate(this.token.access_token,this.uploadProfilePicUrl).then(data => {	
          this.spinner.hide();	
        })	
      })	
    // });	
  })	
  });	
  }
  agentLogin() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.agentDashboardService.getUserDetail(this.agentId,this.token).then((data: any) => {
      this.agentDashboardData = data;
      if(this.agentDashboardData.user.imageUrl == ""||this.agentDashboardData.user.imageUrl==undefined){
        this.profilePicUrl = "../../assets/image/Dummy_Image.png";
      }
      else{
        this.profilePicUrl = data.user.imageUrl;	
      }
      this.wallet = data.balanceAmount;
      if(JSON.stringify(this.agentDashboardData).includes("agencyId")) 
      {
        localStorage.setItem("isSubAgent","Yes");
        localStorage.setItem("agencyIdForagencyName",data.agencyId);
      }
      else
      {
        localStorage.setItem("isSubAgent","No");
      }
      this.wallet = this.wallet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      this.firstName = data.user.firstName;
      this.lastName = data.user.lastName;
      this.van = data.van;
     this.mobile = data.user.mobile;
     this.userName = data.user.userName;
     localStorage.setItem("lastName",this.lastName);
    localStorage.setItem("van", this.van);
    localStorage.setItem("mobile", this.mobile);
    localStorage.setItem("firstName", this.firstName);
    localStorage.setItem("userName",this.userName);
    this.walletTransactionActivites();

    });
    });
      }
      
       walletTransactionActivites(){
         this.spinner.show();
        this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data => {
                this.datas = data;
                this.agentTransaction.getWalletDetailByAgentIds(this.datas.access_token).then((data: any) => {
                 for (var i = 0; i < data.content.length; i++) {
                  if ( data.content[i].status == "SUCCESS") {
                    if(data.content[i].type == "WalletTransaction"){
                      this.activityArray = "CREDIT";
                    }else{
                    for(var activityData =0; activityData < data.content[i].response.length;activityData++){
                      if(data.content[i].response[activityData].vanId != 'UPPCL'){
                      this.activityArray = data.content[i].response[activityData].activity;
                    }
                    }
                  }
                    data.content[i]['sourceActivity'] = this.activityArray;
                    this.walletActivites.push(data.content[i]);
                    this.agentDashboardTransactionData = this.walletActivites;
                  }
                 }
                 if(this.agentDashboardTransactionData == "" || this.agentDashboardTransactionData == undefined || this.agentDashboardTransactionData == null ){
                  //  document.getElementById('ledgerHistory').style.display = "";
                 }
               });
            });
            this.spinner.hide();
       }
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency") || (localStorage.getItem("userType") == null)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  rechargeWallet() {
    if (this.agentDashboardData.agencyId != undefined) {
      this.callModal("You are not authorized for this option.")
    }
    else { this.router.navigate(['/recharge-wallet']) }
  }
  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
  /**
   * logout method.
   * Navigate to login page.
   */
  logout() {
    this.headerService.deleteToken().then(data => {
      localStorage.clear();
      this.router.navigate(['/login']);
    });
  }
}
