import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { constant } from 'src/environments/constant';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TokenGenerateService {
  constructor(private httpClient:HttpClient,private router:Router) { }
  datas:any;
  settimeout:any;

  afterLogin() {
    this.settimeout =setInterval(() =>
    { 
      var href = window.location.href;
      href = href.split("/")[3];
      if(href !="login") {
        this.agentAuth();
        return;
      }
      if(href == "login" || href == "registration" || href == "forget-password") {
        this.setTime();
        return;
      }
    }, 900000);
  }

  setTime() {
    clearInterval(this.settimeout);
  }

  /**
   * IDAM authntication
   */
  agentAuth() {
    this.agentTokenValidateIDAM().then(data => {
      this.datas = data;
      if (!this.datas.valid) {
        localStorage.clear();
        this.router.navigate(["/login"]);
      }
    });
  }

  agentTokenValidateIDAM(){
    return new Promise(resolve => {
     
      this.httpClient.post(environment.openAMValidateAPI+localStorage.getItem("authToken")+'?_action=validate',{},
      {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept-API-Version':'resource=1.0, protocol=1.0' 
      })
      }).subscribe(data => {
      resolve(data);
      });
      });
    }



  getToken(token) {
    let url = environment.ws02TokenAuthAPI+'&username='+constant.adminWSO2UserName+'&password='+constant.adminWSO2Password;
   
    let promise = new Promise((resolve, reject) => {
    this.httpClient.post(url, {},
      {
        headers: new HttpHeaders({
          'content-type':'application/x-www-form-urlencoded',
          'Authorization':'Basic ' + token
        })
      }).toPromise().then(data => {
        resolve(data);
      }),msg => {
      }
    })
    return promise;
}
}
