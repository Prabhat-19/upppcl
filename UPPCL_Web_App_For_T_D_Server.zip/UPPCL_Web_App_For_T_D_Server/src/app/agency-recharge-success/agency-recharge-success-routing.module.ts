import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgencyRechargeSuccessComponent } from './agency-recharge-success.component'

const routes: Routes = [
  {path:'agency-recharge-success',component:AgencyRechargeSuccessComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgencyRechargeSuccessRoutingModule { }
