import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { validation  } from '../../environments/validationsMessage';

@Component({
  selector: 'app-agency-recharge-success',
  templateUrl: './agency-recharge-success.component.html',
  styleUrls: ['./agency-recharge-success.component.scss']
})
export class AgencyRechargeSuccessComponent implements OnInit {
  
  constructor(private agentDashboardService: AgentDashboardService, private router: Router) { }

  ngOnInit() {
    this.checkUserTyper();
    this.agentAuth();
  }

  
   /*
  This method is used to check the user role
  */

  checkUserTyper() {
    if ((localStorage.getItem("userType") == validation.upplcRoles.Agent) || (localStorage.getItem("userType") == validation.upplcRoles.UPPCL)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  
   /*
  This method is used to authenticate the user  
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
}
