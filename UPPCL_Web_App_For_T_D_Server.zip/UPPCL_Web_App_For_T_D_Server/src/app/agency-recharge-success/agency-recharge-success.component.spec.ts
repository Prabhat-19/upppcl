import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyRechargeSuccessComponent } from './agency-recharge-success.component';

describe('AgencyRechargeSuccessComponent', () => {
  let component: AgencyRechargeSuccessComponent;
  let fixture: ComponentFixture<AgencyRechargeSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyRechargeSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyRechargeSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
