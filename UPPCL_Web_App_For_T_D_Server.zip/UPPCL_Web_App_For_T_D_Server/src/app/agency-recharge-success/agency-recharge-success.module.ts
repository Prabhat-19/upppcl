import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgencyRechargeSuccessRoutingModule } from './agency-recharge-success-routing.module';
import { AgencyRechargeSuccessComponent } from './agency-recharge-success.component';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [AgencyRechargeSuccessComponent],
  imports: [
    CommonModule,
    AgencyRechargeSuccessRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule
  ]
})
export class AgencyRechargeSuccessModule { }
