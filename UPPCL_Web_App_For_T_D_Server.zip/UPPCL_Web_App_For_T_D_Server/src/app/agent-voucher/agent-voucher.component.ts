import { Component, OnInit, wtfStartTimeRange,HostListener } from '@angular/core';
import * as $ from 'jquery';
import { AgentVoucherService } from './agent-voucher.service'
import { delay } from 'rxjs/operators';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import {environment} from '../../environments/environment';
import {TokenGenerateService} from '../token-generate.service'

@Component({
  selector: 'app-agent-voucher',
  templateUrl: './agent-voucher.component.html',
  styleUrls: ['./agent-voucher.component.scss']
})
export class AgentVoucherComponent implements OnInit {
  
  //#region variable declaration
  oneThousand: number = 0;
  fiveHundred: number = 0;
  twoHundred: number = 0;
  oneHundred: number = 0;
  numberOfVoucher: number = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
  totalAmount: number = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
  balance: any;
  voucher: any;
  datas: any;
  rechargeAmount: number;
  balances: any;
  Url: any;
  data:any;
  //#region variable declaration end


  //#region constructor
  constructor(private tokenGenerate:TokenGenerateService ,private router: Router, private agentDashboardService: AgentDashboardService, private voucherService: AgentVoucherService) { }
  //#region end

  //#region ngOninit start
  ngOnInit() {
    this.walletBalance();
    // this.getAllVoucher();
    this.activeTab();

    // show & hide bill
    $(document).ready(function () {
      $('#mysubmit').on('click', function () {
        var form = <HTMLElement>(document.getElementById("showbill"));
        if (form.style.display == "block") {
          form.style.display = "none";
        }
        else {
          form.style.display = "block";
        }
      })
      // End of show & hide bill
    });


  }
  //#region ends

  
  //#region Method start

  //#region code to display pop alert
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').trigger('click');
    })
  }
  //#region end


  //#region To get all voucher.
  // getAllVoucher() {
  //   this.voucherService.availableVoucher().then((data: any) => {
  //     this.voucher = data;
  //   })
  // }
  //#region To get all voucher end

  //#region To get wallet balance
  walletBalance() {
    this.voucherService.balance().then((data: any) => {
      this.balance = data.wallet.balance;
      this.balances = (this.balance).toLocaleString('en-GB');
    })
  }
  //#region end

  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => console.log("fired"));
  }

  // geneateVoucher() {
  //   this.rechargeAmount = this.totalAmount / this.numberOfVoucher;
  //   this.voucherService.generateDenomination(this.rechargeAmount, this.numberOfVoucher).then((data: any) => {
  //     this.datas = data;
  //     this.Url = this.datas.location;
  //     this.tokenGenerate.getToken(environment.transactionCreditToken).then(data => {
  //       this.data = data;
  //     this.voucherService.getDetails(this.Url,this.data.access_token).then((help: any) => {
  //       if (JSON.stringify(help).includes("IN_QUEUE")) {
  //         this.callModal("Voucher generated successfully", "Alert");
  //         (<HTMLInputElement>document.getElementById("oneHundred")).value = "0";
  //         (<HTMLInputElement>document.getElementById("twoHundred")).value = "0";
  //         (<HTMLInputElement>document.getElementById("fiveHundred")).value = "0";
  //         (<HTMLInputElement>document.getElementById("oneThousand")).value = "0";
  //         this.totalAmount = 0;
  //         this.numberOfVoucher = 0;
  //         this.oneThousand = 0;
  //         this.fiveHundred = 0;
  //         this.twoHundred = 0;
  //         this.oneHundred = 0;
  //         this.delay(3000).then(any => {
  //           this.walletBalance();
  //           this.getAllVoucher();
  //         });
  //       }
  //       else {
  //         this.callModal("Something went wrong.Please try letter", "Alert");
  //       }

  //     })
  //   })
    // })
  // }



  //#region start increare or decrease code for 1000
  minusOneThousand() {
    if (this.oneThousand > 0) {
      this.oneThousand = (this.oneThousand - 1);
      this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
      this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
    }
  }

  plusOneThousand() {
    if (this.balance >= this.totalAmount + 1000) {
      if ((this.oneHundred == 0) && (this.fiveHundred == 0) && (this.twoHundred == 0)) {
        this.oneThousand = (this.oneThousand + 1);
        this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
        this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
      }
      else {
        this.callModal("Only one denomination can be generated at a time.", "Alert");
      }
    }
    else {
      this.callModal("Your wallet balance is low.Please recharge your wallet first!", "Alert");
    }
  }
  //#region end

  //#region start increare or decrease code for 500
  minusFiveHundred() {
    if (this.fiveHundred > 0) {
      this.fiveHundred = (this.fiveHundred - 1);
      this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
      this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
    }

  }

  plusFiveHundred() {
    if (this.balance >= this.totalAmount + 500) {
      if ((this.oneHundred == 0) && (this.oneThousand == 0) && (this.twoHundred == 0)) {
        this.fiveHundred = (this.fiveHundred + 1);
        this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
        this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
      }
      else {
        this.callModal("Only one denomination can be generated at a time.", "Alert");
      }
    }
    else {
      this.callModal("Your wallet balance is low.Please recharge your wallet first!", "Alert");
    }
  }
  //#region end

  //#region start increare or decrease code for 200
  minusTwoHundred() {
    if (this.twoHundred > 0) {
      this.twoHundred = (this.twoHundred - 1);
      this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
      this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
    }

  }

  plusTwoHundred() {
    if (this.balance >= this.totalAmount + 200) {
      if ((this.oneHundred == 0) && (this.oneThousand == 0) && (this.fiveHundred == 0)) {
        this.twoHundred = (this.twoHundred + 1);
        this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
        this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
      }
      else {
        this.callModal("Only one denomination can be generated at a time.", "Alert");
      }
    }
    else {
      this.callModal("Your wallet balance is low.Please recharge your wallet first!", "Alert");
    }
  }
  //#region end

  //#region start increare or decrease code for 100
  minusOneHundred() {
    if (this.oneHundred > 0) {
      this.oneHundred = (this.oneHundred - 1);
      this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
      this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
    }
  }

  plusOneHundred() {
    if (this.balance >= this.totalAmount + 100) {
      if ((this.fiveHundred == 0) && (this.oneThousand == 0) && (this.twoHundred == 0)) {
        this.oneHundred = (this.oneHundred + 1);
        this.numberOfVoucher = this.oneThousand + this.fiveHundred + this.twoHundred + this.oneHundred;
        this.totalAmount = ((this.oneThousand * 1000) + (this.fiveHundred * 500) + (this.twoHundred * 200) + (this.oneHundred * 100));
      }
      else {
        this.callModal("Only one denomination can be generated at a time.", "Alert");
      }
    }
    else {
      this.callModal("Your wallet balance is low.Please recharge your wallet first!", "Alert");
    }
  }
  //#region end

  //#region Method end
  activeTab() {
    $('#nav-home-tab').css('background-color', '#246aaf');
    $('#nav-home-tab').click(function () {
      $('#nav-home-tab').css('background-color', '#246aaf');
      $('#nav-about-tab').css('background-color', '#6f8294');
      $('#nav-profile-tab').css('background-color', '#6f8294');
    })
    $('#nav-profile-tab').click(function () {
      $('#nav-profile-tab').css('background-color', '#246aaf');
      $('#nav-home-tab').css('background-color', '#6f8294');
      $('#nav-about-tab').css('background-color', '#6f8294');
    })
    $('#nav-about-tab').click(function () {
      $('#nav-about-tab').css('background-color', '#246aaf');
      $('#nav-profile-tab').css('background-color', '#6f8294');
      $('#nav-home-tab').css('background-color', '#6f8294');
    })
  }
}
