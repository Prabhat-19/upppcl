import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentVoucherComponent } from './agent-voucher.component';

describe('AgentVoucherComponent', () => {
  let component: AgentVoucherComponent;
  let fixture: ComponentFixture<AgentVoucherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentVoucherComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentVoucherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
