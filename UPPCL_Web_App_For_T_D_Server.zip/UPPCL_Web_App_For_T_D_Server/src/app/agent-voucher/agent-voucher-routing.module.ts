import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgentVoucherComponent } from './agent-voucher.component';

const route:Routes=[
  {path:'agent-voucher',component:AgentVoucherComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AgentVoucherRoutingModule { }
