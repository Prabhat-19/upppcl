import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { reject } from 'q';

@Injectable({
  providedIn: 'root'
})
export class AgentVoucherService {

  header:any;


  constructor(private http: HttpClient) { }

  balance() {
    let promise = new Promise((resolve,reject) => {
      const Url = 'http://49.50.81.110:9999/api/wallet/agent/' + localStorage.getItem("agentId");
      this.http.get(Url).toPromise().then((data: any) => {
        resolve(data);
      },
        msg => {
          reject(msg);
        })
    })
    return promise;
  }

  //#region code to display pop alert
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("p").text(message);
      $('#btnhide').trigger('click');
    })
  }
  //#region end



  // availableVoucher() {
  //   let promise = new Promise((resolve, reject) => {
  //     this.http.get(environment.voucherForParticularAgent + localStorage.getItem("agentId")).toPromise().then((data: any) => {
  //       resolve(data);
  //     },
  //       msg => {
  //         reject(msg);
  //       })
  //   })
  //   return promise;
  // }

  // getDetails(Url,token) {

  //   this.header = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/x-www-form-urlencoded',
  //       'Authorization': 'Bearer ' + token
  //     })
  //   }


  //   return new Promise(resolve => {
  //     var url = environment.getStatusForTransaction + Url;
  //     console.log("url <==>" + url);
  //     this.http.get(url).subscribe(datas => {
  //       resolve(datas);
  //     });
  //   });
  // }

  // generateDenomination(amount, quantity) {
  //   if (amount > 0) {
  //     let promise = new Promise((resolve, reject) => {
  //       this.http.post(environment.generateVoucherForAgent, {
  //         "agentId": localStorage.getItem("agentId"),
  //         "amount": amount,
  //         "number": quantity
  //       }).toPromise().then((data: any) => {
  //         resolve(data);
  //       },
  //         msg => {
  //           this.callModal("Something went wrong.Please try letter", "Alert");
  //           reject(msg);
  //         })
  //     })
  //     return promise;
  //   }
  //   else {
  //     this.callModal("Entered amount should be in mentioned denomination.", "Alert");
  //   }
  // }
}
