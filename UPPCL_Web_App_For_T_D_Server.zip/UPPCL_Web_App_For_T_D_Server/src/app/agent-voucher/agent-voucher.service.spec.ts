import { TestBed } from '@angular/core/testing';

import { AgentVoucherService } from './agent-voucher.service';

describe('AgentVoucherService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentVoucherService = TestBed.get(AgentVoucherService);
    expect(service).toBeTruthy();
  });
});
