import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ForgetPasswordService {
  forgetpassword:any;
  userName: any;
  constructor(private http: HttpClient) { }

  generateToken(userName) {
    this.userName = userName;
    this.userName = this.userName.toLowerCase();
    let promise = new Promise((resolve, reject) => {

       var payload = 
       {
        "input": {
          "queryFilter": "uid eq \"" + this.userName + "\""
        }
      };
      this.http.post(environment.getTokenForForgetPassword, payload,
        {
          headers: new HttpHeaders({
            //'Content-Type': 'application/json',
            'Accept-API-Version': 'resource=1.0,protocol=1.1'
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
            resolve(msg);
          }
        )
    })
    return promise;
  }

  restPassword(token, password) {
    this.forgetpassword = password
    let promise = new Promise((resolve, reject) => {

      var payload = {
        "input": {
          "password": password
        },
        "token": token
      };
      this.http.post(environment.getTokenForForgetPassword, payload,
        {
          headers: new HttpHeaders({
            //'Content-Type': 'application/json',
            'Accept-API-Version': 'resource=1.0,protocol=1.1'
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
            resolve(msg);
          }
        )
    })
    return promise;
  }

  getDetails(key) {

    const token = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + key
      })
    }

    let promise = new Promise((resolve, reject) => {
      this.http.get(environment.agentValidate + this.userName, token).toPromise().then(data => {
        resolve(data);
      },
        msg => {
          resolve(msg);
        })
    })
    return promise;
  }

  sendEmail(firstName: string, lastName: string, email: string,token :string ,password : string  ) {
    firstName = firstName.charAt(0).toUpperCase() + firstName.substring(1);
    lastName = lastName.charAt(0).toUpperCase() + lastName.substring(1);

    let promise = new Promise((resolve, reject) => {

      var payload = {
        "templateId": "FORGET_PASSWORD",
        "fields": [
          {
            "key": "lastName",
            "value": lastName
          },
          {
            "key": "email",
            "value": email
          },
          {
            "key": "password",
            "value": password
          },
          {
            "key": "firstName",
            "value": firstName
          }
        ]
      };

      this.http.post(environment.sendPassword, payload,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
            resolve(msg);
          }
        )
    })
    return promise;
  }
}
