import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
import { ForgetPasswordComponent } from './forget-password.component';
import { ForgetPasswordRoutingModule } from './forget-password-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { NgxSpinnerModule } from "ngx-spinner";


@NgModule({
  declarations: [ForgetPasswordComponent],
  imports: [
    CommonModule,
    ForgetPasswordRoutingModule,
    FormsModule,
   RouterModule,
   SharedModule,
   NgxSpinnerModule
  ]
})
export class ForgetPasswordModule { }
