import { Component, OnInit } from '@angular/core';
import { Router, NavigationStart, NavigationEnd,Event } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { ForgetPasswordService } from './forget-password.service';
import { NgxSpinnerService } from "ngx-spinner";
import { validation } from 'src/environments/validationsMessage';
import { environment } from '../../environments/environment';
import { TokenGenerateService } from '../token-generate.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  // showLoadingIndicator = true;
  datas: any;
  constructor(private tokenGenerate: TokenGenerateService, private forgetPasswordService: ForgetPasswordService, private spinner: NgxSpinnerService, private agentDashboardService: AgentDashboardService, private router: Router) { }

  ngOnInit() {
    this.checkUserTyper();
    // this.router.events.subscribe((routerEvent: Event) => {
    //   if (routerEvent instanceof NavigationStart) {
    //     this.showLoadingIndicator = true;
    //   }
    //   if (routerEvent instanceof NavigationEnd) {
    //     this.showLoadingIndicator = false;
    //   }
    // })
  }
  /*
    This method is used to check user role
    */

  checkUserTyper() {
    if ((localStorage.getItem("userType") == validation.upplcRoles.UPPCL) || (localStorage.getItem("userType") == validation.upplcRoles.agency)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  /*
  This method is used to generate token
  */
  generateToken() {
    this.spinner.show();
    this.forgetPasswordService.generateToken((<HTMLInputElement>document.getElementById("userName")).value).then((data: any) => {
      if (JSON.stringify(data).includes("Unable to find account")) {
        this.spinner.hide();
        this.callModal(validation.pleaseEnterCorrectUserName, "Alert");
      }
      else {
        var password = Math.random().toString(36).slice(-8);
        this.forgetPasswordService.restPassword(data.token, password).then((dataToken: any) => {

          if (JSON.stringify(dataToken).includes("Snapshot token is invalid")) {
            this.spinner.hide();
            this.callModal(validation.somethingWentWrongMessage, "Alert");
          }
          else {
            this.tokenGenerate.getToken(environment.userToken).then(data => {
              this.datas = data;
              this.forgetPasswordService.getDetails(this.datas.access_token).then((dataInfo: any) => {
                this.tokenGenerate.getToken(environment.notifyUserToken).then(data => {
                  this.datas = data;
                  this.forgetPasswordService.sendEmail(dataInfo[0].firstName, dataInfo[0].lastName, dataInfo[0].email, this.datas.access_token,password).then(dataForPassword => {

                    if (JSON.stringify(dataForPassword).includes("Message Sent")) {
                      $("#userName").val('');
                      this.callModal(validation.passwordHasBeenSentOnEmail, "Alert");
                      this.spinner.hide();
                    }
                    else {
                      $("#userName").val('');
                      this.spinner.hide();
                    }
                  })
                })
              })
            })
          }
        })
      }
    })
  }


}
