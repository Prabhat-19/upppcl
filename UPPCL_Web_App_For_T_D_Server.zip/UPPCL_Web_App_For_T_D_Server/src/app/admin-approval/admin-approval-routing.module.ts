import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AdminApprovalComponent } from './admin-approval.component';

const route:Routes=[
  {path:'admin-approval',component:AdminApprovalComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AdminApprovalRoutingModule { }
