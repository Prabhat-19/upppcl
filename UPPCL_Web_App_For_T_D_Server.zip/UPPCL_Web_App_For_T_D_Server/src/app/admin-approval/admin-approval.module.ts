import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
// import {AdminHeaderComponent} from '../admin-header/admin-header.component'
import { AdminApprovalComponent } from './admin-approval.component';
import { AdminApprovalRoutingModule } from './admin-approval-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import {NgxSpinnerModule} from 'ngx-spinner';
import { Ng2SearchPipeModule } from 'ng2-search-filter';   
import { DatePipe } from '@angular/common';
// import {NgxPaginationModule} from 'ngx-pagination'; 

@NgModule({
  declarations: [AdminApprovalComponent],
  imports: [
    CommonModule,
    AdminApprovalRoutingModule,
    FormsModule,
    RouterModule,
    NgxSpinnerModule,
    SharedModule,
    ScrollingModule,
    OrderModule,
    Ng2SearchPipeModule,
    // NgxPaginationModule,
  ],
  providers: [DatePipe]

})
export class AdminApprovalModule { }
