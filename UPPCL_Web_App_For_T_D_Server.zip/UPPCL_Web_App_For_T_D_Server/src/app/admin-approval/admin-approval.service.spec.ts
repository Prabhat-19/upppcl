import { TestBed } from '@angular/core/testing';

import { AdminApprovalService } from './admin-approval.service';

describe('AdminApprovalService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminApprovalService = TestBed.get(AdminApprovalService);
    expect(service).toBeTruthy();
  });
});
