import { Component, OnInit,HostListener } from '@angular/core';
import { AdminApprovalService } from './admin-approval.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
import {NgxSpinnerService} from 'ngx-spinner';
declare var $: any;
import { DatePipe } from '@angular/common';
import { combineAll } from 'rxjs/operators';

@Component({
  selector: 'app-admin-approval',
  templateUrl: './admin-approval.component.html',
  styleUrls: ['./admin-approval.component.scss']
})
export class AdminApprovalComponent implements OnInit {
  
  allRegisteredData: any;
  filterData = [];
  datas: any;
  filterapprovalDate: any;
  pendingDate= [];
  allData:any;
  searchString:any;
  filterUserType:any;
  filterFirstName:any;
  filterLastName:any;
  filterMobileNumber:any;
  filterStatus:any;
  filterFromDate:any;
  filterToDate:any;
  config:any;
  constructor( private spinner:NgxSpinnerService,public datepipe: DatePipe,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private router: Router, private adminApproval: AdminApprovalService) { 
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      // totalItems: this.collection.count
    };
  }
  ngOnInit() {
    this.agentAuth();
    this.checkUserTyper();
    this.getAllRegisteredAgentsData();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  

  getAllRegisteredAgentsData() {
    let arr = [];
    let arr1 = [];
    this.spinner.show();
    this.tokenGenerate.getToken(environment.agentRequestToken).then(data => {
      this.datas = data;
    this.adminApproval.getAllData(this.datas.access_token).then(data => {
    this.allData = data;
      for (var i = 0; i < this.allData.length; i++) {
        if (this.allData[i].status == "PENDING_MAIL_VERIFICATION" || this.allData[i].status == "PENDING_LEVEL_1_APPROVAL" || this.allData.status == "IN_PROGRESS") { this.allData[i].status = "PENDING"; }
        else if (this.allData[i].status == "PENDING_LEVEL_2_APPROVAL") { this.allData[i].status = "PENDING FOR APPROVAL II"; }
        else if (this.allData[i].status == "FULFILLED") { this.allData[i].status = "APPROVED"; }
        
        if (this.allData[i].agencyId == undefined ) {
          arr.push(this.allData[i])
          if (this.allData[i].status == "PENDING" || this.allData[i].status == "REJECTED" || this.allData[i].status == "PENDING FOR APPROVAL II") {
            if (localStorage.getItem('userName') == environment.lokeshEmail) {
              if (this.allData[i].status == "PENDING" || this.allData[i].status == "PENDING FOR APPROVAL II") {
                arr1.push(this.allData[i]);
                this.filterapprovalDate=arr1;
              }
            }
            else if (localStorage.getItem('userName') == environment.neerajEmail) {
              if (this.allData[i].status == "PENDING FOR APPROVAL II") {
                arr1.push(this.allData[i]);
                this.filterapprovalDate=arr1;
              }
            }
          }
        }
      }
      this.allRegisteredData = arr1;
      this.pendingDate = this.allRegisteredData;
      if (this.allRegisteredData == "" || this.allRegisteredData == undefined) {
        document.getElementById("ledgerHistory").style.display = "";
      }
    });
  })
  this.spinner.hide();
  }
  onSubmit(){
    this.filterData = [];
    for(var agentTranscationLoop = 0 ; agentTranscationLoop < this.pendingDate.length ; agentTranscationLoop++)
    {
    // if(this.addData1[agentTranscationLoop].status == "SUCCESS"){
  
  
  if(this.filterUserType ==null)
  {
  this.filterUserType="";
  }
  if( (this.filterFromDate > this.filterToDate)){
    this.callModal("Invalid Date Range.");
    this.filterFromDate = "";
    this.filterToDate = "";
  }
  if(this.filterToDate != null){
    let newDate = new Date(this.filterToDate);  
    var nextDate = new Date(newDate.getTime()+1000*60*60*24);
    }
    if(this.filterUserType == null || (this.filterUserType != null && this.pendingDate[agentTranscationLoop].agentType.toUpperCase().includes(this.filterUserType.toUpperCase()))
      && ( this.filterStatus == null || (this.filterStatus != null && this.pendingDate[agentTranscationLoop].status.toUpperCase() == (this.filterStatus.toUpperCase())))
      && (this.filterFirstName == null || (this.filterFirstName != null && this.pendingDate[agentTranscationLoop].firstName.toUpperCase().includes(this.filterFirstName.toUpperCase())))
      && (this.filterLastName == null || (this.filterLastName != null && this.pendingDate[agentTranscationLoop].lastName.toUpperCase().includes(this.filterLastName.toUpperCase())))
      && (this.filterMobileNumber == null || (this.filterMobileNumber != null && this.pendingDate[agentTranscationLoop].mobile.includes(this.filterMobileNumber)))
      // && (this.filterDistrict == null || (this.filterDistrict != null && this.allData[agentTranscationLoop].address.district==(this.filterDistrict)))
      // && (this.filterWalletBalance == null || (this.filterWalletBalance != null && this.allData[agentTranscationLoop].balanceAmount.includes(this.filterWalletBalance.toUpperCase())))
      &&(this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') != null && this.pendingDate[agentTranscationLoop].modifiedAt >= (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd'))))
      &&(this.datepipe.transform(nextDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(nextDate, 'yyyy-MM-dd') != null && this.pendingDate[agentTranscationLoop].modifiedAt <= (this.datepipe.transform(nextDate, 'yyyy-MM-dd'))))
      )
      {
      this.filterData.push(this.pendingDate[agentTranscationLoop])
      }
    }
  this.allRegisteredData = this.filterData;
  }
  
  clear()
  {
    this.filterData = [];
    this.filterUserType=null;
    this.filterStatus=null;
    this.filterFirstName=null;
    this.filterLastName=null;
    this.filterMobileNumber=null;
    this.filterToDate=null;
    this.filterFromDate=null;
    this.allRegisteredData =  this.pendingDate;
  }
  

  callModal(message: string) {
    $(document).ready(function () {
      $("#modalText").text(message);
      $('#btnhide').click();
    })
  }

  
  // pageChanged(event){
  //   this.config.currentPage = event;
  // }

  disableLink() {
    $(document).ready(function () {
      $('.deleteDetails').each(function (i, v) {
        var pn = $(this).closest('td').prev('td').text();
        if (pn == "APPROVED") {
          $(this).attr('disabled', 'disabled');
          $(this).removeClass('btn btn-danger btn-xs');
          $(this).css('background-color', '#ccc');

        }
        else {
          $(this).removeAttr; ('disabled');
          $(this).addClass('btn btn-danger btn-xs');
        }
      })
    })
  }
  editDetails(ID) {
    this.router.navigate(['/admin-edit']);
    localStorage.setItem("adminId", ID);
  }
  deleteDetails(ID) {
    localStorage.setItem('deleteID', 'ID');
    var x = document.getElementsByClassName("deleteDetails");
    this.confirmationModal();
  }
  delete(ID) {
    this.tokenGenerate.getToken(environment.agentRequestToken).then(data => {
      this.datas = data;
    this.adminApproval.delete(localStorage.getItem('deleteID'),this.datas.access_token).then(data => {
    });
  })
  }
  confirmationModal() {
    $(document).ready(function () {
      $("#exampleModalCenter").modal();
    });
  }
}


