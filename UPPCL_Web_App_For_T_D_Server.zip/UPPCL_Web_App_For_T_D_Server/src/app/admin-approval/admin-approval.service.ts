import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminApprovalService {
getAllAgentData:string;
header:any;
constructor(private http: HttpClient) { }
  
  getAllData(token){

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }

    return new Promise(resolve => {
     this.http.get(environment.editAgentDetails,this.header).subscribe((data: any) => {
     this.getAllAgentData=data;
     resolve(data);
     });
 });
  }

  delete(ID,token){

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }

    return new Promise(resolve => {
    this.http.delete(environment.deleteAgent+ID,this.header).subscribe((data: any) => {
      resolve(data);
      });
  });
  }
 }



 