import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RechargeWalletService {
  walletId: any;
  constructor(private http: HttpClient) { }
  


  rechargeWalletFromIciciLanding(amount,token,transactionId) {
    var payload= {
      "agentId": localStorage.getItem("agentId"),
      "amount": amount,
      "sourceType": "BANK",
      "transactionId": transactionId,
      "walletId": localStorage.getItem("van")
    }
  //  var payload = {
  //     "agentId": "5d281e9b47ca40d6849c43ece5de9749",
  //     "amount": 1000,
  //     "sourceType": "BANK",
  //     "transactionId": "ICICI-124578",
  //     "walletId": "UPCA3883234212"
  //   }
    return new Promise(resolve => {
      this.http.post(environment.agentRechargeWallet,payload,
      {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        })
      }).subscribe(data => {
        resolve(data);
      });
    });
  }

  icicIntegrationService(amount: string,token) {
    return new Promise((resolve, reject) => {
      this.http.post(environment.icicIntegrationService,
        {
          "transactionAmount": amount,
          "vanNo": localStorage.getItem("van")
        },{
          headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + token.access_token
          })
      }


      ).toPromise().then(data => {
        resolve(data);
      },
        msg => {
          reject(msg);
        }
      )
    })
  }

  recharge(amount) {
    return new Promise(resolve => {
      this.http.post(environment.agentRechargeWallet, {
        "agentId": localStorage.getItem("agentId"),
        "amount": amount,
        "sourceType": "WALLET",
        "walletId": this.walletId,
      }).subscribe(data => {
        resolve(data);
      });
    });
  }
}
