import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { RechargeWalletComponent } from './recharge-wallet.component';
const route:Routes=[
  {path:'recharge-wallet',component:RechargeWalletComponent}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class RechargeWalletRoutingModule { }
