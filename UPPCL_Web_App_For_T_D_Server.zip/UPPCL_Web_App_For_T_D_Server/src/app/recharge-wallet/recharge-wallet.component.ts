import { Component, OnInit,HostListener } from '@angular/core';
import { RechargeWalletService } from './recharge-wallet.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { validation } from 'src/environments/validationsMessage';
import { TokenGenerateService} from '../token-generate.service'
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-recharge-wallet',
  templateUrl: './recharge-wallet.component.html',
  styleUrls: ['./recharge-wallet.component.scss']
})
export class RechargeWalletComponent implements OnInit {
 
  selectedValue = "Select one";
  wallet: any;
  token:any;
  datas:any;
  constructor(private spinerService :NgxSpinnerService,private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private walletRecharge: RechargeWalletService, private router: Router) { }
  ngOnInit() {
    this.agentAuth();
this.walletBalance();
  }

  /*
  This method is used to authenticate the user
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /*
  This method is used to download the form
  */
  downloadBankForm() {
    if (($('#mySelect3').val()) == null || ($('#mySelect2').val()) == null) {
      this.callModal(validation.enterRequiredField);
    }
    else {
      const link = document.createElement('a');
      link.setAttribute('target', '_blank');
      link.setAttribute('href', validation.ICICIBankNEFTRTGS_FormPath);
      link.setAttribute('download', `ICICI_Bank_NEFT-RTGS_Form.pdf`);
      document.body.appendChild(link);

      link.click();
      link.remove();
      this.clearForm();
    }
  }

  /*
  This method is used to clear the form value
  */
  clearForm() {
    $('#mySelect2').val('Select One');
    $('#mySelect3').val('Select One');
    $('#border-round').val('Select One');

  }


  /*
  This method is used to select the payment value
  */
  paymentModeDropdown(element) {
    if (this.selectedValue == "Select one") {
      this.callModal(validation.PleaseSelectPaymentMode)
    }
    else if (element == "2000") {
      $('#displayamount').val('2000');
      $('#valuedisplay2000').css('background-color', '#a5dd4a');
      $('#valuedisplay5000').css('background-color', '');
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
    }
    else if (element == "5000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
      $('#displayamount').val('5000');
      $('#valuedisplay5000').css('background-color', '#a5dd4a');
    }
    else if (element == "10000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay5000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
      $('#displayamount').val('10000');
      $('#valuedisplay10000').css('background-color', '#a5dd4a');
    }
    else if (element == "15000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay5000').css('background-color', '');
      $('#displayamount').val('15000');
      $('#valuedisplay15000').css('background-color', '#a5dd4a');
    }
  }

  /*
  This method is used fetch wallet details
  */
  walletBalance() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.agentDashboardService.getUserDetail(localStorage.getItem("agentId"),this.token).then((data: any) => {
      this.wallet = data.balanceAmount;
      this.wallet = this.wallet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
    });
    // this.walletRecharge.getBalance().then((data: any) => {
    //   this.wallet = data.wallet.balance;
    //   this.wallet = this.wallet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    // })
  }

  /*
  This method is used to recharge the wallet
  */
  rechargeWallet(agentRechargeWalletToken) {
    
    this.tokenGenerate.getToken(environment.agentRechargeWalletToken).then(data => {
      this.token = data;
    localStorage.setItem("rechargeAmount",  (document.getElementById("displayamount") as HTMLInputElement).value);
    if (($('#mySelect').val()) == null ||  (document.getElementById("displayamount") as HTMLInputElement).value == "") {
      this.callModal(validation.enterRequiredField);
    }
    else {
      this.spinerService.show();
      this.walletRecharge.icicIntegrationService( (document.getElementById("displayamount") as HTMLInputElement).value,this.token).then((data: any) => {
        localStorage.setItem('encryptedUrl', data.url);
        this.router.navigate(['/paymentgateway-landingpage']);


      })
    }
  })
  }
  /*
  This method is used to detect which key is pressed
  */
  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
  /*
  This method is used to check user role
  */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == validation.upplcRoles.UPPCL) || (localStorage.getItem("userType") == validation.upplcRoles.agency)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }



}
