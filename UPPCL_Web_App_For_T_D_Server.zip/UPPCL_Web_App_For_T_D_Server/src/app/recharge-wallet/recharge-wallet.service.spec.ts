import { TestBed } from '@angular/core/testing';

import { RechargeWalletService } from './recharge-wallet.service';

describe('RechargeWalletService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RechargeWalletService = TestBed.get(RechargeWalletService);
    expect(service).toBeTruthy();
  });
});
