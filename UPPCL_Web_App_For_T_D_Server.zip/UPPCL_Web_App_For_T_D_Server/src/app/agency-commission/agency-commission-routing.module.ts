import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgencyCommissionComponent } from './agency-commission.component';

const routes: Routes = [
  {path:'agency-commission',component:AgencyCommissionComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgencyCommissionRoutingModule { }
