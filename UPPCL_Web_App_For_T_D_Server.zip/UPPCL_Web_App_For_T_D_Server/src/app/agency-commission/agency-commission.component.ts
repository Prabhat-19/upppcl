import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { AgentEarningService } from '../agent-earning/agent-earning.service';
import { environment } from 'src/environments/environment';
import {GenerateTokenService} from '../generate-token/generate-token.service'
import {TokenGenerateService} from '../token-generate.service'
import { combineAll } from 'rxjs/operators';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-agency-commission',
  templateUrl: './agency-commission.component.html',
  styleUrls: ['./agency-commission.component.scss']
})
export class AgencyCommissionComponent implements OnInit {
  
  agentEarningData: any;
  agentEarningFilterData: any;
  filterData: any;
  Result: any;
  startDate: any;
  endDate: any;
  datas: any;
  textFeildData: any;
  config:any
  token:any;
  totalCommission = 0;

  filterWalletId:any;
  filterTransactionId:any;
  filterAmount:any;
  filterDiscom:any;
  filterDivision:any;
  filterToDate: any;
  filterCommission:any;
  filterFromDate: any;
  filterSource = "Source";
  typeSelectedValue = "Type";
  statusSelectedValue= "Status";

  filterDataForReset = [];
  


  constructor( public datepipe: DatePipe,private tokenService : TokenGenerateService,private generateTokenService:GenerateTokenService, private agentEarningService: AgentEarningService, private excelService: ExcelServiceService, private agentDashboardService: AgentDashboardService, private router: Router) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
     };
   }

  ngOnInit() {
    this.agentAuth();
      this.oncommission();
    this.checkUserTyper();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  

  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  clear() {
    this.filterData = [];
    this.filterTransactionId = null;
    this.filterAmount = null;
    this.filterWalletId = null;
    this.typeSelectedValue = 'Type';
    this.filterDiscom = null;
    this.filterDivision = null;
    this.filterSource = "Source";
    this.statusSelectedValue = 'Status';
    this.filterToDate = null;
    this.filterCommission= null;
    this.filterFromDate = null;
    this.agentEarningFilterData = this.filterDataForReset;
  }

  checkUserTyper() {
    if ((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agent")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  onSubmit() {
    this.agentEarningFilterData = this.filterDataForReset;
    var self = this;
    this.filterData = [];
    
    for (var agentTranscationLoop = 0; agentTranscationLoop < self.agentEarningFilterData.length; agentTranscationLoop++) {
      if (this.filterTransactionId == null) {
          this.filterTransactionId = "";
        }
        if(this.filterToDate != null){
        var newDate = new Date(this.filterToDate);
        }
        if( (this.filterFromDate > this.filterToDate)){
          this.callModal("Invalid Date Range.");
          this.filterFromDate = "";
          this.filterToDate = "";
        }
        if (this.filterTransactionId == null || (this.filterTransactionId != null && self.agentEarningFilterData[agentTranscationLoop].externalTransactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
          && (this.filterDivision == null || (this.filterDivision != null && self.agentEarningFilterData[agentTranscationLoop].division.includes(this.filterDivision)))
          && (this.filterWalletId == null || (this.filterWalletId != null && self.agentEarningFilterData[agentTranscationLoop].externalId.toUpperCase().includes(this.filterWalletId.toUpperCase())))
          && (this.typeSelectedValue == 'Type' || (this.typeSelectedValue != 'Type' && self.agentEarningFilterData[agentTranscationLoop].activity.includes(this.typeSelectedValue.toUpperCase())))
          && (this.filterDiscom == null || (this.filterDiscom != null && self.agentEarningFilterData[agentTranscationLoop].discom.includes(this.filterDiscom.toUpperCase())))
          && (this.filterCommission == null || (this.filterCommission != null && self.agentEarningFilterData[agentTranscationLoop].commission ==(Number(this.filterCommission)))
          && (this.filterAmount == null || (this.filterAmount != null && self.agentEarningFilterData[agentTranscationLoop].amount == (Number(this.filterAmount)))))
          && (this.filterSource == 'Source' || (this.filterSource != 'Source' && self.agentEarningFilterData[agentTranscationLoop].transactionType.includes(this.filterSource.toUpperCase())))
          && (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.datepipe.transform(this.agentEarningFilterData[agentTranscationLoop].time, 'dd-MM-yyyy') >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy'))))
          && (this.datepipe.transform(newDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(newDate, 'dd-MM-yyyy') != null && this.datepipe.transform(this.agentEarningFilterData[agentTranscationLoop].time, 'dd-MM-yyyy') <= (this.datepipe.transform(newDate, 'dd-MM-yyyy'))))
        ) {
          this.filterData.push(this.agentEarningFilterData[agentTranscationLoop])
        }
    }
    this.agentEarningFilterData = this.filterData;
  }

  pageChanged(event){
    this.config.currentPage = event;
  }

  oncommission() {
    let arr = [];
    this.tokenService.getToken(environment.agentTransactionStateToken).then(data =>{
    this.agentEarningService.getCommission(data).then((data: any) => {
      this.agentEarningData = data;
      for (var i = 0; i < this.agentEarningData.result.length; i++) {
        if (this.agentEarningData.result[i].transactionType == "NON_RAPDRP") { this.agentEarningData.result[i].transactionType = "NON-RAPDRP (RURAL)"; }
        if (this.agentEarningData.result[i].transactionType == "RAPDRP") { this.agentEarningData.result[i].transactionType = "RAPDRP (URBAN)"; }
          this.totalCommission = this.totalCommission + this.agentEarningData.result[i].commission;
          arr.push(this.agentEarningData.result[i]);
          this.filterDataForReset = arr;
          this.agentEarningFilterData = arr;
        }
      });
    });
  }

  exportAsXLSX(): void {
    let arr1 = [];
    for (var i = 0; i < this.agentEarningFilterData.length; i++) {
      var a = this.agentEarningFilterData[i].timestamp
      var date = new Date(a);
      arr1.push({
        TransactionId : this.agentEarningFilterData[i].externalTransactionId,
        AgencyVan : localStorage.getItem('van'),
        AgencyName : localStorage.getItem("AgencyName"),
        WalletId : this.agentEarningFilterData[i].externalId,
        Type: this.agentEarningFilterData[i].activity,
        Amount: this.agentEarningFilterData[i].amount,
        Discom: this.agentEarningFilterData[i].discom,
        Division: this.agentEarningFilterData[i].division,
        Source: this.agentEarningFilterData[i].transactionType,
        Status: "SUCCESS",
        Commission: this.agentEarningFilterData[i].commission,
        Date: this.datepipe.transform(this.agentEarningFilterData[i].transactionTime,'dd-MM-yyyy hh:mm:ss a'),
      });
    }
    this.excelService.exportAsExcelFile(arr1, 'Earning');
  }

}
