import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import { AgencyCommissionRoutingModule } from './agency-commission-routing.module';
import { AgencyCommissionComponent } from './agency-commission.component';
import {NgxPaginationModule} from 'ngx-pagination'; 

@NgModule({
  declarations: [AgencyCommissionComponent],
  imports: [
    CommonModule,
    AgencyCommissionRoutingModule, 
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxPaginationModule
  ],  providers: [ExcelServiceService,DatePipe]

})
export class AgencyCommissionModule { }
