import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyCommissionComponent } from './agency-commission.component';

describe('AgencyCommissionComponent', () => {
  let component: AgencyCommissionComponent;
  let fixture: ComponentFixture<AgencyCommissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyCommissionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyCommissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
