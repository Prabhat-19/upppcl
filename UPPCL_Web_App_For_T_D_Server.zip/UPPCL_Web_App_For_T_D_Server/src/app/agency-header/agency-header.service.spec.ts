import { TestBed } from '@angular/core/testing';

import { AgencyHeaderService } from './agency-header.service';

describe('AgencyHeaderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgencyHeaderService = TestBed.get(AgencyHeaderService);
    expect(service).toBeTruthy();
  });
});
