import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { AgencyHeaderService } from './agency-header.service';

@Component({
  selector: 'app-agency-header',
  templateUrl: './agency-header.component.html',
  styleUrls: ['./agency-header.component.scss']
})
export class AgencyHeaderComponent implements OnInit {

  constructor(private agencyHeaderService:AgencyHeaderService,private router:Router) { }

  ngOnInit() {
  }
  logout(){
    //alert("logout");
      this.agencyHeaderService.deleteToken().then(data=> {
        localStorage.clear();
        this.router.navigate(['/login']);
      });

     
  }
}
