import { Component, OnInit, HostListener, ɵConsole } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { AdminApprovalService } from '../admin-approval/admin-approval.service';
import { findIndex } from 'rxjs/operators';
import { NgxSpinnerService } from "ngx-spinner";
declare var $: any;
import {GenerateTokenService} from '../generate-token/generate-token.service'
import {TokenGenerateService} from '../token-generate.service';
import { environment } from 'src/environments/environment';
import { ManageAgentService } from '../manage-agent/manage-agent.service';
import { AdminSubAgentListingService } from './admin-sub-agent-listing.service';

@Component({
  selector: 'app-admin-sub-agent-listing',
  templateUrl: './admin-sub-agent-listing.component.html',
  styleUrls: ['./admin-sub-agent-listing.component.scss']
})
export class AdminSubAgentListingComponent implements OnInit {

  manageAgentData: any;
  walletBalance: string;
  datas: any;
  deleteId: string;
  userName: string;
  authToken: any;
  allagentData: string;
  walletResult: string;
  dataRefresher: any;
  token:any;
  filterData: any;
  filterVAN: any;
  filterFirstName: any;
  filterAgentId: any;
  typeSelectedValue = "Type"; 
  manageDataForFilter:any;
  filterLastName: any;
  filterDiscom: any;
  filterWalletAmount: any;
  statusSelectedValue = "Status";  
  filterToDate: any;
  filterFromDate: any;
  manageAgentFilterData: any;
  result: any;
  totalData:any;
  walletBalancetoken:any;
  subAgentToken:any;	
  agencyName :any;
  constructor(private adminSubAgent:AdminSubAgentListingService,private spinner:NgxSpinnerService,private tokenGenerate : TokenGenerateService,private excelService: ExcelServiceService,public datepipe: DatePipe,private generateTokenService:GenerateTokenService,private adminApproval: AdminApprovalService, private agentDashboardService: AgentDashboardService, private manageAgent: ManageAgentService, private router: Router) { }

  ngOnInit() {
    $('#adminAgencyHeader').css('color', 'white');
    this.agentAuth();
    this.spinner.show();
    this.manageSubAgent();
    this.checkUserTyper();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  clear() {
    this.filterData = [];
    this.filterVAN = null;
    this.filterFirstName = null;
    this.filterLastName = null;
    this.filterDiscom = null;
    this.filterWalletAmount = null;
    this.statusSelectedValue = 'Status';
    this.filterToDate = null;
    this.filterFromDate = null;
    this.manageAgentData = this.manageDataForFilter;
  }


  exportAsXLSX(): void {
    let arr1 = []
    for (var i = 0; i < this.manageDataForFilter.length; i++) {
      var date = this.manageDataForFilter[i].modifiedAt.split("T")[0]
      arr1.push({
        Van: this.manageDataForFilter[i].van,
        FirstName : this.manageDataForFilter[i].user.firstName,
        LastName : this.manageDataForFilter[i].user.lastName,
        Discom: this.manageDataForFilter[i].discoms[0],
        WalletAmount: this.manageDataForFilter[i].balance,
        Status: this.manageDataForFilter[i].status,
        Date: date,
      });
    }
    this.excelService.exportAsExcelFile(arr1, 'Ledger');
  }



  onSubmit() {
    var self = this;
    this.filterData = [];
    for (var agentTranscationLoop = 0; agentTranscationLoop < self.manageDataForFilter.length; agentTranscationLoop++) {
        if (this.filterVAN == null) {
          this.filterVAN = "";
        }
        if(this.filterToDate != null){
        let newDate = new Date(this.filterToDate);  
        var nextDate = new Date(newDate.getTime()+1000*60*60*24);
        }
        console.log(this.filterWalletAmount);
        console.log(self.manageDataForFilter[agentTranscationLoop].balance.toString());
        // if (self.manageDataForFilter[agentTranscationLoop].status.include("ACTIVE")) { 
        if (this.filterVAN == null || (this.filterVAN != null && self.manageDataForFilter[agentTranscationLoop].van.toUpperCase().includes(this.filterVAN.toUpperCase()))
          && (this.filterFirstName == null || (this.filterFirstName != null && self.manageDataForFilter[agentTranscationLoop].user.firstName.toUpperCase().includes(this.filterFirstName.toUpperCase())))
          // && (this.filterAgentId == null || (this.filterAgentId != null && self.manageDataForFilter[agentTranscationLoop].payload.walletId.toUpperCase().includes(this.filterAgentId.toUpperCase())))
          // && (this.typeSelectedValue == 'Type' || (this.typeSelectedValue != 'Type' && self.manageDataForFilter[agentTranscationLoop].response[0].activity.includes(this.typeSelectedValue.toUpperCase())))
          && (this.filterLastName == null || (this.filterLastName != null && self.manageDataForFilter[agentTranscationLoop].user.lastName.toUpperCase().includes(this.filterLastName.toUpperCase())))
          && (this.filterDiscom == null || (this.filterDiscom != null && self.manageDataForFilter[agentTranscationLoop].discoms[0].toUpperCase().includes(this.filterDiscom.toUpperCase())))
          && (this.filterWalletAmount == null || (this.filterWalletAmount != null && self.manageDataForFilter[agentTranscationLoop].balance.toString() == (this.filterWalletAmount)))
          //&& (this.statusSelectedValue == 'Status' || (this.statusSelectedValue != 'Status' && this.agencyTransactionData.content[agentTranscationLoop].payload.status.toUpperCase().includes(this.statusSelectedValue.toUpperCase())))
          && (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd') != null && this.manageDataForFilter[agentTranscationLoop].modifiedAt >= (this.datepipe.transform(this.filterFromDate, 'yyyy-MM-dd'))))
          && (this.datepipe.transform(nextDate, 'yyyy-MM-dd') == null || (this.datepipe.transform(nextDate, 'yyyy-MM-dd') != null && this.manageDataForFilter[agentTranscationLoop].modifiedAt  <= (this.datepipe.transform(nextDate, 'yyyy-MM-dd'))))
        ) {
          this.filterData.push(self.manageDataForFilter[agentTranscationLoop])
        }
       }
    //}
    this.manageAgentData = this.filterData;
  }

  manageSubAgent() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data=>{
      this.token=data;
    this.adminSubAgent.manageSubAgent(this.token).then((data: any) => {
      this.manageAgentData = data;
      this.manageAgentData.sort((a,b) => b.modifiedAt.localeCompare(a.modifiedAt));
      this.manageDataForFilter = this.manageAgentData;
      if (JSON.stringify(this.manageAgentData) == "[]") {
          document.getElementById("ledgerHistory").style.display = "";
      }
      this.agencyName = localStorage.getItem('agencyName');
      var self = this;
      for (var i = 0; i < self.manageAgentData.length; i++) {
        (function (j) {
          self.walletBalance1(self.manageAgentData[j].van).then((walletBalanceResult: any) => {
            self.walletResult = walletBalanceResult.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            self.manageAgentData[j]['balance'] = self.walletResult;
            self.allagentData = walletBalanceResult;
           
          });
        })(i);
      }
    })
  })
    this.spinner.hide();
  }

  
  walletBalance1(id) {
     return new Promise(resolve => {
      this.tokenGenerate.getToken(environment.tokenForBalanceUsingVan).then(data=>{
      this.walletBalancetoken=data;
      this.manageAgent.walletSubAgent(id,this.walletBalancetoken).then((data: any) => {
        this.walletBalance = data.balance;
        resolve(this.walletBalance);
      })
    })
  })
  }

  confirmationModal(event) {
    $(document).ready(function () {
      event.preventDefault();
    jQuery.noConflict();
      $("#exampleModalCenter").modal();
    });
  }
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "AGENCY")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  

  subAgentDetailsEdit(subAgentId) {
    localStorage.setItem("subAgentId", subAgentId);
    this.router.navigate(['/sub-agent-edit']);
  }

  subAgentDetailsEdit1(subAgentVan, Id) {
    localStorage.setItem("subAgentVan", subAgentVan);
    localStorage.setItem("subAgentId", Id);
    this.router.navigate(['/ledger-analysis']);
  }
}

