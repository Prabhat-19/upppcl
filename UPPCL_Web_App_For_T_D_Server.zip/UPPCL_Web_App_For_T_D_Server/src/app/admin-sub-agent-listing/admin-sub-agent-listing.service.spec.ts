import { TestBed } from '@angular/core/testing';

import { AdminSubAgentListingService } from './admin-sub-agent-listing.service';

describe('AdminSubAgentListingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminSubAgentListingService = TestBed.get(AdminSubAgentListingService);
    expect(service).toBeTruthy();
  });
});
