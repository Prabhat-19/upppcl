import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminSubAgentListingComponent } from './admin-sub-agent-listing.component';

const routes: Routes = [
  {path:'sub-agent',component:AdminSubAgentListingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminSubAgentListingRoutingModule { }
