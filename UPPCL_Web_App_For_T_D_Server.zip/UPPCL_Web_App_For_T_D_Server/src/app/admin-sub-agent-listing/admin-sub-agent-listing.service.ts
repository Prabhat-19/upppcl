import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';
import { Observable } from 'rxjs';
import { constant } from 'src/environments/constant';
@Injectable({
  providedIn: 'root'
})
export class AdminSubAgentListingService {
  header:any;

  constructor(private http: HttpClient) { }

  manageSubAgent(token:any){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization':'Bearer '+ token.access_token
      })};
    return new Promise(resolve => {
      this.http.get(environment.allAgentOnBasisOfAgencyId+localStorage.getItem('AgencyID'), httpOptions).subscribe((data: any) => {
        console.log(data);
        resolve(data);
       });
   });
  }
}
