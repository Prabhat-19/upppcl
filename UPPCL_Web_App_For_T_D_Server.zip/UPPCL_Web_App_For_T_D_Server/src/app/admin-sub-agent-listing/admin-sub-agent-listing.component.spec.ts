import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSubAgentListingComponent } from './admin-sub-agent-listing.component';

describe('AdminSubAgentListingComponent', () => {
  let component: AdminSubAgentListingComponent;
  let fixture: ComponentFixture<AdminSubAgentListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminSubAgentListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSubAgentListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
