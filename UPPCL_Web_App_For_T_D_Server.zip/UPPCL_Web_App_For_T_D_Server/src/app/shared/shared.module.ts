import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FooterComponent } from '../footer/footer.component';
import { HeaderComponent } from '../header/header.component';
import { RouterModule } from '@angular/router'
import { AdminHeaderComponent } from '../admin-header/admin-header.component';
import { AgencyHeaderComponent } from '../agency-header/agency-header.component';
import {ChatbotComponent} from '../chatbot/chatbot.component';

@NgModule({
  declarations: [FooterComponent,HeaderComponent,AdminHeaderComponent,AgencyHeaderComponent,ChatbotComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[FooterComponent,HeaderComponent,AdminHeaderComponent,AgencyHeaderComponent,ChatbotComponent]
})
export class SharedModule { }
