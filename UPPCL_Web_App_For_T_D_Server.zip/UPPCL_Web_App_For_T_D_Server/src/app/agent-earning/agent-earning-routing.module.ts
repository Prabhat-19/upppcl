import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgentEarningComponent } from './agent-earning.component';

const route:Routes=[
  {path:'agent-earning',component:AgentEarningComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AgentEarningRoutingModule { }
