import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'; 
import { environment  } from '../../environments/environment';
import { TokenGenerateService } from '../token-generate.service'


@Injectable({
  providedIn: 'root'
})
export class AgentEarningService {


  header:any;

  constructor(private tokenGenerate:TokenGenerateService,private http:HttpClient) { }
  
  getCommission(token){
    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token.access_token
      })
    }

    return new Promise(resolve => {
      this.http.get(environment.getCommission+localStorage.getItem("van") +'?commission=true',this.header).subscribe(data => {
        resolve(data);
      });
    });

  }
  
}
