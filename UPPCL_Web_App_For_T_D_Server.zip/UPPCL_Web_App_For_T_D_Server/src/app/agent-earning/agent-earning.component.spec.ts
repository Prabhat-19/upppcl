import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentEarningComponent } from './agent-earning.component';

describe('AgentEarningComponent', () => {
  let component: AgentEarningComponent;
  let fixture: ComponentFixture<AgentEarningComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentEarningComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentEarningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
