import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgentEarningComponent } from './agent-earning.component';
import { AgentEarningRoutingModule } from './agent-earning-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import {NgxPaginationModule} from 'ngx-pagination'; 

@NgModule({
  declarations: [AgentEarningComponent],
  imports: [
    CommonModule,
    AgentEarningRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxPaginationModule
  ],
  providers: [ExcelServiceService,DatePipe]
})
export class AgentEarningModule { }
