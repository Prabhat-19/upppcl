import { TestBed } from '@angular/core/testing';

import { AgentEarningService } from './agent-earning.service';

describe('AgentEarningService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentEarningService = TestBed.get(AgentEarningService);
    expect(service).toBeTruthy();
  });
});
