import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmailVerificationService } from './email-verification.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { validation } from '../../environments/validationsMessage';
import { environment } from '../../environments/environment';
import { TokenGenerateService } from '../token-generate.service';
import { HttpClient,HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-email-verification',
  templateUrl: './email-verification.component.html',
  styleUrls: ['./email-verification.component.scss']
})
export class EmailVerificationComponent implements OnInit {

  successful: boolean = false;
  alreadyRegister: boolean = false;
  datas: any;
  errorMessage : any;
  //constructor(private tokenGenerate: TokenGenerateService, private agentDashboardService: AgentDashboardService, private emailVerificationService: EmailVerificationService, private router: Router, private _route: ActivatedRoute,private http:HttpClient) { }
  constructor(private tokenGenerate: TokenGenerateService, private agentDashboardService: AgentDashboardService, private router: Router, private _route: ActivatedRoute,private http:HttpClient) { }


  ngOnInit() {
    //this.agentAuth();
    this.verification();
  }

  /*
     This method is used to verify the email and remove the service layer from this component bcz there is only one 
     service will call in this component, 
  */
  verification() {
    var encodeUrl = atob(this._route.snapshot.paramMap.get('encodeUrl'));
    var id = encodeUrl.toString().split("/")[6];
    this.tokenGenerate.getToken(environment.fsmEvent).then(data => {
      this.datas = data;
      var token = this.datas.access_token;
      // above code succefully return token 
          //var url = environment.emailVerficationService  + id ;  
          //they have to provide url without ip and port,
      var url = environment.emailVerficationService + "/v1/fsm/event/" + id + "/REGISTER";
      let promise = new Promise((resolve,reject) => {
        this.http.get(url, {
                     headers: new HttpHeaders ({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                       })
                     }).toPromise().then((data : any)=>{
                          resolve(data);
                          this.successful = true;
                     },
                     msg => {
                         reject(msg);
                          this.errorMessage = msg.error.message;
                          this.alreadyRegister = true;
                       }
                )
      })
      
    })
  }


      /*
        This method is used to verify the email
        */
      //   verification() {
      // var encodeUrl = atob(this._route.snapshot.paramMap.get('encodeUrl'));
      //  console.log("encodeUrl : "+encodeUrl);
      //  var id  = encodeUrl.toString().split("/")[6];
      //  console.log("id : "+id);
      //     this.tokenGenerate.getToken(environment.fsmEvent).then(data => {
      //       this.datas = data;
      //       console.log("data : "+JSON.stringify(data));
      //      var output=  this.emailVerificationService.email1(id,this.datas.access_token).then((data: any) => {
      //         this.successful = true;
      //         this.pending = false;
      //         console.log("data "+data);
      //         console.log("data string  "+JSON.stringify(data));
      //       })
      //       console.log("outpu "+JSON.stringify(output));
      //     })

      //   }

     /*
        This method is used to authenticate the user
        */
      agentAuth() {
        this.agentDashboardService.agentTokenValidateIDAM().then((data: any) => {
          if (!data.valid) {
            this.router.navigate(["/login"]);
          }
        });
      }

      navigateToLogin() {
        this.router.navigate(['/login']);
      }

      /*
      This method is used to check user role
      */
      checkUserTyper() {
        if ((localStorage.getItem("userType") == validation.upplcRoles.UPPCL) || (localStorage.getItem("userType") == validation.upplcRoles.agency)) {
          localStorage.clear();
          this.router.navigate(['/login']);
        }
      }
    }