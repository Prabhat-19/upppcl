import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmailVerificationService {

  header:any;
 errorMessage: any;
  constructor(private http:HttpClient) { }
  
    email(id:any) {
      return new Promise(resolve => {
        var url = environment.emailVerficationService +"/"+id+"/REGISTER";
        console.log("url in service.ts "+url);
       this.http.get(url).subscribe(data => {
            resolve(data);
        })
        console.log("email verify service");
      })
    }
    
  email1(id: any,  token) {
    
   /* return new Promise(resolve => {
    var url = environment.emailVerficationService + "/v1/fsm/event/" + id + "/REGISTER";
    console.log("url in service.ts " + url);
      
    this.http.get(url,{
      headers: new HttpHeaders ({
         'Content-Type': 'application/json',
         'Authorization': 'Bearer ' + token
        })
      }).subscribe(data => {
         resolve(data);
         console.log("data in service "+data);
         console.log("data in service "+JSON.stringify(data));
     })
     console.log("email verify service");
    })
    */
   console.log("token  "+token);
   var url = environment.emailVerficationService + "/v1/fsm/event/" + id + "/REGISTER";
    let promise = new Promise((resolve,reject) => {
      this.http.get(url, {
                   headers: new HttpHeaders ({
                      'Content-Type': 'application/json',
                      'Authorization': 'Bearer ' + token
                     })
                   }).toPromise().then((data : any)=>{
                        resolve(data);
                        console.log("data in service "+data);
                        console.log("data in service "+JSON.stringify(data));
                   },
                   msg => {
                       reject(msg);
                       console.log("data in msg "+msg);
                        console.log("data in msg "+JSON.stringify(msg));
                        this.errorMessage = msg.error.message;
                        console.log("eroor message "+this.errorMessage);
                     }
              )
    })
   return promise;
  }
  
}
