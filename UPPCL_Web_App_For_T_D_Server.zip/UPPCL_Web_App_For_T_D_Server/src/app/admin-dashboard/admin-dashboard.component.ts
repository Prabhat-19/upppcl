import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { AdminApprovalService } from '../admin-approval/admin-approval.service';
import { AdminDashboardService } from '../admin-dashboard/admin-dashboard.service';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { TokenGenerateService } from '../token-generate.service';
import { combineAll } from 'rxjs/operators';
import { validation } from 'src/environments/validationsMessage';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})

export class AdminDashboardComponent implements OnInit {
  agentData = 0;
  agencyData = 0;
  approvedData = 0;
  ledgerTotalData = 0;
  results: any
  fullName: string;
  walletBalance: any;
  activities: any;
  ledgerAdminData:any;
  datas: any;
  uppclWalletData:any;
  addData = [];
  vanId:string;
  token:any;
  adminData:any;
  userName:any;
  nextPageToken = "";
  constructor(private tokenGenerate:TokenGenerateService,private adminDashboard: AdminDashboardService, private spinner: NgxSpinnerService, private AdminApproval: AdminApprovalService, private agentDashboardService: AgentDashboardService, private router: Router) { }

  ngOnInit() {
    this.checkUserTyper();
   
    this.spinner.hide();
    this.tokenGenerate.afterLogin();
    this.ledgerData();
    this.getAllRegisteredAgentsData();
    this.uppclActivity();
    this.adminLogin()
  }

  adminLogin(){
    this.tokenGenerate.getToken(environment.userToken).then(data => {
      this.token = data;
        this.adminDashboard.adminLogin(this.token).then(data => {
          this.adminData = data;
          this.userName = this.adminData[0].firstName+" "+this.adminData[0].lastName
        });
      });
  }

  /**
   * To display data according to role
   */
  agentDataDisplay() {
    // this.spinner.show();
    localStorage.setItem("role", "AGENT");
    this.router.navigateByUrl("/admin-analysis");
  }
  agencyDataDisplay() {
    // this.spinner.show();
    localStorage.setItem("role", "AGENCY");
    this.router.navigateByUrl("/admin-agency");
  }
  approvedDataDisplay() {
    // this.spinner.show();
    localStorage.setItem("role", "FULFILLED");
    // this.router.navigateByUrl("/admin-analysis");
  }
  ledgerAnalysis() {
    // this.spinner.show();
    localStorage.setItem("role", "ledger");
    // this.router.navigateByUrl("/admin-analysis");
  }

  /**
   * To get count of agent, agency and pending status data
   */
  getAllRegisteredAgentsData() {
    this.tokenGenerate.getToken(environment.agentRequestToken).then(data => {
      this.datas = data;
    this.AdminApproval.getAllData(this.datas.access_token).then(data => {
      this.results = data; 
      var filteredUsers = (this.results).filter((item) => item.agencyId == undefined);
      var fullfilledStatus = (filteredUsers).filter((item) => item.status == 'FULFILLED');
      this.agentData = (fullfilledStatus).filter((item) => item.agentType == validation.upplcRoles.Agent.toUpperCase());
      this.agencyData = (fullfilledStatus).filter((item) => item.agentType == validation.upplcRoles.agency.toUpperCase());
      
      if(this.adminData[0].role == validation.upplcRoles.Approval1){
        this.approvedData = (filteredUsers).filter((item) => item.status == 'PENDING_MAIL_VERIFICATION' || item.status == 'PENDING_LEVEL_1_APPROVAL' || item.status == 'PENDING_LEVEL_2_APPROVAL' );
      }
      else{
        this.approvedData = (filteredUsers).filter((item) => item.status == 'PENDING_LEVEL_2_APPROVAL');
      }
   })
  })
  }

  /**
   * To check Agent type
   */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  /**
   * UPPCL Wallet Balance
   */
  ledgerData() {
    this.tokenGenerate.getToken(environment.apiWalletOwnerToken).then(data => {
      this.datas = data;
    this.adminDashboard.ledgerData(this.datas.access_token).then(data => {
      this.uppclWalletData = data;
      this.walletBalance = this.uppclWalletData.balance;
      this.vanId = this.uppclWalletData.vanId;
    });
  });
  }

  /**
   * UPPCL Recent Activity
   */
  uppclActivity(){
    this.tokenGenerate.getToken(environment.uppclTransactionToken).then(data => {
      this.datas = data;
    this.adminDashboard.uppclTransactionData(this.datas.access_token,this.nextPageToken).then(data => {
      this.ledgerAdminData = data;
      for (var a = 0; a < this.ledgerAdminData.result.length; a++) {
              this.addData.push(this.ledgerAdminData.result[a]);
              this.ledgerTotalData++;
          }
      
    });
  });
  }
}
