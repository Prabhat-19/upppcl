import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
// import {AdminHeaderComponent} from '../admin-header/admin-header.component'
import { AdminDashboardComponent } from './admin-dashboard.component';
import { AdminDashboardRoutingModule } from './admin-dashboard-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { NgxSpinnerModule } from "ngx-spinner";
import { OrderModule } from 'ngx-order-pipe';

@NgModule({
  declarations: [AdminDashboardComponent],
  imports: [
    CommonModule,
    AdminDashboardRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxSpinnerModule,
    OrderModule
  ]
})
export class AdminDashboardModule { }
