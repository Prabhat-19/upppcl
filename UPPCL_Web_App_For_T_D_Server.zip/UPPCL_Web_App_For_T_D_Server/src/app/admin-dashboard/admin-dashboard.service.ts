import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http';
import { environment } from '../../environments/environment';
import { validation } from '../../environments/validationsMessage';

@Injectable({
  providedIn: 'root'
})
export class AdminDashboardService {
  URLNextpageToken:any;

  header:any;

  constructor(private http: HttpClient) { }

  ledgerData(token) {
    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
    return new Promise(resolve => {
      this.http.get(environment.ledgerData,this.header).subscribe(data => {
        resolve(data);
      });
    });
  }
  
  uppclTransactionData(token,nextPageToken) {
    this.URLNextpageToken = '?nextPageToken='+nextPageToken;
    if(nextPageToken == ""){
      this.URLNextpageToken = "";
    }
    else {
      this.URLNextpageToken = '?nextPageToken='+nextPageToken+'&pageSize=20';
    }
    const URL = environment.uppclTransactionData+this.URLNextpageToken;
        this.header = {
          headers: new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Bearer ' + token
          })
        }
        return new Promise(resolve => {
          this.http.get(URL,this.header).subscribe(data => {
            resolve(data);
          });
        });
      }

  userData(entityId,token) {
    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
      return new Promise(resolve => {
      this.http.get(environment.editAgentDetail + entityId,this.header).subscribe(data => {
        resolve(data);
      });
    });
  }

  adminLogin(token:any) {
    const httpOptions = {
    headers: new HttpHeaders({
      'Authorization':'Bearer '+ token.access_token
    })};
    let promise = new Promise((resolve, reject) => {
    this.http.get(environment.agentValidate + localStorage.getItem('userName'),httpOptions)
    .toPromise().then((data: any) => {
        resolve(data);
    },
      msg => {
      reject(msg);
      })
  })
  return promise;
}
callModal(message: string): void {
  $(document).ready(function () {
    $("#modelText").text(message);
    $('#btnhide').click();
  })
}
}
