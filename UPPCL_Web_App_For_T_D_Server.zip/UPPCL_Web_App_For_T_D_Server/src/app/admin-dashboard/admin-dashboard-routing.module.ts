import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard.component';

const route:Routes=[
  {path:'admin-dashboard',component:AdminDashboardComponent}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AdminDashboardRoutingModule { }
