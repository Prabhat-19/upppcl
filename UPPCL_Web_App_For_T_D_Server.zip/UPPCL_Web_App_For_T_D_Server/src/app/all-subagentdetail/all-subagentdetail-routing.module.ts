import { NgModule } from '@angular/core';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AllSubagentdetailComponent } from './all-subagentdetail.component';
import { SharedModule } from '../shared/shared.module';

const route:Routes=[
  {path:'all-subagentdetails', component:AllSubagentdetailComponent }
]

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(route)
  ],  exports: [RouterModule]

})
export class AllSubagentdetailRoutingModule { }
