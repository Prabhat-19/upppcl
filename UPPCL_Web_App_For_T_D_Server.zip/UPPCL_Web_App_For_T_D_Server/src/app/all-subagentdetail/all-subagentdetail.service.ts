import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AllSubagentdetailService {

  results: any[];
  
  constructor(public http: HttpClient) { }

  // manageSubAgent() {
  //   return new Promise(resolve => {
  //     this.http.get(environment.manageAgent + localStorage.getItem('agentId')).subscribe((data: any) => {
  //       resolve(data);
  //     });
  //   });
  // }

  walletSubAgent(result: any) {
    return new Promise(resolve => {
      this.http.get(environment.walletSubAgent + result).subscribe((data: any) => {
        resolve(data);
      });
    });
  }
  
}
