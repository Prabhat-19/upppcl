import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllSubagentdetailComponent } from './all-subagentdetail.component';

describe('AllSubagentdetailComponent', () => {
  let component: AllSubagentdetailComponent;
  let fixture: ComponentFixture<AllSubagentdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllSubagentdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllSubagentdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
