import { TestBed } from '@angular/core/testing';

import { AllSubagentdetailService } from './all-subagentdetail.service';

describe('AllSubagentdetailService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AllSubagentdetailService = TestBed.get(AllSubagentdetailService);
    expect(service).toBeTruthy();
  });
});
