import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.chatbot();
  }
chatbot(){
  $(".btn-minimize").click(function(){
    $(".widget-content").slideToggle();
  });
}
}
