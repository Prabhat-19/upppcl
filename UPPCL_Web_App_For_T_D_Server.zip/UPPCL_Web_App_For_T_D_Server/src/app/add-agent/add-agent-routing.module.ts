import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AddAgentComponent } from './add-agent.component';

const route:Routes=[
  {path:'add-agent',component:AddAgentComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AddAgentRoutingModule { }
