import { Component, OnInit,HostListener } from '@angular/core';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { AddAgentService } from './add-agent.service'
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
declare var $: any
import { RegistrationService } from '../registration/registration.service';

@Component({
  selector: 'app-add-agent',
  templateUrl: './add-agent.component.html',
  styleUrls: ['./add-agent.component.scss']
})

export class AddAgentComponent implements OnInit {
  
  Basic: any;
  discom = "Select one";
  division = "Select one";
  datas: any;
  token:any;
  emailAddress:any;
  fullName:any;
  userName:any;
  constructor(private registrationService :RegistrationService,private http: HttpClient, private tokenGenerate:TokenGenerateService,private agentDashboardService: AgentDashboardService, private data: AddAgentService, private router: Router) { }
  
  ngOnInit() {
    this.agentAuth();
    $('#manage-agent').css('color', 'white');
    this.checkUserTyper();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "UPPCL")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  ClearFields() {
    (document.getElementById("textfield1") as HTMLInputElement).value = "";
    (document.getElementById("textfield2") as HTMLInputElement).value = "";
    (document.getElementById("textfield3") as HTMLInputElement).value = "";
    (document.getElementById("textfield4") as HTMLInputElement).value = "";
    (document.getElementById("textfield5") as HTMLInputElement).value = "";
    (document.getElementById("textfield6") as HTMLInputElement).value = "";
    (document.getElementById("textfield7") as HTMLInputElement).value = "";
    (document.getElementById("textfield8") as HTMLInputElement).value = "";
    (document.getElementById("textfield11") as HTMLInputElement).value = "";
    (document.getElementById("textfield9") as HTMLInputElement).value = "Select one";
    (document.getElementById("textfield10") as HTMLInputElement).value = "";
  }

  onBasic(subAgentDetail: NgForm): void {
    this.Basic = subAgentDetail.value;
    this.userName = (document.getElementById("textfield11") as HTMLInputElement).value;
    var fields = ["firstName","lastName", "address", "state", "city", "postalCode", "contactNumber", "emailAddress", "discom", "district"]
    var i, l = fields.length;
    var fieldname;
    for (i = 0; i < l; i++) {
      fieldname = fields[i];
      if (document.forms["form"]["firstName"].value.length == 0 || document.forms["form"]["lastName"].value.length == 0 || document.forms["form"]["address"].value.length == 0 || document.forms["form"]["state"].value.length == 0 || 
      document.forms["form"]["city"].value.length == 0 || document.forms["form"]["postalCode"].value.length == 0 || document.forms["form"]["contactNumber"].value.length == 0 || document.forms["form"]["emailAddress"].value.length == 0
      || document.forms["form"]["district"].value.length == 0) {
        this.callModal("Please enter all required field(s).");
      }
      else if (document.forms["form"]["discom"].value == "Select one") {
        this.callModal("Please enter all required field(s).");
      }
      else {
        this.confirmationModal(event);
      }
    }
  }
  emailIdCheck() {
    var regExp = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    if (!(regExp.test(this.emailAddress))) {
      this.callModal("Please enter valid email address.");
    }
    this.tokenGenerate.getToken(environment.userToken).then(data => {
      this.token = data;

    this.data.emailCheck(this.emailAddress,this.token.access_token).then(data => {
    });
  })
  }
  onAddagents() {
    this.tokenGenerate.getToken(environment.addAgentsToken).then(data => {
    this.datas = data;
    this.data.addAgents(this.Basic,this.datas.access_token,this.userName).then(data => {
    //  this.callModal("Agent created sucessfully.");
     this.callModal("Request is submitted sucessfully. The agents will show on Agent Listing page after they will verify their email address.");

     });
  });
  this.ClearFields();
  }

  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  return() {
    this.router.navigate(['/manage-agent'])
  }

  confirmationModal(event) {
    $(document).ready(function () {
      event.preventDefault();
    jQuery.noConflict();
      $("#exampleModalCenter").modal();
    });
  }

  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) { return false; }
    return true;
  }

  contactNumberCheck() {
    var mobileNumber = (<HTMLInputElement>document.getElementById("textfield7")).value;
    var numberCheck = /^\d{10}$/;
    if (!(mobileNumber.match(numberCheck))) {
      (document.getElementById("textfield7") as HTMLInputElement).value = "";
      this.callModal("Please enter valid contact number.")
    }
  }

  postalNumberCheck() {
    var postalNumber = (<HTMLInputElement>document.getElementById("textfield6")).value;
    var numberCheck = /^\d{6}$/;
    if (!(postalNumber.match(numberCheck))) {
      (document.getElementById("textfield6") as HTMLInputElement).value = "";
      this.callModal("Please enter valid postal number.")
    }
  }

  focusOutUserFullNameFunction() {
    let lastDigit;
    var firstName = $('#textfield1').val();
    var lastName = $('#textfield2').val();
    firstName = firstName.replace(/\s/g, "").toLowerCase();
    lastName = lastName.replace(/\s/g, "").toLowerCase();

    if(firstName !="" || lastName!=""){
    this.fullName = firstName + '.' + lastName;
    this.tokenGenerate.getToken(environment.userToken).then(data => {
      this.token = data;
    
    const header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + this.token.access_token
      })
    }
    let promise = new Promise((resolve, reject) => {
      this.http.get(environment.getAllUserDetails,header).toPromise().then((data: any) => {
        for (let array of data) {
          if (array.userName == this.fullName) {
            lastDigit = JSON.stringify(this.fullName).charAt(this.fullName.length)

            if (isNaN(lastDigit)) {
              this.fullName = this.fullName + "01";
            }
            else {
              lastDigit = this.fullName.substr(this.fullName.length - 1);
              this.fullName = this.fullName + Number(lastDigit) + 1;
            }
            $('#textfield11').val(this.fullName);
            // $('#fullnn').val(this.fullName);
            $('#textfield11').attr('disabled', 'true');
            break;
          }
          else {
            $('#textfield11').val(this.fullName);
            // $('#fullnn').val(this.fullName);
            $('#textfield11').attr('disabled', 'true');
          }
        }
      
      },
        msg => {

        })
    })
  })
  }
  }
}
