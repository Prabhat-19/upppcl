import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
// import { AgencyHeaderComponent  } from '../agency-header/agency-header.component';
import { AddAgentComponent } from './add-agent.component';
import { AddAgentRoutingModule } from './add-agent-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
// import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';

@NgModule({
  declarations: [AddAgentComponent],
  imports: [
    CommonModule,
    AddAgentRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    // NgIdleKeepaliveModule.forRoot()
  ]
})
export class AddAgentModule { }
