import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AddAgentService {
  address:any;
  constructor(private http: HttpClient) { }
  addAgents(payload:any,token,userName){
  //   this.address= {city : payload.city,
  //     street : payload.street,
  //     state : payload.state,
  //     postalCode : payload.postalCode}
  //   var payload1={
  //   "discomSubscription":payload.discom,
  //   "division" : payload.division,
  //   "firstName" : payload.firstName,
  //   "lastName" : payload.lastName,
  //   "mobile" : payload.contactNumber,
  //   "address" : this.address,
  //   "userName" : payload.UserName,
  //   "email" : payload.emailAddress,
  // };
  this.address = {
    "address": payload.address,
    "city": payload.city,
    "district": payload.district,
    "postalCode": payload.postalCode,
    "state": payload.state
  }
  var payload1={
    "address": this.address,
    "discoms": [payload.discom],
   "email": payload.emailAddress,
    "firstName": payload.firstName,
    "lastName": payload.lastName,
    "mobile": payload.contactNumber,
    "userName": userName,
    "divisions": [""],
  };
  
  return new Promise((resolve, reject) => {
    this.http.post(environment.addAgent+localStorage.getItem('agentId')+'/register',payload1,
    {
        headers:new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization': 'Bearer ' + token
      })
    }).toPromise().then(data =>
      {
      resolve(data);
      },
      msg => {
        this.callModal("Due to some technical glitch request is not submitted successfully. Please try again later.")
        reject(msg);
    }
      );
     });
  }
  emailCheck(email,token:any){
    const header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }
    return new Promise(resolve => {
      this.http.get(environment.emailValidate+email,header).subscribe(data => {
        if(data == ""){
        }
        else{
       this.callModal("Duplicate email address.");
       $('#textfield8').focus();
        }
        resolve(data);
      });
    });
   }
  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
  }

