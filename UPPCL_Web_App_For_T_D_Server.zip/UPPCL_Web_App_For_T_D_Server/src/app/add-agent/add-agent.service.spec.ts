import { TestBed } from '@angular/core/testing';

import { AddAgentService } from './add-agent.service';

describe('AddAgentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddAgentService = TestBed.get(AddAgentService);
    expect(service).toBeTruthy();
  });
});
