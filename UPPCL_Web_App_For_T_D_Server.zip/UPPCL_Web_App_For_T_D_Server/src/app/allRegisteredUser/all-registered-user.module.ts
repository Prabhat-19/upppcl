import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllRegisteredUserComponent } from './all-registered-user.component';
import { AllRegisteredUserRoutingModule } from './all-registered-user-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [AllRegisteredUserComponent],
  imports: [
    CommonModule,
    AllRegisteredUserRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    OrderModule,
    NgxPaginationModule
  ],
  providers: [DatePipe]

})
export class AllRegisteredUserModule { }
