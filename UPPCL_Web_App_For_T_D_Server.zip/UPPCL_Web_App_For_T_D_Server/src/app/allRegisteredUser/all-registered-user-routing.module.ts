import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllRegisteredUserComponent } from './all-registered-user.component';

const routes: Routes = [
  {path:'all-registered-user',component:AllRegisteredUserComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AllRegisteredUserRoutingModule { }
