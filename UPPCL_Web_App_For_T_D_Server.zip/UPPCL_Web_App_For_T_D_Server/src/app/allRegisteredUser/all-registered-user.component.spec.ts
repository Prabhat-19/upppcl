import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllRegisteredUserComponent } from './all-registered-user.component';

describe('AllRegisteredUserComponent', () => {
  let component: AllRegisteredUserComponent;
  let fixture: ComponentFixture<AllRegisteredUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllRegisteredUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllRegisteredUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
