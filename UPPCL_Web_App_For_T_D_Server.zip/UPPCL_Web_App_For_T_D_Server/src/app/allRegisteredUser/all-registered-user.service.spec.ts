import { TestBed } from '@angular/core/testing';

import { AllRegisteredUserService } from './all-registered-user.service';

describe('AllRegisteredUserService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AllRegisteredUserService = TestBed.get(AllRegisteredUserService);
    expect(service).toBeTruthy();
  });
});
