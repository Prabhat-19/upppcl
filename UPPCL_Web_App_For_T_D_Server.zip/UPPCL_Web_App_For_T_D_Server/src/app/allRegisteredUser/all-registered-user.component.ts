import { Component, OnInit, HostListener} from '@angular/core';
import { AllRegisteredUserService } from './all-registered-user.service';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import { TokenGenerateService } from '../token-generate.service';
import { environment } from '../../environments/environment';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-all-registered-user',
  templateUrl: './all-registered-user.component.html',
  styleUrls: ['./all-registered-user.component.scss']
})
export class AllRegisteredUserComponent implements OnInit {
  
  typeSelectedValue = "Type"; //amit
  statusSelectedValue = "Status";  //amit
  getAllData: any;
  getAllLedgerData: any;
  Activities: any;
  getallRegisteredData = [];
  firstName: string;
  lastName: string;
  wallet: any;
  transactionRecord: boolean = false;
  datas: any;
  showhead: boolean = true;
  agentName: string;
  config: any;
  filterData = [];
  filterTransactionId: any;
  filterAgentId: any;
  filterType: any;
  filterConsumerId: any;
  filterBillNumber: any;
  filterAmount: any;
  filterSource = 'Source';
  filterStatus: any
  filterFromDate: any;
  filterToDate: any;
  activityArray:any;
  totalElements:any;
  constructor(public datepipe: DatePipe, private tokenGenerate: TokenGenerateService, private router: Router, private agentDashboardService: AgentDashboardService, private data: AllRegisteredUserService, private excelService: ExcelServiceService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      // totalItems: this.collection.count
    };
  }

  ngOnInit() {
    this.agentAuth();
    $('#adminAgentHeader').css('color', 'white');
    this.onTransaction(this.totalElements);
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
 
  onTransaction(totalElements) {
    this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data => {
      this.datas = data;
      this.data.getAllData(this.datas.access_token,totalElements).then(data => {
        this.getAllData = data;
        for (var a = 0; a < this.getAllData.content.length; a++) {
          this.getallRegisteredData = this.getAllData.content;
          this.getallRegisteredData.sort((a,b) => b.response[0].transactionTime.localeCompare(a.response[0].transactionTime));
        if(this.getallRegisteredData[a].type == "WalletTransaction"){
              this.activityArray = "CREDIT";
        }else{
          for(var activityData =0; activityData < this.getallRegisteredData[a].response.length;activityData++){
            if(this.getallRegisteredData[a].response[activityData].vanId != 'UPPCL'){
              this.activityArray = this.getallRegisteredData[a].response[activityData].activity;
            }
            }
          }
          this.getallRegisteredData[a]['sourceActivity'] = this.activityArray;
          if (this.getallRegisteredData[a].payload.billId == undefined) { this.getallRegisteredData[a].payload.billId = "-"; }
          if (this.getallRegisteredData[a].payload.consumerAccountId == undefined) { this.getallRegisteredData[a].payload.consumerAccountId = "-"; }
          if (this.getallRegisteredData[a].response.type == "CREDIT") { this.getallRegisteredData[a].payload.walletId = "-"; }
          if (this.getallRegisteredData[a].payload.sourceType == "BANK") { this.getallRegisteredData[a].payload.sourceType = "NET BANKING"; }
          if (this.getallRegisteredData[a].payload.sourceType == "NON_RAPDRP") { this.getallRegisteredData[a].payload.sourceType = "NON-RAPDRP (RURAL)"; }
          if (this.getallRegisteredData[a].payload.sourceType == "RAPDRP") { this.getallRegisteredData[a].payload.sourceType = "RAPDRP (URBAN)"; }
          if (this.getallRegisteredData[a].payload.consumerName == undefined) { this.getallRegisteredData[a].payload.consumerName = "-"; }
          if (this.getallRegisteredData[a].payload.discom == undefined) { this.getallRegisteredData[a].payload.discom = "-"; }
          if (this.getallRegisteredData[a].payload.division == undefined) { this.getallRegisteredData[a].payload.division = "-"; }
        }
        
        this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
          this.datas = data;
          this.data.getAllLedgerData(this.datas.access_token).then(data => {
            
            this.getAllLedgerData = data;
              this.firstName = this.getAllLedgerData.user.firstName;
              this.lastName = this.getAllLedgerData.user.lastName;
              this.agentName = this.firstName + " " + this.lastName;
            this.wallet = this.getAllLedgerData.balanceAmount;
            this.wallet = this.wallet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
          });
        })
        if (this.getAllData.content == "") {
          document.getElementById("ledgerHistory").style.display = "";
        }
      });
    })
  }
  pageChanged(event) {
    this.config.currentPage = event;
    this.onTransaction(this.getAllData.totalElements);
  }
  onSubmit() {
    this.filterData = [];
    for (var agentTranscationLoop = 0; agentTranscationLoop < this.getAllData.content.length; agentTranscationLoop++) {
      if (this.filterTransactionId == null) {
        this.filterTransactionId = "";
      }

      if ((this.filterFromDate > this.filterToDate)) {
        this.callModal("Invalid Date Range.");
        this.filterFromDate = "";
        this.filterToDate = "";
      }
      if (this.filterToDate != null) {
        let newDate = new Date(this.filterToDate);
        var nextDate = new Date(newDate.getTime() + 1000 * 60 * 60 * 24);
      }
      if (this.filterTransactionId == null || (this.filterTransactionId != null && this.getAllData.content[agentTranscationLoop].response[0].transactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
        //  && ( this.filterAgentId == null || (this.filterAgentId != null && this.getallRegisteredData[agentTranscationLoop].entityType.toUpperCase().includes(this.filterAgentId.toUpperCase())))
        && (this.typeSelectedValue == "Type" || (this.typeSelectedValue != "Type" && this.getAllData.content[agentTranscationLoop].sourceActivity == (this.typeSelectedValue)))
        && (this.filterConsumerId == null || (this.filterConsumerId != null && this.getAllData.content[agentTranscationLoop].payload.consumerAccountId == (Number(this.filterConsumerId))))
        && (this.filterBillNumber == null || (this.filterBillNumber != null && this.getAllData.content[agentTranscationLoop].payload.billId.includes(this.filterBillNumber)))
        && (this.filterAmount == null || (this.filterAmount != null && this.getAllData.content[agentTranscationLoop].payload.amount == (Number(this.filterAmount))))
        
        //  && (this.filterSource == null || (this.filterSource != null && this.getAllData.content[agentTranscationLoop].payload.sourceType.toUpperCase().includes(this.filterSource.toUpperCase())))
        && (this.filterSource == 'Source' || (this.filterSource != 'Source' && this.getAllData.content[agentTranscationLoop].payload.sourceType == (this.filterSource.toUpperCase())))
        && (this.statusSelectedValue == "Status" || (this.statusSelectedValue != "Status" && this.getAllData.content[agentTranscationLoop].status.toUpperCase() == (this.statusSelectedValue.toUpperCase())))
        && (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.getAllData.content[agentTranscationLoop].date >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy'))))
        && (this.datepipe.transform(nextDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(nextDate, 'dd-MM-yyyy') != null && this.getAllData.content[agentTranscationLoop].date <= (this.datepipe.transform(nextDate, 'dd-MM-yyyy'))))
      ) {
        this.filterData.push(this.getAllData.content[agentTranscationLoop])
      }
    }
    this.getallRegisteredData = this.filterData;
  }
  /**
     * Method to call Modal
     * @param message 
     */
  callModal(message: string) {
    $(document).ready(function () {
      $("#modalText").text(message);
      $('#btnhide').click();
    })
  }
  clear() {
    this.filterData = [];
    this.filterTransactionId = null;
    this.typeSelectedValue = "Type";
    this.statusSelectedValue = "Status";
    this.filterConsumerId = null;
    this.filterBillNumber = null;
    this.filterAmount = null;
    this.filterToDate = null;
    this.filterSource = "Source"
    this.filterFromDate = null;
    this.getallRegisteredData = this.getAllData.content;
  }
  exportAsXLSX(): void {
    let arr1 = [];
    for (var i = 0; i < this.getallRegisteredData.length; i++) {
      if(this.getallRegisteredData[i].type == 'WalletTransaction'){
        var agentId = this.getallRegisteredData[i].response[1].vanId;
       }
       else{
         var agentId = this.getallRegisteredData[i].payload.walletId;
       }
      arr1.push({
        TransactionId: this.getallRegisteredData[i].response[0].transactionId,
        AgentId : agentId,
        AgentVAN: this.getallRegisteredData[i].response[0].vanId,
        AgentName: this.agentName.toUpperCase(),
        Source: this.getallRegisteredData[i].payload.sourceType,
        ConsumerId: this.getallRegisteredData[i].payload.consumerAccountId,
        ConsumerName: this.getallRegisteredData[i].payload.consumerName,
        BillNumber: this.getallRegisteredData[i].payload.billId,
        Type : this.getallRegisteredData[i].response[0].activity,
        Amount: this.getallRegisteredData[i].response[0].amount,
        Discom: this.getallRegisteredData[i].payload.discom,
        Division: this.getallRegisteredData[i].payload.division,
        TransactionStatus: this.getallRegisteredData[i].status,
        Date: this.getallRegisteredData[i].date,

      });
    }
    this.excelService.exportAsExcelFile(arr1, 'Ledger');
  }
}
