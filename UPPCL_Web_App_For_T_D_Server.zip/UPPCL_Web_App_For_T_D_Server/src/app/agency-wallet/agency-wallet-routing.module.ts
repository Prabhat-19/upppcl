import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgencyWalletComponent } from './agency-wallet.component';

const routes: Routes = [
  {path:'agency-wallet',component:AgencyWalletComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgencyWalletRoutingModule { }
