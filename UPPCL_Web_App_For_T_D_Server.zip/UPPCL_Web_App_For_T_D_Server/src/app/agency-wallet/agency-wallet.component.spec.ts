import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyWalletComponent } from './agency-wallet.component';

describe('AgencyWalletComponent', () => {
  let component: AgencyWalletComponent;
  let fixture: ComponentFixture<AgencyWalletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyWalletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
