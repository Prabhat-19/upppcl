import { Component, OnInit,HostListener } from '@angular/core';
import * as $ from 'jquery';
import { AgencyWalletService } from './agency-wallet.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { RechargeWalletService } from '../recharge-wallet/recharge-wallet.service';
import { validation  } from '../../environments/validationsMessage';
import {GenerateTokenService} from '../generate-token/generate-token.service'
import { TokenGenerateService} from '../token-generate.service'
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-agency-wallet',
  templateUrl: './agency-wallet.component.html',
  styleUrls: ['./agency-wallet.component.scss']
})
export class AgencyWalletComponent implements OnInit {
 
  selectedValue = "Select one";
  wallet: any;
  token:any;
  constructor(private tokenGenerate:TokenGenerateService,private generateTokenService:GenerateTokenService,private walletRechargee: RechargeWalletService, private spinner: NgxSpinnerService, private agentDashboardService: AgentDashboardService, private walletRecharge: AgencyWalletService, private router: Router) { }

  ngOnInit() {
    this.agentAuth();
    // this.paymentModeDropdown;
    this.walletBalance();
    
    this.checkUserTyper();

  }
  
   /*
  This method is used to check the user  role
  */
  checkUserTyper() {
    if ((localStorage.getItem("userType") == validation.upplcRoles.Agent) || (localStorage.getItem("userType") == validation.upplcRoles.UPPCL)) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }
  
   /*
  This method is used to authenticate the user  
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }


  /*
  This method is used to fill the values for recharge amount
  */
  paymentModeDropdown(element) {
    if (this.selectedValue == "Select one") {
      this.callModal(validation.PleaseSelectPaymentMode);
    }
    else if (element == "2000") {
      $('#displayamount').val('2000');
      $('#valuedisplay2000').css('background-color', '#a5dd4a');
      $('#valuedisplay5000').css('background-color', '');
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
    }
    else if (element == "5000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
      $('#displayamount').val('5000');
      $('#valuedisplay5000').css('background-color', '#a5dd4a');
    }
    else if (element == "10000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay5000').css('background-color', '');
      $('#valuedisplay15000').css('background-color', '');
      $('#displayamount').val('10000');
      $('#valuedisplay10000').css('background-color', '#a5dd4a');
    }
    else if (element == "15000") {
      $('#valuedisplay2000').css('background-color', '')
      $('#valuedisplay10000').css('background-color', '');
      $('#valuedisplay5000').css('background-color', '');
      $('#displayamount').val('15000');
      $('#valuedisplay15000').css('background-color', '#a5dd4a');
    }
  }


   /*
  This method is used to clear the fields
  */

  clear() {
    (document.getElementById("displayamount") as HTMLInputElement).value = "";
    (document.getElementById("mySelect") as HTMLInputElement).value = this.selectedValue;
  }

  
   /*
  This method is used to download the bank form
  */
  downloadBankForm() {
    if (($('#selectedBank').val()) == null || ($('#selectedTransferType').val()) == null) {
      this.callModal(validation.enterRequiredField);
    }
    else {
      const link = document.createElement('a');
      link.setAttribute('target', '_blank');
      link.setAttribute('href', validation.ICICIBankNEFTRTGS_FormPath);
      link.setAttribute('download', `ICICI_Bank_NEFT-RTGS_Form.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    }

  }

  /*
  This method is used to fetch the wallet details
  */
  walletBalance() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.agentDashboardService.getUserDetail(localStorage.getItem("agentId"),this.token).then((data: any) => {
      this.wallet = data.balanceAmount;
      this.wallet = this.wallet.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
    });
  }

  /*
  This method is used to recharge wallet
  */
  rechargeWallet() {
    
    localStorage.setItem("rechargeAmount", (document.getElementById("displayamount") as HTMLInputElement).value);
    if (($('#paymentgatewayDropDown').val()) == null || (document.getElementById("displayamount") as HTMLInputElement).value == "") {
      this.callModal(validation.enterRequiredField);
    }
    else {
      this.spinner.show();
       this.tokenGenerate.getToken(environment.agentRechargeWalletToken).then(data => {
         this.token = data;
      this.walletRechargee.icicIntegrationService((document.getElementById("displayamount") as HTMLInputElement).value,this.token).then((data: any) => {
        localStorage.setItem('encryptedUrl', data.url);
        if (data.url != "") {
          localStorage.setItem('encryptedUrl', data.url);
          this.router.navigate(['/paymentgateway-landingpage']);
        }
        else {
          this.callModal(validation.somethingWentWrongMessage);
        }
      }), () => this.spinner.hide();
    })
    }
  

  }

  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  /*
  This method is used to check press key
  */
  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

}