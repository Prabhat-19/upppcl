import { TestBed } from '@angular/core/testing';

import { AgencyWalletService } from './agency-wallet.service';

describe('AgencyWalletService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgencyWalletService = TestBed.get(AgencyWalletService);
    expect(service).toBeTruthy();
  });
});
