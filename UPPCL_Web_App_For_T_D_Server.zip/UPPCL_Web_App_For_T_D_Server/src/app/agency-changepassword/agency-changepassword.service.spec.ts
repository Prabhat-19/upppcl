import { TestBed } from '@angular/core/testing';

import { AgencyChangepasswordService } from './agency-changepassword.service';

describe('AgencyChangepasswordService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgencyChangepasswordService = TestBed.get(AgencyChangepasswordService);
    expect(service).toBeTruthy();
  });
});
