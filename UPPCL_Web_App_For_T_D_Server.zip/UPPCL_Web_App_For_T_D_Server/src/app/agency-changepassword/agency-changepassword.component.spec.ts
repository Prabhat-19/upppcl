import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyChangepasswordComponent } from './agency-changepassword.component';

describe('AgencyChangepasswordComponent', () => {
  let component: AgencyChangepasswordComponent;
  let fixture: ComponentFixture<AgencyChangepasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyChangepasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyChangepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
