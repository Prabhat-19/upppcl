import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { AgencyChangepasswordRoutingModule } from './agency-changepassword-routing.module';
import { AgencyChangepasswordComponent } from './agency-changepassword.component';

@NgModule({
  declarations: [AgencyChangepasswordComponent],
  imports: [
    CommonModule,
    AgencyChangepasswordRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule
  ]
})
export class AgencyChangepasswordModule { }
