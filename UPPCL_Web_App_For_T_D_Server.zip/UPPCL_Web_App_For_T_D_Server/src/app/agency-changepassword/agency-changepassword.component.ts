import { Component, OnInit,HostListener } from '@angular/core';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import { AgencyChangepasswordService } from './agency-changepassword.service';
import { validation } from '../../environments/validationsMessage';

@Component({
  selector: 'app-agency-changepassword',
  templateUrl: './agency-changepassword.component.html',
  styleUrls: ['./agency-changepassword.component.scss']
})
export class AgencyChangepasswordComponent implements OnInit {
 
  constructor(private agencyChangepasswordService: AgencyChangepasswordService, private agentDashboardService: AgentDashboardService, private router: Router) { }

  ngOnInit() {
    this.agentAuth();
  }


   /*
  This method is used to authenticate the user  
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  
   /*
  This method is used to change the user  password
  */
  submit() {
    if ((<HTMLInputElement>document.getElementById("confirmPassword")).value === (<HTMLInputElement>document.getElementById("newPassword")).value) {
      this.agencyChangepasswordService.passwordChange((<HTMLInputElement>document.getElementById("currentPassword")).value, (<HTMLInputElement>document.getElementById("newPassword")).value).then((data:any) => {
        if (JSON.stringify(data).includes("Old password is incorrect.")) {
          this.callModal(validation.oldPasswordWrong, "Alert");
        }
        else {
          this.callModal(validation.passwordChangedSuccessfully, "Alert");
        }
      })
    }
    else {
      this.callModal(validation.newPasswordAndOldPasswordNotMatched, "Alert");
    }
  }
}
