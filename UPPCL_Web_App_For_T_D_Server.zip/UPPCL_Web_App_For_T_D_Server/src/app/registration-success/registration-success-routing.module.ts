import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { RegistrationSuccessComponent } from './registration-success.component';

const route:Routes=[
  {path:'registration-success',component:RegistrationSuccessComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class RegistrationSuccessRoutingModule { }
