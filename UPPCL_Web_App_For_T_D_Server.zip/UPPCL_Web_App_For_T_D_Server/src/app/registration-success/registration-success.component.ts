import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-registration-success',
  templateUrl: './registration-success.component.html',
  styleUrls: ['./registration-success.component.scss']
})
export class RegistrationSuccessComponent implements OnInit {

  constructor(private spinnerService: Ng4LoadingSpinnerService,private router:Router) { }

  ngOnInit() {
    this.checkUserTyper();
    this.spinnerService.hide();
  }
  checkUserTyper(){
    if((localStorage.getItem("userType") == "UPPCL") || (localStorage.getItem("userType") == "Agency")) {
      localStorage.clear();
       this.router.navigate(['/login']);
    }
  }

}
