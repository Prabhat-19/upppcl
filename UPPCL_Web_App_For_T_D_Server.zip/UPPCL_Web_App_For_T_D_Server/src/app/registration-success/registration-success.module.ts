import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { FooterComponent  } from '../footer/footer.component';
import { RegistrationSuccessComponent } from './registration-success.component';
import { RegistrationSuccessRoutingModule } from './registration-success-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

@NgModule({
  declarations: [RegistrationSuccessComponent],
  imports: [
    CommonModule,
    RegistrationSuccessRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    Ng4LoadingSpinnerModule
  ]
})
export class RegistrationSuccessModule { }
