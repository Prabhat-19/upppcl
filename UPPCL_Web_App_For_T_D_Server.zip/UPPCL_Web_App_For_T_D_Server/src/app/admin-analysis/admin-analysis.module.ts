import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { AdminAnalysisRoutingModule } from './admin-analysis-routing.module';
import {AdminAnalysisComponent} from './admin-analysis.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import {NgxPaginationModule} from 'ngx-pagination'; 
import {NgxSpinnerModule} from 'ngx-spinner'
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [AdminAnalysisComponent],
  imports: [
    CommonModule,
    AdminAnalysisRoutingModule, 
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    OrderModule,
    NgxPaginationModule,
    NgxSpinnerModule
  ],
  providers: [DatePipe]

})
export class AdminAnalysisModule { }
