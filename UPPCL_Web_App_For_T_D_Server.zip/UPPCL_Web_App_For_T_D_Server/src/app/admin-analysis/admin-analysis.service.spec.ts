import { TestBed } from '@angular/core/testing';

import { AdminAnalysisService } from './admin-analysis.service';

describe('AdminAnalysisService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminAnalysisService = TestBed.get(AdminAnalysisService);
    expect(service).toBeTruthy();
  });
});
