import { Component, OnInit,HostListener } from '@angular/core';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pending-verification',
  templateUrl: './pending-verification.component.html',
  styleUrls: ['./pending-verification.component.scss']
})
export class PendingVerificationComponent implements OnInit {
  
  datas: any;

  constructor(private router: Router, private agentDashboardService: AgentDashboardService) { }

  ngOnInit() {
  }

  
}
