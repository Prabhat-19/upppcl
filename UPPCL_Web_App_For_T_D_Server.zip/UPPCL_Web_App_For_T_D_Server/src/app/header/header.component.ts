import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { HeaderService } from './header.service';
import {environment} from '../../environments/environment';
import {TokenGenerateService} from '../token-generate.service'
import {GenerateTokenService} from '../generate-token/generate-token.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  token:any;
  constructor(private generateTokenService:GenerateTokenService,private tokenGenerate:TokenGenerateService,private headerService: HeaderService, private router: Router, private agentDashboardService: AgentDashboardService) { }

  ngOnInit() {

    $(document).ready(function(){
      $(".walletnav").click(function(){
      $('#rechargeWallet').css('border-bottom', '2.4px solid #fbfbfb !important');
      });
    });
  

  }

  /**
   * logout method.
   * Navigate to login page.
   */
  logout() {
    this.headerService.deleteToken().then(data => {
      localStorage.clear();
      this.router.navigate(['/login']);
    });
  }

  /**
   * recharge wallet of agent from different page.
   */

  


  rechargeWalletAgent() {
    var userId = localStorage.getItem("userId");
      this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then( data=>{
      this.token=data;
    this.agentDashboardService.getUserDetail(localStorage.getItem("agentId"),this.token).then((data: any) => {
      if (data.agencyId !== undefined) {
        this.callModal("You are not authorized for this option.")
      }
      else {
        this.router.navigate(['/recharge-wallet'])
      }
    });
  })
  }

  /**
   * Method to call Modal
   * @param message string
   */
  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
}
