import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { RegistrationService } from './registration.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner'
import { constant } from '../../environments/constant'
declare var $: any;
import { TokenGenerateService } from '../token-generate.service'


class ImageSnippet {
  constructor(public src: string, public file: File) { }
}
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  registerAs = constant.dropDownValue;
  discom = constant.dropDownValue;
  area = constant.dropDownValue;
  division = constant.dropDownValue;
  basic: any;
  business: any;
  fullName: string;
  emailAddress: string;
  contactNumber: string;
  postalCode: string;
  gstinValue: string;
  summaryRegisterAs: string = null;
  authLetter: string;
  resProof: string;
  panNumberProof: string;
  token: any;
  gstinProof: any
  idProof: any;
  residencepostalCode: string;
  gstinDropDown: any;
  showImportantTags: boolean = true;
  showhead: false;
  registrationPayload: any;
  consumerAccount:any;

  constructor(private tokenGenerate: TokenGenerateService, private router: Router, private data: RegistrationService, private http: HttpClient, private spinner: NgxSpinnerService) { }
  ngOnInit() {   

$(document).ready(function () {
      var dropvalue;
      $("#ddlPassport").change(function () {
        dropvalue = ($('#ddlPassport').val());
        $(".select-field").val("");
        $("#ddlPassport").val(dropvalue)
        
        $("#mySelect3").val("Select one");
        $("#mySelect2").val("Select one");
        
        
      });

      $('input[type="radio"]').on('click', function () {
        if ($(this).val() == 'yes') {
          $('#gstinInputValue').show();
          $('#gstinYesCheckbox').attr('checked', 'true');
        }
        else {
          $('#gstinInputValue').hide();
          $('#gstinNoCheckbox').attr('checked', 'false');

        }
      });
      var controls = $('.back-btns')
      controls.click(function () {
        $('#gstinBussinessInput').removeAttr('disabled');
      if(dropvalue == 'CONSUMER')
      {
        backStepWizard = $('div.setup-panel div a[href="#step-2"]').parent().prev().children("a");
        backStepWizard.removeAttr('disabled').trigger('click');
      }
      else
      {
        var StepWizard = $(this).closest(".setup-content"),
          curStepBtn = StepWizard.attr("id"),
          backStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().prev().children("a");
        backStepWizard.removeAttr('disabled').trigger('click');
      }
      })
      var navListItems = $('div.setup-panel div a'),
        allWells = $('.setup-content'),
        allNextBtn = $('.nextBtn');
      allWells.hide();
      var idControls = $('.s');
      idControls.show();
      navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
          $item = $(this);
        if (!$item.hasClass('btn-circle')) {
          $item.addClass('btn-circle').removeClass('btn-default');
          allWells.hide();
          $target.show();
          $target.find('input:eq(0)').focus();
        }
        else {
          allWells.hide();
          $target.show();
          $target.find('input:eq(0)').focus();
        }
      });
      console.log(allNextBtn.val());
      allNextBtn.click(function (e) {
        console.log("inside all nextbutton");
        e.preventDefault();
        var form1data;
        var StepWizard = $(this).closest(".setup-content");
        var curStepBtn = StepWizard.attr("id");
        if (curStepBtn == 'step-1') {

          form1data = $('#myform1 :input');
        }
        if (curStepBtn == 'step-2') {
          form1data = $('#myform2 :input').not('#tanId');

          var gstin = $('#gstinBussinessInput').val();
          if (gstin.length != "") {
            this.showhead = true;
            this.show = false;
          }
          else {
            this.showhead = false;
            this.show = true;
          }
        }
        if (curStepBtn == 'step-3') {
          // form1data = $('#myform2 :input').not('#tanId');    //ISt change
          form1data = $('#myform2 :input').not('#tanId');    //ISt change
          var gstin = ($("input[name='gstin']:checked").val())
          var fileup = ($('#gstinID').val());

          if (gstin == 'yes' && (fileup == '' || fileup == null)) {
            $("#modalText").text("Please enter all required field(s)");
            $('#btnhide').click();
            return false;
          }
        }
        var count = 0;
        console.log(form1data);
        form1data.each(function (index, value) {
          var x = ($("input[name='gstin']:checked").val())
          if (x == 'no') {
            $('#gstinBussinessInput').prop('disabled', true);
          }
          if ((value.value.trim() == "" || value.value == constant.dropDownValue) && (!$(this).attr('disabled'))) {
  
            $("#modalText").text("Please enter all required field(s)");
            $('#btnhide').click();
            count = 1;
            return false;
          }
        })

        if (dropvalue == 'CONSUMER') //change
        {
          

          var StepWizard = $(this).closest(".setup-content"),
         
          nextStepWizard = $('div.setup-panel div a[href="#step-3"]').parent().next().children("a"),

          curInputs = StepWizard.find(":input,input[type='url']"),
          isValid = true;
          for (var i = 0; i < curInputs.length - 1; i++) {
            if (!((curInputs[i] as HTMLInputElement).validity.valid)) {
              isValid = false;
              $("#modalText").text("Please enter all required field(s)");
            }
          }
          if (isValid) {
            
          nextStepWizard.removeAttr('disabled').trigger('click');
            
          }
        }
          else

        
        {
          


          if (count == 0) {
            var StepWizard = $(this).closest(".setup-content"),
              curStepBtn = StepWizard.attr("id"),
              nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
              curInputs = StepWizard.find(":input,input[type='url']"),
              isValid = true;

            
            //$(".form-group").removeClass("has-error");
            for (var i = 0; i < curInputs.length - 1; i++) {
              if (!((curInputs[i] as HTMLInputElement).validity.valid)) {
                isValid = false;
              }
              // $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
            if (isValid) {

              nextStepWizard.removeAttr('disabled').trigger('click');
              $('div.setup-panel div a.btn-circle').trigger('click');
            }
          }
        }

        



      });
      $(document).ready(function () {
        $("input[type='radio']").change(function () {
          if ($(this).val() == "yes") {
            $("#gstinBussinessInput").show();
          }
          else {
            $("#gstinBussinessInput").hide();
            $('#gstinBussinessInput').val('');
          }
        });
      });

      // Chossen Consumer

    })


  }// onInit tag close

  
  validation(event) {
    switch (event) {
      case 'postalCheck': {
        let numberCheck = /^\d{6}$/;
        if (!((this.residencepostalCode).match(numberCheck)) || !((this.postalCode).match(numberCheck))) {
          $("#modalText").text("Please enter valid postal number");
          $('#btnhide').click();
          $('#postalNumber').focus();
        }
        break;
      }
      case 'mobileNumberCheck': {
        let numberCheck = /^\d{10}$/;
        if (!(this.contactNumber.match(numberCheck))) {
          this.contactNumber = "";
          $("#modalText").text("Please enter valid contact number");
          $('#btnhide').click();
        } else {
          localStorage.setItem("mobileNumber", this.contactNumber);
        }
        break;
      }
      case 'emailAddressCheck': {
        var regExp = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
        if (!(regExp.test(this.emailAddress))) {
          $("#modalText").text("Please enter valid email address");
          $('#btnhide').click();
        }
        this.tokenGenerate.getToken(environment.userToken).then(data => {
          this.token = data;
          this.data.emailCheck(this.emailAddress, this.token.access_token).then(data => {
          });
        });
        break;
      }
      case 'panNumberCheck': {
        var pan = $('#panId').val();
        if (pan.length > 0 && pan.length < 10) {
          $("#modalText").text("Please enter valid pan number");
          $('#btnhide').click();
          $('#panId').focus();
        }
        break;
      }
      case 'tanNumberCheck': {
        var tan = $('#tanId').val();
        if ((tan.length > 0 && tan.length < 10)) {
          $("#modalText").text("Please enter valid tan number");
          $('#btnhide').click();
          $('#tanId').focus();
        }
        break;
      }
      case 'area': {
        
        if ((this.area)=='NonRAPDRP') {
          let numberCheck = /^\d{12}$/;
          if (!(this.consumerAccount.match(numberCheck)))
          {
          $("#modalText").text("Please enter valid Account Number with 12 digit");
          $('#btnhide').click();
          }
        }
        else if
        ((this.area)=='RAPDRP')
        {
          let numberCheck = /^\d{10}$/;
          if (!(this.consumerAccount.match(numberCheck)))
          {
          $("#modalText").text("Please enter valid Account Number with 10 digit");
          $('#btnhide').click();
          }
        }
        
        break;
      }
    }
  }


  chkNo() {
    this.showImportantTags = false;
  }

  chkYes() {
    this.showImportantTags = true;
  }


  loginLinkRouting() {
    $('#email').off("focus");
    window.location.href = "/login";
    this.router.navigate(["/login"]);
  }

  registerAsSelection(basicForm: NgForm): void {

    
    if (this.registerAs == "AGENT") {

      $("#agencyNameInput").prop('disabled',true);
      $("#agencyNameInput").css({ 'background-color' : '#ebebe4'});

      [].forEach.call(document.getElementsByClassName("nodisplay"), function (el) {
        el.style.visibility = 'visible';
      });
      
      
      
      // (document.getElementById("agencyNameInput") as HTMLInputElement).value = "";
      // (document.getElementById("agencyNameInput") as HTMLInputElement).disabled = true;

      // $('#agencyNameInput').css('background-color', '#ebebe4');
      

    }
    else if (this.registerAs == "CONSUMER") {
      [].forEach.call(document.getElementsByClassName("nodisplay"), function (el) {
        el.style.visibility = 'hidden';
      });
      //(document.getElementById("consumerAccount") as HTMLInputElement).value = "";
      //(document.getElementById("consumerAccount") as HTMLInputElement).disabled = true;
      //(<HTMLInputElement>document.getElementById("consumerAccount")).disabled = true;
      
     

    }
    else if (this.registerAs == "AGENCY") {
      [].forEach.call(document.getElementsByClassName("nodisplay"), function (el) {
        el.style.visibility = 'visible';
      });
      $("#agencyNameInput").val("");
      $("#agencyNameInput").prop('disabled',false);
      $("#agencyNameInput").css({ 'background-color' : ''});
      
      // (document.getElementById("agencyNameInput") as HTMLInputElement).disabled = false;
      // (document.getElementById("agencyNameInput") as HTMLInputElement).value = "";
      // $('#agencyNameInput').css('background-color', '#ebebe4');

    }
  }

  enableField(){
    $("#consumerAccount").val("");
    $("#consumerAccount").prop('disabled',false);
    $("#consumerAccount").css({ 'background-color' : ''});
   // $('#consumerAccount').css('background-color', '#ebebe4');
  }
  // Basic Form
  basicFormButton(basicForm: NgForm): void {
    this.basic = basicForm.value;
    this.basic.userName = this.fullName;
    if (this.basic.registerAs == "AGENCY") {
      this.summaryRegisterAs = basicForm.value.agencyName;
    }
    else { this.summaryRegisterAs = ' '; }
    
  }

  // Consumer Registration 
  register() {
    $(document).ready(function () {
      $('#gstinInputValue').val($('#gstinBussinessInput').val());
      var controls = $('.summaryDetails :input').not('.back-btn');
      controls.each(function (index, value) {
        $(this).prop('disabled', false);
      })
      $('.back-btns ').removeAttr('disabled');
    })
  }

  bussinessFormButton(businessForm: NgForm): void {
    this.business = businessForm.value;
  }

  summaryFormButton(summaryForm) {
    if(this.registerAs == "CONSUMER")
    {
      let basicArray = [];
      basicArray.push(this.basic);
      this.spinner.show();
      this.data.getPost(this.basic).then(data => {
        this.registrationPayload = data;
        console.log("printing payload " +JSON.stringify(this.registrationPayload))
        localStorage.setItem("registerationConsumerData", JSON.stringify(this.registrationPayload));
        this.router.navigate(["/otp-verify"]);
      });

    }
    else
    {
    let basicArray = [];
    let bussinessArray = [];
    basicArray.push(this.basic);
    bussinessArray.push(this.business);
    this.spinner.show();
    this.data.getPosts(this.basic, this.business, this.gstinValue).then(data => {
      this.registrationPayload = data;
      localStorage.setItem("registerationUserData", JSON.stringify(this.registrationPayload));
      this.router.navigate(["/otp-verify"]);
    });
  }
  }

  // supporting documents
  documentsFormButton(authorizationLetterDocument, residenceProofDocument, panNumberDocument, gstinDocument, idProofDocument) {
    var authorizationLetter = $('#authorizationLetterID').val();
    var residenceProof = $('#residenceProofID').val();
    var panNumber = $('#panNumberID').val();
    var gstinNumber = $('#gstinID').val();
    var idProof = $('#proofID').val();

    if (authorizationLetter == "" || residenceProof == "" || panNumber == "" || idProof == "") {
      $("#modalText").text("Please enter all required field(s)");
      $('#btnhide').trigger('click');
    } else {
      let milliseconds;
      milliseconds = new Date().getTime();
      let residenceProofFeild = milliseconds + "_" + this.emailAddress + "_" + "RESIDENCE_ID";
      let authorizationLetterFeild = milliseconds + "_" + this.emailAddress + "_" + "AUTHORIZATION_LETTER";
      let panNumberFeild = milliseconds + "_" + this.emailAddress + "_" + "PAN_NUMBER";
      let gstinNumberFeild = milliseconds + "_" + this.emailAddress + "_" + "GSTIN_ID";
      let idProofFeild = milliseconds + "_" + this.emailAddress + "_" + "ID_DOCUMENT";
      var authorizationLetterUpload = authorizationLetterDocument.value.replace(/^.*[\\\/]/, '');
      var residenceProofUpload = residenceProofDocument.value.replace(/^.*[\\\/]/, '');
      var panNumberUpload = panNumberDocument.value.replace(/^.*[\\\/]/, '');
      var idProofUpload = idProofDocument.value.replace(/^.*[\\\/]/, '');

      (document.getElementById("authProof") as HTMLInputElement).innerHTML = authorizationLetterUpload;
      (document.getElementById("resProof") as HTMLInputElement).innerHTML = residenceProofUpload;
      (document.getElementById("panproof") as HTMLInputElement).innerHTML = panNumberUpload;
      (document.getElementById("idProof") as HTMLInputElement).innerHTML = idProofUpload;
      this.uploadDoucments(authorizationLetterDocument, authorizationLetterFeild).then(data => { });
      this.uploadDoucments(residenceProofDocument, residenceProofFeild).then(data => { });
      this.uploadDoucments(panNumberDocument, panNumberFeild).then(data => { });
      this.uploadDoucments(idProofDocument, idProofFeild).then(data => { });;
      if (($("input[name='gstin']:checked").val() != 'no')) {
        var gstinNumberUpload = gstinDocument.value.replace(/^.*[\\\/]/, '');
        (document.getElementById("gstinProof") as HTMLInputElement).innerHTML = gstinNumberUpload;
        this.uploadDoucments(gstinDocument, gstinNumberFeild).then(data => { });;
      }
      $(document).ready(function () {
        $('#gstinInputValue').val($('#gstinBussinessInput').val());
        var controls = $('.summaryDetails :input').not('.back-btn');
        controls.each(function (index, value) {
          $(this).prop('disabled', true);
        })
        $('.back-btns ').removeAttr('disabled');
      })
    }
  }
  // Documents Upload
  uploadDoucments(imageInputLetter: any, documentsUpload: any) {

    return new Promise(resolve => {
      const file: File = imageInputLetter.files[0];
      const reader = new FileReader();
      let selectedFile;
      reader.addEventListener('load', (event: any) => {
        selectedFile = new ImageSnippet(event.target.result, file);
        let formData = new FormData();
        formData.append('file', selectedFile.file);
        formData.append('extraField', documentsUpload);
        // this.tokenGenerate.getToken(environment.fileUploadToken).then(data => {
        // this.token = data;
        this.data.uploadDocumentsService(formData).then(data => {
          let response = data
          resolve(response);
          // });
        })
      });
      reader.readAsDataURL(file);
    });
  }
  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  //check existing users
  focusOutUserFullNameFunction() {
    let lastDigit;
    var firstName = $('#fn').val();
    var lastName = $('#ln').val();
    firstName = firstName.replace(/\s/g, "").toLowerCase();
    lastName = lastName.replace(/\s/g, "").toLowerCase();
    if (firstName != "" || lastName != "") {
      this.fullName = firstName + '.' + lastName;
      this.tokenGenerate.getToken(environment.userToken).then(data => {
        this.token = data;
        const header = {
          headers: new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': 'Bearer ' + this.token.access_token
          })
        }
        let promise = new Promise((resolve, reject) => {
          this.http.get(environment.getAllUserDetails, header).toPromise().then((data: any) => {
            for (let array of data) {
              if (array.status != "DELETED") {
                if (array.userName == this.fullName) {
                  lastDigit = JSON.stringify(this.fullName).charAt(this.fullName.length)
                  if (isNaN(lastDigit)) {
                    this.fullName = this.fullName + "01";
                  }
                  else {
                    lastDigit = this.fullName.substr(this.fullName.length - 1);
                    this.fullName = this.fullName + Number(lastDigit) + 1;
                  }
                  
                  $('#fulln').val(this.fullName);
                  $('#fullnn').val(this.fullName);
                  $('#fulln').attr('disabled', 'true');
                  break;
                }
                else {
                  $('#fulln').val(this.fullName);
                  $('#fullnn').val(this.fullName);
                  $('#fulln').attr('disabled', 'true');
                }
              }
            }

          },
            msg => {

            })
        })
      })
    }
  }
}


