import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, Router, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration.component';

const route: Routes = [
  { path: 'registration', component: RegistrationComponent }
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class RegistrationRoutingModule { }
