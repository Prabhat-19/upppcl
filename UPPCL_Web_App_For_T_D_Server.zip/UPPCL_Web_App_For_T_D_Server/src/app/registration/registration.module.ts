 import { NgModule } from '@angular/core';
 import { CommonModule } from '@angular/common';
import { RegistrationComponent } from './registration.component';
import { RegistrationRoutingModule } from './registration-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import {NgxSpinnerModule} from 'ngx-spinner'
import { environment  } from '../../environments/environment';

@NgModule({
  declarations: [RegistrationComponent],
  imports: [
    CommonModule,
    RegistrationRoutingModule,
    RouterModule,
    FormsModule,
    SharedModule,
    Ng4LoadingSpinnerModule,
    NgxSpinnerModule
  ]
})
export class RegistrationModule { }
