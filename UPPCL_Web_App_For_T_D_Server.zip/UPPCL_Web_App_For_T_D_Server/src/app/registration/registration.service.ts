import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {NgxSpinnerService} from 'ngx-spinner';

@Injectable({providedIn: 'root'})
export class RegistrationService {
    address : {
        address: any;
        city: any;
        district: any;
        state: any;
        postalCode: any;
    };
    document : {
        location: any;
        type: string;
    }[];
    dataArray = [];
    userType : string;
    residenceAddress : {
        address: any;
        city: any;
        district: any;
        state: any;
        postalCode: any;
    }
    Auth_type : any;
    RES_type : any;
    PAN_type : any;
    ID_type : any;
    GSTIN_type : any;
    registrationPayload : any;

    constructor(private http : HttpClient, private spinner : NgxSpinnerService) {}

    // Upload document service call
    uploadDocumentsService(payload : any) {
        return new Promise(resolve => {
            this.http.post(environment.uploadDocuments, payload, {
                // headers: new HttpHeaders({
                // 'Authorization': 'Bearer '+token,
                // })
            }).subscribe(data => {
                this.dataArray.push(data);
                for (var fileUpload = 0; fileUpload < this.dataArray.length; fileUpload++) {
                    if (this.dataArray[fileUpload].extraField.includes("AUTHORIZATION_LETTER")) {
                        this.Auth_type = this.dataArray[fileUpload].fileName;
                    } else if (this.dataArray[fileUpload].extraField.includes("RESIDENCE_ID")) {
                        this.RES_type = this.dataArray[fileUpload].fileName;
                    } else if (this.dataArray[fileUpload].extraField.includes("PAN_NUMBER")) {
                        this.PAN_type = this.dataArray[fileUpload].fileName;
                    } else if (this.dataArray[fileUpload].extraField.includes("GSTIN_ID")) {
                        this.GSTIN_type = this.dataArray[fileUpload].fileName;
                    } else if (this.dataArray[fileUpload].extraField.includes("ID_DOCUMENT")) {
                        this.ID_type = this.dataArray[fileUpload].fileName;
                    }
                }
                resolve(data);
            });
        });
    }
    // Preparing payload for consumer

    getPost(basicFormpayload : any) {
        return new Promise(resolve => {
            
            this.registrationPayload = {
                "agentType": basicFormpayload.registerAs,
                "area": [basicFormpayload.area],
                "firstName": basicFormpayload.fistName,
                "lastName": basicFormpayload.lastName,
                "email": basicFormpayload.emailAddress,
                "userName": basicFormpayload.userName,
                "discoms": [basicFormpayload.discom],
                "mobile": basicFormpayload.contactNumber,
                "ConsumerAccount":basicFormpayload.consumerAccount,
                "ServiceConnectionNo":basicFormpayload.serviceConNo
                
            };
            resolve(this.registrationPayload)
        });
    }

    // Registration API call
    getPosts(basicFormpayload : any, bussinessformpayload : any, gstinPayload : any) {
        return new Promise(resolve => {
            this.address = {
                address: bussinessformpayload.address,
                city: bussinessformpayload.city,
                district: bussinessformpayload.district,
                state: bussinessformpayload.state,
                postalCode: bussinessformpayload.postalCode
            };
            this.residenceAddress = {
                address: basicFormpayload.residenceAddress,
                city: basicFormpayload.residencecity,
                district: basicFormpayload.residenceDistrict,
                state: basicFormpayload.residencestate,
                postalCode: basicFormpayload.residencepostalCode
            };
            this.document = [
                {
                    location: environment.FileDownloadURL + this.Auth_type,
                    type: "AUTHORIZATION_LETTER"
                },
                {
                    location: environment.FileDownloadURL + this.RES_type,
                    type: "RESIDENCE_ID"
                },
                {
                    location: environment.FileDownloadURL + this.PAN_type,
                    type: "PAN_NUMBER"
                },
                {
                    location: environment.FileDownloadURL + this.GSTIN_type,
                    type: "GSTIN_ID"
                }, {
                    location: environment.FileDownloadURL + this.ID_type,
                    type: "ID_DOCUMENT"
                }
            ]
            this.registrationPayload = {
                "agentType": basicFormpayload.registerAs,
                "agencyName": basicFormpayload.agencyName,
                "userName": basicFormpayload.userName,
                "discoms": [basicFormpayload.discom],
                "divisions": [""],
                "residenceAddress": this.residenceAddress,
                "address": this.address,
                "documents": this.document,
                "email": basicFormpayload.emailAddress,
                "firstName": basicFormpayload.fistName,
                "gstin": gstinPayload,
                "lastName": basicFormpayload.lastName,
                "panNumber": bussinessformpayload.panNumber,
                "mobile": bussinessformpayload.contactNumber,
                "tinNumber": bussinessformpayload.tanNumber
            };
            resolve(this.registrationPayload)
        });
    }

    emailCheck(email, token : any) {
        const header = {
            headers: new HttpHeaders(
                {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Bearer ' + token
                }
            )
        }
        return new Promise(resolve => {
            this.http.get(environment.emailValidate + email, header).subscribe(data => {
                if (data == "") {} else if (data[0].status != 'DELETED') {
                    $("#modalText").text("Duplicate email address");
                    $('#btnhide').click();
                    $('#email').focus();
                }
                resolve(data);
            });
        });
    }
}

