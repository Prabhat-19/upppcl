import { TestBed } from '@angular/core/testing';

import { WalletDistributionService } from './wallet-distribution.service';

describe('WalletDistributionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WalletDistributionService = TestBed.get(WalletDistributionService);
    expect(service).toBeTruthy();
  });
});
