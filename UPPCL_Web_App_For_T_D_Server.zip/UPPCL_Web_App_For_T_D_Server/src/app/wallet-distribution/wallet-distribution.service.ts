import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class WalletDistributionService {

  header:any;
  inputData:any;

  constructor(private http: HttpClient) { }

  balance(van,token) {

    return new Promise(resolve => {

      this.header = {
        headers: new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Bearer ' + token
        })
      }

      const Url = environment.ApiToGetWalletBalance + van
      this.http.get(Url,this.header).subscribe(data => {
        resolve(data);
      })
    })
  }

  getAllAgent(token) {

    this.header = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer ' + token
      })
    }

    let promise = new Promise((resolve, reject) => {
      this.http.get(environment.allAgentOnBasisOfAgencyId + localStorage.getItem("agentId"),this.header).toPromise().then((data: any) => {
        resolve(data);
      },
        msg => {
          reject(msg);
        })
    })
    return promise;

  }

  // transferBalance(token,destinationID,transferAmount)
  //   {
      

  //   let promise = new Promise((resolve, reject) => {
    
  //   })
  //   return promise;
  //       }
}
