import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WalletDistributionComponent } from './wallet-distribution.component';

const routes: Routes = [
  { path: 'wallet-distribution', component: WalletDistributionComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WalletDistributionRoutingModule { }
