import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WalletDistributionRoutingModule } from './wallet-distribution-routing.module';
import { WalletDistributionComponent } from './wallet-distribution.component';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxSpinnerModule } from "ngx-spinner";
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [WalletDistributionComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    SharedModule,
    NgxSpinnerModule,
    WalletDistributionRoutingModule
  ]
})
export class WalletDistributionModule { }
