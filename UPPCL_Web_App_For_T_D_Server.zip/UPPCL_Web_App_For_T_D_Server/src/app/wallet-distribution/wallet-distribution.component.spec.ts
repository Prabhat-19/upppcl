import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WalletDistributionComponent } from './wallet-distribution.component';

describe('WalletDistributionComponent', () => {
  let component: WalletDistributionComponent;
  let fixture: ComponentFixture<WalletDistributionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WalletDistributionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WalletDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
