import { Component, OnInit, HostListener } from '@angular/core';
import { WalletDistributionService } from './wallet-distribution.service';
import { ManageAgentService } from '../manage-agent/manage-agent.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as $ from 'jquery';
import { environment } from 'src/environments/environment';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import { TokenGenerateService } from '../token-generate.service';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { validation } from 'src/environments/validationsMessage';
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-wallet-distribution',
  templateUrl: './wallet-distribution.component.html',
  styleUrls: ['./wallet-distribution.component.scss']
})
export class WalletDistributionComponent implements OnInit {

  balance: any;
  datas: any;
  payAs = validation.payAs;
  amountOfAgent: any;
  destinationID: any;
  walletResult: string;
  allagentData: string;
  transferAmount: any;
  walletBalancetoken: any;
  inputData: any;
  totalAgentBalance: number = 0;
  balanceLabel:boolean = false;
  balanceLabels:boolean = true;
  isReadOnly: boolean;
  balances: string;
  showItem: number = 0;
  header: any;
  index: number = 1;

  constructor(private spinner: NgxSpinnerService,private generateTokenService: GenerateTokenService, private manageAgent: ManageAgentService, private tokenGenerate: TokenGenerateService, private router: Router, private agentDashboardService: AgentDashboardService, private walletDistributionService: WalletDistributionService, private http: HttpClient) { }


  ngOnInit() {
    this.allAgentList();
    this.agentAuth();
    this.walletBalance();
    this.disableEnterAmountTextBox();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  /**
   * Method call on cancel button
   */
  clear() {
    (document.getElementById("amountId") as HTMLInputElement).value = " ";
    $('#tableId #myAmountId').val('');
    (document.getElementById("amountId") as HTMLInputElement).value = " ";
  }

  // To validate amount  
  mainService() {
    if(this.balance > 0) {
    if (this.payAs == validation.payAs) {
      this.callModal(validation.dropboxSelectionValue, validation.alertHeader)
    }
    else if (this.payAs == "Equal") {
      var inputValue = (document.getElementById("amountId") as HTMLInputElement).value;
      if (Number.isInteger(parseInt(inputValue))) {
        if (this.balance > (parseInt(inputValue) + parseInt(environment.minWalletBalanceForDistribution))) {
          this.serviceCall();
        }
      }
      else {
        this.callModal(validation.correctNonDecimalValue, validation.errorHeader);
      }
    }
    else {
      this.serviceCall();
    }
  }
  else {
    this.callModal(validation.walletBalanceLess, validation.alertHeader)
  }
  }


  // To validate input value is number.
  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  /**
   * Method is used for balance transfer
   */
  serviceCall() {
    return new Promise(resolve => {
      var arr = [];
    var mount = [];
    $("#tableId tr").each(function () {
      arr.push($(this).find("td:first").text()); //put elements into array
      mount.push(($(this).find('td').find('#myAmountId').val()));
    });

    for (let i = 2; i < mount.length; i++) {
      if (!isNaN(parseInt(mount[i]))) {
        this.totalAgentBalance = this.totalAgentBalance + parseInt(mount[i]);
      }
    }
    
    if (this.totalAgentBalance == 0) {
      this.callModal(validation.correctNonDecimalValue, validation.alertHeader);
    }
    else if ((this.totalAgentBalance + parseInt(environment.minWalletBalanceForDistribution)) > this.balance) {
      this.callModal(validation.walletBalanceLowAlert, validation.alertHeader);
      this.totalAgentBalance = 0;
    }
    else {
      if (this.showItem != 1) {
        for (let i = 2; i < arr.length; i++) {
          
          this.destinationID = arr[i];
          this.transferAmount = parseInt(mount[i]);
          if (isNaN(this.transferAmount)) {

          }
          else {
            if (this.transferAmount != "" || this.transferAmount != 0 || this.transferAmount.toString != "NaN") {
              this.tokenGenerate.getToken(environment.walletDistributionToken).then(data => {
                this.datas = data;
                
                this.header = {
                  headers: new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + this.datas.access_token
                  })
                }
          
                this.inputData = {
                  "amount": mount[i],
                  "destinationAgentId": arr[i],
                  "sourceAgentId": localStorage.getItem("agentId"),
                  "sourceType": "WALLET"
                }
                // let promise = new Promise((resolve, reject) => {
                this.http.put(environment.ApiForWalletDistribution, this.inputData,this.header).subscribe((data: any) => {
                })
              }) 
            }
            
            if (i == arr.length-1) {
              
              (document.getElementById("amountId") as HTMLInputElement).value = " ";   
              $('#tableId #myAmountId').val('');
              this.callModal(validation.transferCompleted, validation.alertHeader);
              
              
            }
          }
        }
      }
    }
  })
  }

  async delay(ms: number) {
    await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => { });
  }



  /*
@author manoj 
This method is used to open the pop up menu 
@param
  message 
*/
  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  payAsDistribution() {
    var balanceTransfer = (document.getElementById("amountId") as HTMLInputElement).value;
    if (this.payAs == "Equal") {
      $('#tableId #myAmountId').val('');
      (document.getElementById("amountId") as HTMLInputElement).value = " ";
      (<HTMLInputElement>document.getElementById("amountId")).disabled = false;
      this.isReadOnly = true;
    }
    else {
      (document.getElementById("amountId") as HTMLInputElement).value = " ";
      (<HTMLInputElement>document.getElementById("amountId")).disabled = true;
      $('#tableId #myAmountId').val('');
      this.callModal("You have to fill the amount for each agent manually.", validation.alertHeader);
    }
  }

  disableEnterAmountTextBox() {
    if (this.payAs == validation.payAs) {
      (<HTMLInputElement>document.getElementById("amountId")).disabled = true;
    }
  }

  /**
   * To check entered amount greater than current wallet balance or not
   */
  enteredAmount() {
    // var noOfSubAgent = (document.getElementById("tableId").getElementsByTagName("tr").length - 1);
    var balanceTransfer = (document.getElementById("amountId") as HTMLInputElement).value;
    if (this.payAs == validation.payAs) {
      (<HTMLInputElement>document.getElementById("amountId")).disabled = true;
    }
    else if (this.payAs == validation.equalValue) {
      (<HTMLInputElement>document.getElementById("amountId")).disabled = false;
      var equalAmount = balanceTransfer;
      $(".otherDevText").val(equalAmount);
      this.isReadOnly = true;
    }
    else {
      this.callModal("Please select radio button first then enter amount.", validation.alertHeader);
      (document.getElementById("amountId") as HTMLInputElement).value = "";
    }
  }

  //code for wallet to wallet transfer.

  //#region To get wallet balance
  walletBalance() {
   
    // var van = ;
    this.tokenGenerate.getToken(environment.tokenForBalanceUsingVan).then(data => {
      this.datas = data;
      this.walletDistributionService.balance(localStorage.getItem('van'), this.datas.access_token).then((data: any) => {
        this.balance = data.balance;
        this.balances = this.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      })
    })
  }
  //#region end

  walletBalance1(id) {
    return new Promise(resolve => {
      this.tokenGenerate.getToken(environment.tokenForBalanceUsingVan).then(data => {
        this.walletBalancetoken = data;
        this.manageAgent.walletSubAgent(id, this.walletBalancetoken).then((data: any) => {
          this.walletBalance = data.balance;
          resolve(this.walletBalance);
        })
      })
    })
  }

  /**
   * get all agent list
   */
  allAgentList() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.datas = data;
      this.walletDistributionService.getAllAgent(this.datas.access_token).then((data: any) => {
        if (JSON.stringify(data) == "[]") {
          document.getElementById("ledgerHistory").style.display = "";
          this.showItem = 1;
        }
        else {
          $('input:radio[name=r1][value=unequal]').click();
        }
        this.datas = data;
        var self = this;
        for (var i = 0; i < self.datas.length; i++) {
          (function (j) {
            self.walletBalance1(self.datas[j].van).then((walletBalanceResult: any) => {
              self.walletResult = walletBalanceResult.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
              self.datas[j]['balance'] = self.walletResult;
              self.allagentData = walletBalanceResult;
            });
          })(i);
        }
      })
    })
  }
}
