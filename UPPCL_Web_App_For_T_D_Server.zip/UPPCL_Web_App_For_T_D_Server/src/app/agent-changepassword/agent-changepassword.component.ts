import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { AgentChangepasswordService } from './agent-changepassword.service';
import { validation  } from '../../environments/validationsMessage';
import {environment} from '../../environments/environment';
import {TokenGenerateService} from '../token-generate.service';
import { HeaderService } from '../header/header.service';
// import * as $ from 'jquery';


@Component({
  selector: 'app-agent-changepassword',
  templateUrl: './agent-changepassword.component.html',
  styleUrls: ['./agent-changepassword.component.scss']
})
export class AgentChangepasswordComponent implements OnInit {
  
  agent: boolean = false;
  admin: boolean = false;
  agency: boolean = false;
  data: any;

  constructor(private headerService: HeaderService,private tokenGenerate:TokenGenerateService,private agentChangepasswordService: AgentChangepasswordService, private agentDashboardService: AgentDashboardService, private router: Router) { }

  ngOnInit() {
    this.agentAuth();
    this.showHeaderUsingRole();
  }

   /*
  This method is used to show header according to roles  
  */
  showHeaderUsingRole() {
    const userType = localStorage.getItem("userType");
    if (userType == validation.upplcRoles.Agent) {
      this.agent = true;
    }
    if (userType == validation.upplcRoles.agency) {
      this.agency = true;
    }
    if (userType == validation.upplcRoles.UPPCL) {
      this.admin = true;
    }
  }


   /*
  This method is used to authenticate the user  
  */

  agentAuth() {
    let tokenValidateData;
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      tokenValidateData = data;
      if (!tokenValidateData.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }


  
   /*
  This method is used to clear the fields
  */
  cancel() {
    (<HTMLInputElement>document.getElementById("currentPassword")).value = "";
    (<HTMLInputElement>document.getElementById("newPassword")).value = "";
    (<HTMLInputElement>document.getElementById("confirmPassword")).value = "";
  }


  callModal(message: string, title: string) {
    $(document).ready(function () {
      $("#h4").text(title);
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  
   /*
  This method is used to change the password the user  
  */

 submit() {
  if((<HTMLInputElement>document.getElementById("confirmPassword")).value == undefined || (<HTMLInputElement>document.getElementById("newPassword")).value == undefined || (<HTMLInputElement>document.getElementById("currentPassword")).value == undefined){
    this.callModal ("Please enter all required feild.","Alert");
  }
  if ((<HTMLInputElement>document.getElementById("confirmPassword")).value === (<HTMLInputElement>document.getElementById("newPassword")).value) {
    this.agentChangepasswordService.passwordChange((<HTMLInputElement>document.getElementById("currentPassword")).value, (<HTMLInputElement>document.getElementById("newPassword")).value).then((data:any) => {
      console.log(data);
      var password =(<HTMLInputElement>document.getElementById("newPassword")).value;
      if (JSON.stringify(data).includes(validation.oldPasswordWrong)) {
        this.callModal(validation.currentPasswordWrong, "Alert");
      }
      else if (JSON.stringify(data).includes(validation.minimumPasswordLength)) {
        this.callModal(validation.minimumPassordLengthRequired, "Alert");
      }
      else if (JSON.stringify(data).includes("attribute not set in JSON content.")) {
        this.callModal(validation.allFieldsAreRequired, "Alert");
      }
      else {

        this.tokenGenerate.getToken(environment.notifyUserToken).then(data => {
          this.data = data;
        this.agentChangepasswordService.sendPassword( password,this.data.access_token).then(data => {

        })
      })
        this.confirmationModal(event);
        // this.headerService.deleteToken();
        (<HTMLInputElement>document.getElementById("currentPassword")).value = "";
        (<HTMLInputElement>document.getElementById("newPassword")).value = "";
        (<HTMLInputElement>document.getElementById("confirmPassword")).value = "";
        // this.router.navigate(["/login"]);
      }
    })
  }
  else {
    this.callModal(validation.newPasswordAndOldPasswordNotMatched, "Alert");
  }
}
deleteOpenAMTokenApi(){
  this.headerService.deleteToken();
  this.router.navigate(["/login"]);
}

confirmationModal(event) {
  $(document).ready(function () {
    event.preventDefault();
    jQuery.noConflict();
    $('#exampleModalCenter').modal();
  });
}
}
