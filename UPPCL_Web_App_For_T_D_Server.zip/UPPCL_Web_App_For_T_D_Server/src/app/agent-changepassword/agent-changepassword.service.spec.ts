import { TestBed } from '@angular/core/testing';

import { AgentChangepasswordService } from './agent-changepassword.service';

describe('AgentChangepasswordService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentChangepasswordService = TestBed.get(AgentChangepasswordService);
    expect(service).toBeTruthy();
  });
});
