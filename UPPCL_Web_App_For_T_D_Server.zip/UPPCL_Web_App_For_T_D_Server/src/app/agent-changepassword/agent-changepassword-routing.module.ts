import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgentChangepasswordComponent } from './agent-changepassword.component';

const route:Routes=[
  {path:'changePassword',component:AgentChangepasswordComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class AgentChangepasswordRoutingModule { }
