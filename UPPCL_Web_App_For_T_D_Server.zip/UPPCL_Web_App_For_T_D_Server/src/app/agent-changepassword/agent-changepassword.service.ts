import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders,HttpResponse} from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgentChangepasswordService {

  url:any;
  constructor(private http: HttpClient) { }


  sendPassword(newPassword,token) {
    let promise = new Promise((resolve, reject) => {
      var payload = {
        "templateId": "CHANGE_PASSWORD",
        "fields": [
            {
                "key": "password",
                "value": newPassword
            },
            {
                "key": "firstName",
                "value": localStorage.getItem('firstName')
            },
            {
                "key": "phoneNo",
                "value": localStorage.getItem('mobile')
            }
        ]
    };
      this.http.post<HttpResponse<Object>>( environment.sendPassword , payload,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
            resolve(msg);
          }
        )
    })
    return promise;
  }

  passwordChange(currentPassword,newPassword) {
        this.url =  environment.changePassword + localStorage.getItem('userName') + "?_action=changePassword";
    var payload = {
      "currentpassword": currentPassword,
      "userpassword": newPassword
    };
    let promise = new Promise((resolve, reject) => {
      this.http.post<HttpResponse<Object>>( this.url , payload,
        {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept-API-Version': 'resource=3.0, protocol=1.0',
            'iplanetDirectoryPro': localStorage.getItem("authToken")
          })
        }).toPromise().then((data: any) => {
          resolve(data);
        },
          msg => {
     
            resolve(msg);
          }
        )
    })
    return promise;
  }
}
