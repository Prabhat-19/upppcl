import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { HeaderComponent  } from '../header/header.component';
// import { FooterComponent  } from '../footer/footer.component';
import { AgentChangepasswordComponent } from './agent-changepassword.component';
import { AgentChangepasswordRoutingModule } from './agent-changepassword-routing.module';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'

@NgModule({
  declarations: [AgentChangepasswordComponent],
  imports: [
    CommonModule,
    AgentChangepasswordRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule
  ]
})
export class AgentChangepasswordModule { }
