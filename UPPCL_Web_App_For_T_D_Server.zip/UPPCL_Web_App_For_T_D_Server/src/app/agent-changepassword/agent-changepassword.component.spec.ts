import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentChangepasswordComponent } from './agent-changepassword.component';

describe('AgentChangepasswordComponent', () => {
  let component: AgentChangepasswordComponent;
  let fixture: ComponentFixture<AgentChangepasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentChangepasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentChangepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
