import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyTransactionComponent } from './agency-transaction.component';

describe('AgencyTransactionComponent', () => {
  let component: AgencyTransactionComponent;
  let fixture: ComponentFixture<AgencyTransactionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyTransactionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
