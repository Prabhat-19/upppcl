import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http'; 
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AgencyTransactionService {
constructor(private http:HttpClient) { }
URL:any;
transactionDetail(totalPages,token:any) {
  const httpOptions = {
    headers: new HttpHeaders({
      'Authorization':'Bearer '+ token.access_token
    })
  };
  // var url = environment.agencyTransactionAgentIdBasis+'&size='+size+'&sort=date%2Cdesc&van='+localStorage.getItem("van");
  if(totalPages == ""){
    this.URL = environment.agentTransactionAgentIdBasis+'&sort=date%2Cdesc&status=SUCCESS&van=';}
    else{
    this.URL = environment.agentTransactionAgentIdBasis+'size='+ totalPages +'&sort=date%2Cdesc&status=SUCCESS&van=';}
  return new Promise(resolve => {
      this.http.get(this.URL+localStorage.getItem("van"),httpOptions).subscribe(data => {
        resolve(data);
      });
    });
  }
}
