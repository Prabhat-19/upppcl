import { TestBed } from '@angular/core/testing';

import { AgencyTransactionService } from './agency-transaction.service';

describe('AgencyTransactionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgencyTransactionService = TestBed.get(AgencyTransactionService);
    expect(service).toBeTruthy();
  });
});
