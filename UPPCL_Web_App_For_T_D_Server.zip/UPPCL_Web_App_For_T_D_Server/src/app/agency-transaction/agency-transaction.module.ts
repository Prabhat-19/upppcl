import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgencyTransactionComponent } from './agency-transaction.component';
import { AgencyTransactionRoutingModule } from './agency-transaction-routing.module'
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { Ng2SearchPipeModule } from 'ng2-search-filter';   
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [AgencyTransactionComponent],
  imports: [
    CommonModule,
    AgencyTransactionRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxPaginationModule,
    NgxSpinnerModule,
    Ng2SearchPipeModule
  ],
  providers: [ExcelServiceService,DatePipe]
})
export class AgencyTransactionModule { }