import { Component, OnInit,HostListener } from '@angular/core';
import { AgencyTransactionService } from './agency-transaction.service';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import { DatePipe } from '@angular/common';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { environment } from '../../environments/environment';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { TokenGenerateService } from '../token-generate.service';


@Component({
  selector: 'app-agency-transaction',
  templateUrl: './agency-transaction.component.html',
  styleUrls: ['./agency-transaction.component.scss']
})
export class AgencyTransactionComponent implements OnInit {
  
  typeSelectedValue = "Type"; 
  statusSelectedValue = "Status";  
  filterData: any;
  agencyTransactionData: any;
  agencyTransactionFilterData: any;
  result: any;
  startDate: any;
  endDate: any;
  datas: any;
  textFeildValue: any;
  creditAmount: number;
  debitAmount: number;
  config: any;
  token: any
  filterTransactionId: any;
  filterAgentId: any;
  filterConsumerId: any;
  filterType: any;
  filterBillNumber: any;
  filterAmount: any;
  filterSource = "Source";
  filterStatus: any;
  filterFromDate: any;
  filterToDate: any;
  activityArray:any;
  totalElements:any;
  constructor(private tokenGenerate:TokenGenerateService,private spinner:NgxSpinnerService,private router: Router, private generateTokenService: GenerateTokenService, private agentDashboardService: AgentDashboardService, public datepipe: DatePipe, private agencyTransactionService: AgencyTransactionService, private excelService: ExcelServiceService) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
    };
  }
  // totalItem:number=0;

  ngOnInit() {
    this.spinner.show();
    this.agentAuth();
    this.ledgerDetail(this.totalElements);
 
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }
  
  
  ledgerDetail(totalItems) {
    
    let arr = [];
    this.creditAmount = 0;
    this.debitAmount = 0;
    this.tokenGenerate.getToken(environment.agentTransactionAgentIdBasisToken).then(data => {
      this.token = data;
    this.agencyTransactionService.transactionDetail(totalItems,this.token).then((data: any) => {
      this.agencyTransactionData = data;
      for (var i = 0; i < this.agencyTransactionData.content.length; i++) {
        if (this.agencyTransactionData.content[i].payload.sourceType == "BANK") { this.agencyTransactionData.content[i].payload.sourceType = "NET BANKING"; }
        if (this.agencyTransactionData.content[i].payload.sourceType == "NON_RAPDRP") { this.agencyTransactionData.content[i].payload.sourceType = "NON-RAPDRP (RURAL)"; }
        if (this.agencyTransactionData.content[i].payload.sourceType == "RAPDRP") { this.agencyTransactionData.content[i].payload.sourceType = "RAPDRP (URBAN)"; }
        if (this.agencyTransactionData.content[i].payload.agentId == undefined) { this.agencyTransactionData.content[i].payload.agentId = "-"; }
        if (this.agencyTransactionData.content[i].payload.consumerAccountId == undefined) { this.agencyTransactionData.content[i].payload.consumerAccountId = "-"; }
        if (this.agencyTransactionData.content[i].payload.billId == undefined) { this.agencyTransactionData.content[i].payload.billId = "-"; }
        if (this.agencyTransactionData.content[i].payload.amount == undefined) { this.agencyTransactionData.content[i].payload.amount = "-"; }
        if (this.agencyTransactionData.content[i].payload.discom == undefined) { this.agencyTransactionData.content[i].payload.discom = "-"; }
        if (this.agencyTransactionData.content[i].payload.division == undefined) { this.agencyTransactionData.content[i].payload.division = "-"; }
       
        if (this.agencyTransactionData.content[i].status == "SUCCESS") {
          if(this.agencyTransactionData.content[i].type == "WalletTransaction"){
            this.activityArray = "DEBIT";
          }else{
          for(var activityData =0; activityData < this.agencyTransactionData.content[i].response.length;activityData++){
            if(this.agencyTransactionData.content[i].response[activityData].vanId != 'UPPCL'){
            this.activityArray = this.agencyTransactionData.content[i].response[activityData].activity;
          }
          }
        }
          this.agencyTransactionData.content[i]['sourceActivity'] = this.activityArray;
          if (this.agencyTransactionData.content[i].sourceActivity == "CREDIT") {
            this.creditAmount += this.agencyTransactionData.content[i].payload.amount;
          }
          if (this.agencyTransactionData.content[i].sourceActivity == "DEBIT") {
            this.debitAmount += this.agencyTransactionData.content[i].payload.amount;
          }
          arr.push(this.agencyTransactionData.content[i]);
          this.agencyTransactionFilterData = arr;
          this.result = this.agencyTransactionFilterData;
        }
      }
    })
    this.spinner.hide();
  })
}

  pageChanged(event) {
    console.log("inside if");
    
    this.config.currentPage = event;
    console.log(this.agencyTransactionData.totalElements);
    this.ledgerDetail(this.agencyTransactionData.totalElements);
  }



  onSubmit() {
    this.filterData = [];
    this.creditAmount = 0;
    this.debitAmount = 0;
    for (var agentTranscationLoop = 0; agentTranscationLoop < this.agencyTransactionData.content.length; agentTranscationLoop++) {
       
        if (this.filterTransactionId == null) {
          this.filterTransactionId = "";
        }
        if(this.filterToDate != null && this.filterToDate != ""){
        let newDate = new Date(this.filterToDate);  
        var nextDate = new Date(newDate.getTime()+1000*60*60*24);
       
        }
        if( (this.filterFromDate > this.filterToDate)){
          this.callModal("Invalid Date Range.");
          this.filterFromDate = "";
          this.filterToDate = "";
        }
        if (this.agencyTransactionData.content[agentTranscationLoop].status == "SUCCESS") { 
        if (this.filterTransactionId == null || (this.filterTransactionId != null && this.agencyTransactionData.content[agentTranscationLoop].response[0].transactionId.toUpperCase().includes(this.filterTransactionId.toUpperCase()))
          && (this.filterConsumerId == null || (this.filterConsumerId != null && this.agencyTransactionData.content[agentTranscationLoop].payload.consumerAccountId.includes(this.filterConsumerId)))
          && (this.filterAgentId == null || (this.filterAgentId != null && this.agencyTransactionData.content[agentTranscationLoop].payload.walletId.toUpperCase().includes(this.filterAgentId.toUpperCase())))
          && (this.typeSelectedValue == 'Type' || (this.typeSelectedValue != 'Type' && this.agencyTransactionData.content[agentTranscationLoop].response[0].activity.includes(this.typeSelectedValue.toUpperCase())))
          && (this.filterBillNumber == null || (this.filterBillNumber != null && this.agencyTransactionData.content[agentTranscationLoop].payload.billId.includes(this.filterBillNumber)))
          && (this.filterAmount == null || (this.filterAmount != null && this.agencyTransactionData.content[agentTranscationLoop].payload.amount == (Number(this.filterAmount))))
          && (this.filterSource == 'Source' || (this.filterSource != 'Source' && this.agencyTransactionData.content[agentTranscationLoop].payload.sourceType == (this.filterSource.toUpperCase())))
          && ((this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy') != null && this.agencyTransactionData.content[agentTranscationLoop].date >= (this.datepipe.transform(this.filterFromDate, 'dd-MM-yyyy')))))
          && (this.datepipe.transform(nextDate, 'dd-MM-yyyy') == null || (this.datepipe.transform(nextDate, 'dd-MM-yyyy') != null && this.agencyTransactionData.content[agentTranscationLoop].date <= (this.datepipe.transform(nextDate, 'dd-MM-yyyy'))))
        ) {
          if (this.agencyTransactionData.content[agentTranscationLoop].response[0].activity == "CREDIT") {
            this.creditAmount = this.creditAmount + this.agencyTransactionData.content[agentTranscationLoop].payload.amount;
          }
          if (this.agencyTransactionData.content[agentTranscationLoop].response[0].activity == "DEBIT") {
            this.debitAmount = this.debitAmount +this.agencyTransactionData.content[agentTranscationLoop].payload.amount;
          }
          this.filterData.push(this.agencyTransactionData.content[agentTranscationLoop])
        }
       }
    }
  // }
    this.agencyTransactionFilterData = this.filterData;
  }
  clear() {
    this.filterData = [];
    this.filterTransactionId = null;
    this.filterConsumerId = null;
    this.filterAgentId = null;
    this.typeSelectedValue = 'Type';
    this.filterBillNumber = null;
    this.filterAmount = null;
    this.filterSource = 'Source';
    this.statusSelectedValue = 'Status';
    this.filterToDate = null;
    this.filterFromDate = null;
    // this.agencyTransactionFilterData = this.result;
    this.onSubmit();
  }
  
  callModal(message: string) {
    
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }
  exportAsXLSX(): void {
    
    let arr1 = []
    for (var i = 0; i < this.agencyTransactionFilterData.length; i++) {
      if(this.agencyTransactionFilterData[i].type == 'WalletTransaction'){
       var agentId = this.agencyTransactionFilterData[i].response[1].vanId;
      }
      else{
        var agentId = this.agencyTransactionFilterData[i].payload.walletId;
      }
      console.log(agentId);
      arr1.push({
        TransactionId: this.agencyTransactionFilterData[i].response[0].transactionId,
        AgencyVan : localStorage.getItem('van'),
        AgencyName : localStorage.getItem("AgencyName"),
        AgentId: agentId,
        TransactionType: this.agencyTransactionFilterData[i].sourceActivity,
        ConsumerId: this.agencyTransactionFilterData[i].payload.consumerAccountId,
        ConsumerName: this.agencyTransactionFilterData[i].payload.consumerName,
        BillId: this.agencyTransactionFilterData[i].payload.billId,
        Amount: this.agencyTransactionFilterData[i].payload.amount,
        Source: this.agencyTransactionFilterData[i].payload.sourceType,
        Discom : this.agencyTransactionFilterData[i].payload.discom,
        Division : this.agencyTransactionFilterData[i].payload.division,
        TransactionStatus: this.agencyTransactionFilterData[i].status,
        Date: this.agencyTransactionFilterData[i].date,
      });
    }
    this.excelService.exportAsExcelFile(arr1, 'Ledger');
  }
}

