import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { AgencyTransactionComponent } from './agency-transaction.component';

const route:Routes=[
  {path:'agency-transaction',component:AgencyTransactionComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
 ]
})
export class AgencyTransactionRoutingModule { }