import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LedgerAnalysisComponent} from '../ledger-analysis/ledger-analysis.component'
const routes: Routes = [
  {path:'ledger-analysis',component:LedgerAnalysisComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LedgerAnalysisRoutingModule { }
