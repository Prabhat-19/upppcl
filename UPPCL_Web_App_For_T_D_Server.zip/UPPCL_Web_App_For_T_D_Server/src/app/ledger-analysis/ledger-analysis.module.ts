import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module';
import { LedgerAnalysisRoutingModule } from './ledger-analysis-routing.module';
import { LedgerAnalysisComponent } from './ledger-analysis.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { DatePipe } from '@angular/common';
import { OrderModule } from 'ngx-order-pipe';

@NgModule({
  declarations: [LedgerAnalysisComponent],
  imports: [
    CommonModule,
    LedgerAnalysisRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxPaginationModule,
    OrderModule
  ],
  providers: [DatePipe]

})
export class LedgerAnalysisModule { }
