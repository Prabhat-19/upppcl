import { TestBed } from '@angular/core/testing';

import { LedgerAnalysisService } from './ledger-analysis.service';

describe('LedgerAnalysisService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LedgerAnalysisService = TestBed.get(LedgerAnalysisService);
    expect(service).toBeTruthy();
  });
});
