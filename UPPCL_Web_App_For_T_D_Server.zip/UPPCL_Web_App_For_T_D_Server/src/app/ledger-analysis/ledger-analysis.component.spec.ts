import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LedgerAnalysisComponent } from './ledger-analysis.component';

describe('LedgerAnalysisComponent', () => {
  let component: LedgerAnalysisComponent;
  let fixture: ComponentFixture<LedgerAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LedgerAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LedgerAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
