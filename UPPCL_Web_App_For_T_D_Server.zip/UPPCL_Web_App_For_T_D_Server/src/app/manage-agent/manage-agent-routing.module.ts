import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes,Router,RouterModule  } from '@angular/router';
import { ManageAgentComponent } from './manage-agent.component';

const route:Routes=[
  {path:'manage-agent',component:ManageAgentComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class ManageAgentRoutingModule { }
