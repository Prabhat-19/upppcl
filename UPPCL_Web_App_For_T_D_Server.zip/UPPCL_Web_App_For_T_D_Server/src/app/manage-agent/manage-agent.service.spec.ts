import { TestBed } from '@angular/core/testing';

import { ManageAgentService } from './manage-agent.service';

describe('ManageAgentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManageAgentService = TestBed.get(ManageAgentService);
    expect(service).toBeTruthy();
  });
});
