import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageAgentComponent } from './manage-agent.component';
import { ManageAgentRoutingModule } from './manage-agent-routing.module';
import { ExcelServiceService } from '../excel-service/excel-service.service';
import{ FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import {SharedModule} from '../shared/shared.module'
import { DatePipe } from '@angular/common';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OrderModule } from 'ngx-order-pipe';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [ManageAgentComponent],
  imports: [
    CommonModule,
    ManageAgentRoutingModule,
    FormsModule,
    RouterModule,
    SharedModule,
    ScrollingModule,
    NgxSpinnerModule,
    OrderModule
  ],
  providers: [ExcelServiceService,DatePipe]
})
export class ManageAgentModule { }
