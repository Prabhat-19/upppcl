import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';
import { Observable } from 'rxjs';
import { constant } from 'src/environments/constant';

@Injectable({
  providedIn: 'root'
})
export class ManageAgentService {
  header:any;
  constructor(private http: HttpClient) { }
  manageSubAgent(token:any){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization':'Bearer '+ token.access_token
      })};
    return new Promise(resolve => {
      this.http.get(environment.allAgentOnBasisOfAgencyId+localStorage.getItem('agentId'), httpOptions).subscribe((data: any) => {
        resolve(data);
       });
   });
  }

    walletSubAgent(result:any,walletBalancetoken:any){
      
      this.header = {
        headers: new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Bearer ' + walletBalancetoken.access_token
        })
      }
      return new Promise(resolve => {
         this.http.get(environment.manageSubAgentWalletDetails+result,this.header).subscribe((data: any) => {
              resolve(data);
              });
       });
      }
    delete(ID,token:any){
      console.log(token)
      const httpOptions = {
        headers: new HttpHeaders({
          'Authorization':'Bearer '+ token.access_token
        })};
      return new Promise(resolve => {
      this.http.delete(environment.deleteSubAgent+ID,httpOptions).subscribe((data: any) => {
        resolve(data);
        });
    });
    }
    onIDAMDelete(userName,authToken){
      console.log(userName);
      console.log(authToken);
      return new Promise(resolve => {
        this.http.delete(environment.changePassword+userName ,
        {
        headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept-API-Version':'resource=2.0, protocol=1.0' ,
        'iplanetDirectoryPro': authToken
        })
        }).subscribe(data => {
        resolve(data);
        });
        });
      }
      agentValidateIDAM(){
        return new Promise(resolve => {
          this.http.post(environment.validateAgentWithIDAM,{},
          {
          headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'X-OpenAM-Username': constant.adminOpenAMUserName,   
          'X-OpenAM-Password':constant.adminOpenAMPassword,     
          'Accept-API-Version':'resource=2.0, protocol=1.0' 
          })
          }).subscribe(data => {
          resolve(data);
          });
          });
      }
}

