import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: '',
  loadChildren: () => import('./login/login.module').then(mod => mod.LoginModule)
  },
  { path: '',
  loadChildren: () => import('./login/login.module').then(mod => mod.LoginModule)
  },
  { path: '',
  loadChildren: () => import('./registration/registration.module').then(mod => mod.RegistrationModule)
  },
  { path: '',
  loadChildren: () => import('./bill-payment/bill-payment.module').then(mod => mod.BillPaymentModule)
  },
  { path: '',
  loadChildren: () => import('./recharge-wallet/recharge-wallet.module').then(mod => mod.RechargeWalletModule)
  },
  { path: '',
  loadChildren: () => import('./add-agent/add-agent.module').then(mod => mod.AddAgentModule)
  },
  { path: '',
  loadChildren: () => import('./admin-approval/admin-approval.module').then(mod => mod.AdminApprovalModule)
  },
  { path: '',
  loadChildren: () => import('./admin-dashboard/admin-dashboard.module').then(mod => mod.AdminDashboardModule)
  },
  { path: '',
  loadChildren: () => import('./admin-edit/admin-edit.module').then(mod => mod.AdminEditModule)
  },
  { path: '',
  loadChildren: () => import('./admin-transaction/admin-transaction.module').then(mod => mod.AdminTransactionModule)
  },
  { path: '',
  loadChildren: () => import('./agency-dashboard/agency-dashboard.module').then(mod => mod.AgencyDashboardModule)
  },
  { path: '',
  loadChildren: () => import('./agent-changepassword/agent-changepassword.module').then(mod => mod.AgentChangepasswordModule)
  },
  { path: '',
  loadChildren: () => import('./agent-dashboard/agent-dashboard.module').then(mod => mod.AgentDashboardModule)
  },
  { path: '',
  loadChildren: () => import('./agent-earning/agent-earning.module').then(mod => mod.AgentEarningModule)
  },
  { path: '',
  loadChildren: () => import('./agent-profile/agent-profile.module').then(mod => mod.AgentProfileModule)
  },
  { path: '',
  loadChildren: () => import('./agent-transaction/agent-transaction.module').then(mod => mod.AgentTransactionModule)
  },
  { path: '',
  loadChildren: () => import('./agent-voucher/agent-voucher.module').then(mod => mod.AgentVoucherModule)
  },{ path: '',
  loadChildren: () => import('./email-verification/email-verification.module').then(mod => mod.EmailVerificationModule)
  },
  { path: '',
  loadChildren: () => import('./forget-password/forget-password.module').then(mod => mod.ForgetPasswordModule)
  },
  { path: '',
  loadChildren: () => import('./manage-agent/manage-agent.module').then(mod => mod.ManageAgentModule)
  },
  { path: '',
  loadChildren: () => import('./otp-verify/otp-verify.module').then(mod => mod.OtpVerifyModule)
  },
  { path: '',
  loadChildren: () => import('./recharge-success/recharge-success.module').then(mod => mod.RechargeSuccessModule)
  },
  { path: '',
  loadChildren: () => import('./registration-success/registration-success.module').then(mod => mod.RegistrationSuccessModule)
  },
  { path: '',
  loadChildren: () => import('./wallet-distribution/wallet-distribution.module').then(mod => mod.WalletDistributionModule)
  },
  { path: '',
  loadChildren: () => import('./agency-wallet/agency-wallet.module').then(mod => mod.AgencyWalletModule)
  },
  { path: '',
  loadChildren: () => import('./agency-recharge-success/agency-recharge-success.module').then(mod => mod.AgencyRechargeSuccessModule)
  },
  { path: '',
  loadChildren: () => import('./manage-agent-edit/manage-agent-edit.module').then(mod => mod.ManageAgentEditModule)
  },
  { path: '',
  loadChildren: () => import('./agency-profile/agency-profile.module').then(mod => mod.AgencyProfileModule)
  },
  { path: '',
  loadChildren: () => import('./agency-changepassword/agency-changepassword.module').then(mod => mod.AgencyChangepasswordModule)
  },
  { path: '',
  loadChildren: () => import('./pending-verification/pending-verification.module').then(mod => mod.PendingVerificationModule)
  },
  { path: '',
  loadChildren: () => import('./admin-analysis/admin-analysis.module').then(mod => mod.AdminAnalysisModule)
  },
  { path: '',
  loadChildren: () => import('./all-subagentdetail/all-subagentdetail.module').then(mod => mod.AllSubagentdetailModule)
  },
  { path: '',
  loadChildren: () => import('./history-subagentdetails/history-subagentdetails.module').then(mod => mod.HistorySubagentdetailsModule)
  },
  { path: '',
  loadChildren: () => import('./agency-transaction/agency-transaction.module').then(mod => mod.AgencyTransactionModule)
  },
  { path: '',
  loadChildren: () => import('./ledger-analysis/ledger-analysis.module').then(mod => mod.LedgerAnalysisModule)
  },
  { path: '',
  loadChildren: () => import('./allRegisteredUser/all-registered-user.module').then(mod => mod.AllRegisteredUserModule)
  },
  { path: '',
  loadChildren: () => import('./adminChangePassword/admin-change-password.module').then(mod => mod.AdminChangePasswordModule)
  },
  { path: '',
  loadChildren: () => import('./icicilanding-page/icicilanding-page.module').then(mod => mod.IcicilandingPageModule)
  },

  { path: '',
  loadChildren: () => import('./paymentgateway-landingpage/paymentgateway-landingpage.module').then(mod => mod.PaymentgatewayLandingpageModule)
  },
  { path: '',
  loadChildren: () => import('./adminDetails-edit/admin-details-edit.module').then(mod => mod.AdminDetailsEditModule)
  },
  { path: '',
  loadChildren: () => import('./agency-commission/agency-commission.module').then(mod => mod.AgencyCommissionModule)
  },
  { path: '',
  loadChildren: () => import('./admin-agency-listing/admin-agency-listing.module').then(mod => mod.AdminAgencyListingModule)
  },
  { path:'',
  loadChildren: () => import('./admin-sub-agent-listing/admin-sub-agent-listing.module').then(mod => mod.AdminSubAgentListingModule)
  },
  { path:'',
  loadChildren: () => import('./sub-agent-edit/sub-agent-edit.module').then(mod => mod.SubAgentEditModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
