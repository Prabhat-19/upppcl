import { TestBed } from '@angular/core/testing';

import { ManageAgentEditService } from './manage-agent-edit.service';

describe('ManageAgentEditService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ManageAgentEditService = TestBed.get(ManageAgentEditService);
    expect(service).toBeTruthy();
  });
});
