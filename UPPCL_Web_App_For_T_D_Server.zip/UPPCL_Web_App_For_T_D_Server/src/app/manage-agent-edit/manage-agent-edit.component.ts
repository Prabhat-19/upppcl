import { Component, OnInit, HostListener } from '@angular/core';
import { ManageAgentEditService } from './manage-agent-edit.service';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';
import { GenerateTokenService } from '../generate-token/generate-token.service';
import { environment } from 'src/environments/environment';
import { TokenGenerateService } from '../token-generate.service';
declare var $: any;
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manage-agent-edit',
  templateUrl: './manage-agent-edit.component.html',
  styleUrls: ['./manage-agent-edit.component.scss']
})
export class ManageAgentEditComponent implements OnInit {
  
  manageAgentEditData: any;
  datas: any;
  token: any;
  firstName: string;
  lastName: string;
  emailAddress: string;
  userName: string;
  discom: string;
  mobileNumber: string;
  address: string;
  city: string;
  state: string;
  district: string;
  postalCode: string;
  payload: any;
  constructor(private tokenGenerate: TokenGenerateService, private generateTokenService: GenerateTokenService, private agentDashboardService: AgentDashboardService, private manageAgentEdit: ManageAgentEditService, private router: Router) { }

  ngOnInit() {
    this.agentAuth();
    $('#manage-agent').css('color', 'white');
    this.disabledField();
    this.manageSubAgentEdit();
    this.checkUserTyper();
  }

  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then(data => {
      this.datas = data;

      if (!this.datas.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

  disabledField(){
    (document.getElementById("userName") as HTMLInputElement).disabled = true;
    $('#userName').css('background-color', '#ebebe4');
    (document.getElementById("emailAddress") as HTMLInputElement).disabled = true;
    $('#emailAddress').css('background-color', '#ebebe4');
    (document.getElementById("mySelect2") as HTMLInputElement).disabled = true;
    $('#mySelect2').css('background-color', '#ebebe4');
  }

  manageSubAgentEdit() {
    this.tokenGenerate.getToken(environment.vanAgentDetailsToken).then(data => {
      this.token = data;
      this.manageAgentEdit.manageSubAgentEdit(this.token).then((data: any) => {
        this.manageAgentEditData = data;
        this.firstName = this.manageAgentEditData[0].user.firstName;
        this.lastName = this.manageAgentEditData[0].user.lastName;
        this.emailAddress = this.manageAgentEditData[0].user.email;
        this.userName = this.manageAgentEditData[0].user.userName;
        this.discom = this.manageAgentEditData[0].discoms;
        this.mobileNumber = this.manageAgentEditData[0].user.mobile;
        this.address = this.manageAgentEditData[0].user.address.address;
        this.city = this.manageAgentEditData[0].user.address.city;
        this.state = this.manageAgentEditData[0].user.address.state;
        this.district = this.manageAgentEditData[0].user.address.district;
        this.postalCode = this.manageAgentEditData[0].user.address.postalCode;
      })
    })
  }

  updateDetail() {
    this.payload = {
      "address": {
        "address": this.address,
        "city": this.city,
        "district": this.district,
        "postalCode": this.postalCode,
        "state": this.state
      },
      "firstName": this.firstName,
      "lastName": this.lastName,
      "mobile": this.mobileNumber
    }
    this.tokenGenerate.getToken(environment.userToken).then(data => {
      this.token = data;
      this.manageAgentEdit.updateDetails(this.payload, this.token.access_token).then(data => {
        this.datas = data;
      })

    })
  }

  onSubmit(subAgentDetail: NgForm) {
    var basic = subAgentDetail.value;
    if (basic.firstName == "" || basic.lastName == "" || basic.address == "" || basic.state == "" || basic.city == "" || basic.postalCode == "" || basic.mobileNumber == "" || basic.district == "") {
      this.callModal("Please enter all required field(s).");
    }
    else {
      this.confirmationModal(event);
    }
  }

  checkUserTyper() {
    if ((localStorage.getItem("userType") == "Agent") || (localStorage.getItem("userType") == "UPPCL")) {
      localStorage.clear();
      this.router.navigate(['/login']);
    }
  }

  confirmationModal(event) {
    $(document).ready(function () {
      event.preventDefault();
      jQuery.noConflict();
      $("#exampleModalCenter").modal();
    });
  }

  return() {
    this.router.navigate(['/manage-agent'])
  }

  mobileNumberCheck() {
    var mobileNumber = (<HTMLInputElement>document.getElementById("mobileNumber")).value;
    var numberCheck = /^\d{10}$/;
    if (!(mobileNumber.match(numberCheck))) {
      (document.getElementById("mobileNumber") as HTMLInputElement).value = "";
      this.callModal("Please enter valid Mobile Number.")
    }
  }

  callModal(message: string) {
    $(document).ready(function () {
      $("#modelText").text(message);
      $('#btnhide').click();
    })
  }

  isNumberKey(evt): boolean {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  postalNumberCheck() {
    var postalNumber = (<HTMLInputElement>document.getElementById("textfield6")).value;
    var numberCheck = /^\d{6}$/;
    if (!(postalNumber.match(numberCheck))) {
      (document.getElementById("textfield6") as HTMLInputElement).value = "";
      this.callModal("Please enter valid postal number.")
    }
  }
}
