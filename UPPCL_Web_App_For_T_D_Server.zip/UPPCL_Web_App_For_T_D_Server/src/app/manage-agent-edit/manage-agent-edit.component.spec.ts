import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAgentEditComponent } from './manage-agent-edit.component';

describe('ManageAgentEditComponent', () => {
  let component: ManageAgentEditComponent;
  let fixture: ComponentFixture<ManageAgentEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAgentEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAgentEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
