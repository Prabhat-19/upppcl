import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment  } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ManageAgentEditService {

  header:any;

  constructor(private http: HttpClient) { }

  manageSubAgentEdit(token:any){
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization':'Bearer '+ token.access_token
      })};
    return new Promise(resolve => {
    this.http.get(environment.manageSubAgentEdit+localStorage.getItem('subAgentId'), httpOptions).subscribe((data: any) => {
    resolve(data);
    });
   });
  }

  updateDetails(payload,token) {

  this.header = {
    headers: new HttpHeaders({
      'Authorization': 'Bearer ' + token
    })
  }
console.log(payload);

    var url = environment.updateUserDetails + localStorage.getItem("subAgentId");

      let promise = new Promise((resolve, reject) => {
        this.http.put(url, payload,this.header).toPromise().then((data: any) => {
                resolve(data);
            },
                msg => {
                    reject(msg);
                })
    })
    return promise;
    
  }
}
