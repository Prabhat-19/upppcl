import { NgModule } from '@angular/core';
import { Routes, Router,RouterModule } from '@angular/router';
import {ManageAgentEditComponent} from './manage-agent-edit.component'

const routes: Routes = [
  { path:'manage-agent-edit', component: ManageAgentEditComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageAgentEditRoutingModule { }
