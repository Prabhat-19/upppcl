import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { AgentDashboardService } from '../agent-dashboard/agent-dashboard.service';

@Component({
  selector: 'app-admin-change-password',
  templateUrl: './admin-change-password.component.html',
  styleUrls: ['./admin-change-password.component.scss']
})
export class AdminChangePasswordComponent implements OnInit {
  
  constructor(private router: Router, private agentDashboardService: AgentDashboardService) { }

  ngOnInit() {
    this.agentAuth();
  }

   /*
  This method is used to authenticate the user  
  */
  agentAuth() {
    this.agentDashboardService.agentTokenValidateIDAM().then((data:any) => {
      if (!data.valid) {
        this.router.navigate(["/login"]);
      }
    });
  }

}
