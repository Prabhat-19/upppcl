import { Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminHeaderService {

  constructor(private router:Router,private http:HttpClient) { }

 deleteToken() {
  let promise = new Promise((resolve, reject) => {
  this.http.post(environment.deleteTokenApi, {},
    {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Accept-Api-Version':'resource=1.1, protocol=1.0',
            'iplanetDirectoryPro': localStorage.getItem("authToken")
        })
      }).toPromise().then((data: any) => {
        resolve(data);
    },
        msg => {
          if(JSON.stringify(msg).includes("Access Denied"))
          {
          localStorage.clear();
          this.router.navigate(['/login']);
          }
          reject(msg);
        }
    )
});
return promise;
  }

}
