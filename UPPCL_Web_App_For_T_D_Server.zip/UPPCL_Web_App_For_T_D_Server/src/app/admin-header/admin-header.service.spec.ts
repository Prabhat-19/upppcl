import { TestBed } from '@angular/core/testing';

import { AdminHeaderService } from './admin-header.service';

describe('AdminHeaderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminHeaderService = TestBed.get(AdminHeaderService);
    expect(service).toBeTruthy();
  });
});
