import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AdminHeaderService } from './admin-header.service';

@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.scss']
})
export class AdminHeaderComponent implements OnInit {

  constructor(private adminHeaderService: AdminHeaderService, private router: Router) { }

  ngOnInit() {
  }

  /**
   * logout method in admin header.
   */
  logout() {
    this.adminHeaderService.deleteToken().then(data => {
      localStorage.clear();
      this.router.navigate(['/login']);
    });
  }
}
