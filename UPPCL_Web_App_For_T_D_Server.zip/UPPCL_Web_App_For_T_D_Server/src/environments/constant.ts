export const constant = {

    dropDownValue : 'Select one',
    oldPasswordWrong:'Old password is incorrect.',

    billAlreadyPaid:"Bill already paid for this bill number.",
    alertError:"Alert",

    // production openAM admin username and password 
    // adminOpenAMUserName :'walletadmin',
    // adminOpenAMPassword : ' Welcome1$321 ',

    // t&d openAM admin username and password 
    adminOpenAMUserName :'Amadmin',
    adminOpenAMPassword : 'Welcome1',

    // production ws02 admin username and password 
    // adminWSO2UserName :"apimdmin",
    // adminWSO2Password : "apim@2019",

    // T&D ws02 admin username and password 
    adminWSO2UserName :"uppclgenx",
    adminWSO2Password : "genx@Apg1219"
}